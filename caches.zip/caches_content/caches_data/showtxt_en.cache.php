﻿<?php
return array (
'　<p align="left">　　博大考神<b><a href="http://www.kaozc.com/tg/zcyy/zz/" >职称英语家庭式培训班</a></b>是为了帮助那些没有时间、没有精力、没有基础的考生能顺利通过职称英语考试而专门设计的。家庭式培训班采用高科技术让考生在家就能上的面授，随时随地学，名师面对面，职称英语教父亲授考试解题技巧。只要学习达标率达到95%，协议保证通过职称英语考试，不过退款。 <a class="STYLE1" href="http://www.kaozc.com/tg/zcyy/zz/" target="_blank" rel="nofollow"><font color="#ff0000">点击免费下载</font></a>。</p>',

'<p align="left">　　博大考神作为专业的职称英语考试培训中心想考生所想，结合多年的培训经验，将远程教学与面对面名师教学紧密结合建立了<b><a href="http://www.kaozc.com/tg/zcyy/zz/">职称英语家庭式培训班</a></b>，彻底解决了考生自学效果不佳、工作忙无法参加培训的问题，帮您获取高分、成功过关!<a class="STYLE1" href="http://www.kaozc.com/tg/zcyy/zz/" rel="nofollow" target="_blank">
<font color="#ff0000">点击免费下载</font></a>。</p>
',

'
<p align="left">　　博大考神<b><a href="http://www.kaozc.com/tg/zcyy/zz/" >职称英语家庭式培训班</a></b>突破性的开创了一套以技巧为主线的教学模式。由职称英语教父带领的名师团队为考生讲解各种应试技巧，简单、实用，上手极快。多年来为广大考生解决了难题并获得晋升。已经被誉为职称英语基础薄弱考生的必备利器，帮助无数的零基础考生用最短的时间轻松的通过了复杂的职称英语考试。<a class="STYLE1" href="http://www.kaozc.com/tg/zcyy/zz/" target="_blank" rel="nofollow"><font color="#ff0000">点击免费下载</font></a>。</p>');