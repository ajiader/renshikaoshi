﻿<?php
return array (
'　<p align="left">　　有关<b><a href="http://www.kaozc.com/jsj/" >职称计算机考试</a></b>博大考神专门为考生提供了一套能提高考试技巧的软件。通过它不仅可以和全国的其余考生交流经验，还能自动收集考试错题，针对考试的薄弱点进行有针对性的练习。并且里面的职称计算机考试模块可以在线更新，拥有市面上最广，最全的题型。提高考生技巧、能力，让考生顺利通过考试!<a class="STYLE1" href="http://cps.egbroad.com/cpstransfer.php?unid=j1037&&urlto=http://www.egbroad.com/kfb/zcjsj/" target="_blank" rel="nofollow"><font color="#ff0000">点击免费下载</font></a>。</p>',

'<p align="left">　　博大考神<b><a href="http://www.kaozc.com/jsj/">职称计算机考试</a></b>学习软件专业数十年，帮助你不花冤枉钱，不走弯路，用最少的时间，花最小的精力，一次性通过职称计算机考试，轻松圆您升职加薪梦!
<a class="STYLE1" href="http://cps.egbroad.com/cpstransfer.php?unid=j1037&&urlto=http://www.egbroad.com/kfb/zcjsj/" rel="nofollow" target="_blank">
<font color="#ff0000">点击免费下载</font></a>。</p>
',

'
<p align="left">　　博大考神<b><a href="http://www.kaozc.com/jsj/" >职称计算机考试</a></b>培训学习软件功能先进、操作轻松简单、通过率高，采用最新的动态题库技术、题目与国家考试题库高度一致、随时在线升级。<a class="STYLE1" href="http://cps.egbroad.com/cpstransfer.php?unid=j1037&&urlto=http://www.egbroad.com/kfb/zcjsj/" target="_blank" rel="nofollow"><font color="#ff0000">点击免费下载</font></a>。</p>');