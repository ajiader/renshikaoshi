<?php
return array (
  'phpcms/base.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '/eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => 'base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '(base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/libs/functions/global.func.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '@eval(',
        1 => 'eval',
      ),
      1 => 
      array (
        0 => ' base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
  'phpcms/modules/attachment/templates/imgupload.tpl.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => ' eval(',
        1 => 'eval',
      ),
    ),
  ),
  'phpcms/modules/content/fields/editor/output.inc.php' => 
  array (
    'func' => 
    array (
      0 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
      1 => 
      array (
        0 => '.base64_decode(',
        1 => 'base64_decode',
      ),
      2 => 
      array (
        0 => '_base64_decode(',
        1 => 'base64_decode',
      ),
    ),
  ),
);
?>