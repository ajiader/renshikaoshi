<?php
return array (
  'file_type' => 'php',
  'func' => 'com|system|exec|eval|escapeshell|cmd|passthru|base64_decode|gzuncompress|05579',
  'code' => '',
  'md5_file' => '/data/wwwroot/test.kaozc.com/caches/caches_scan/caches_data/md5_2013-04-23.cache.php',
  'dir' => 'array (
  0 => \'/data/wwwroot/test.kaozc.com/phpcms\',
  1 => \'/data/wwwroot/test.kaozc.com/uploadfile\',
  2 => \'/data/wwwroot/test.kaozc.com/404-1.php\',
  3 => \'/data/wwwroot/test.kaozc.com/api.php\',
  4 => \'/data/wwwroot/test.kaozc.com/index.php\',
  5 => \'/data/wwwroot/test.kaozc.com/jiekou2_utf8.php\',
  6 => \'/data/wwwroot/test.kaozc.com/jiekou_utf8.php\',
  7 => \'/data/wwwroot/test.kaozc.com/jiekoukou3_utf8.php\',
  8 => \'/data/wwwroot/test.kaozc.com/m.php\',
  9 => \'/data/wwwroot/test.kaozc.com/m_all.php\',
  10 => \'/data/wwwroot/test.kaozc.com/memcached.php\',
  11 => \'/data/wwwroot/test.kaozc.com/plugin.php\',
)',
);
?>