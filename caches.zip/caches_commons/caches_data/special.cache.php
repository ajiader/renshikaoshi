<?php
return array (
  1 => 
  array (
    'id' => '1',
    'siteid' => '1',
    'title' => '博大考试专题',
    'url' => 'http://test.kaozc.com/specials/',
    'thumb' => 'http://www.boda.com/uploadfile/2012/1102/20121102030630668.jpg',
    'banner' => 'http://www.boda.com/uploadfile/2012/1106/20121106042224529.jpg',
    'ishtml' => '0',
  ),
);
?>