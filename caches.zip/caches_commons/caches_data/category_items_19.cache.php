<?php
return array (
  880 => '1269',
);
?>