<?php
return array (
  5 => 
  array (
    'workflowid' => '5',
    'siteid' => '2',
    'steps' => '1',
    'workname' => '审核',
    'description' => '',
    'setting' => 'array (
  1 => 
  array (
    0 => \'sunlifang\',
  ),
  2 => \'\',
  3 => \'\',
  4 => \'\',
  \'nocheck_users\' => \'\',
)',
    'flag' => '1',
  ),
);
?>