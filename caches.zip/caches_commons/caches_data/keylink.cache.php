<?php
return array (
  0 => 
  array (
    0 => '兴安盟人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/nmgxinanmeng.html',
  ),
  1 => 
  array (
    0 => '北京人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/beijing.html',
  ),
  2 => 
  array (
    0 => '天津人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/tianjin.html',
  ),
  3 => 
  array (
    0 => '河北人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/hebei.html',
  ),
  4 => 
  array (
    0 => '山西人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/shanxi.html',
  ),
  5 => 
  array (
    0 => '湖北人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/hubei.html',
  ),
  6 => 
  array (
    0 => '江苏人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/jiangshu.html',
  ),
  7 => 
  array (
    0 => '安徽人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/anhui.html',
  ),
  8 => 
  array (
    0 => '山东人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/shandong.html',
  ),
  9 => 
  array (
    0 => '上海人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/shanghai.html',
  ),
  10 => 
  array (
    0 => '浙江人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/zhejiang.html',
  ),
  11 => 
  array (
    0 => '江西人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/jiangxi.html',
  ),
  12 => 
  array (
    0 => '福建人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/fujian.html',
  ),
  13 => 
  array (
    0 => '湖南人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/hunan.html',
  ),
  14 => 
  array (
    0 => '宁夏人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/ningxia.html',
  ),
  15 => 
  array (
    0 => '内蒙古人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/neimenggu.html',
  ),
  16 => 
  array (
    0 => '河南人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/henan.html',
  ),
  17 => 
  array (
    0 => '四川人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/sichuan.html',
  ),
  18 => 
  array (
    0 => '重庆人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/chongqing.html',
  ),
  19 => 
  array (
    0 => '贵州人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/guizhou.html',
  ),
  20 => 
  array (
    0 => '云南人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/yunnan.html',
  ),
  21 => 
  array (
    0 => '辽宁人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/liaoning.html',
  ),
  22 => 
  array (
    0 => '吉林人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/jilin.html',
  ),
  23 => 
  array (
    0 => '广东人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/guangdong.html',
  ),
  24 => 
  array (
    0 => '广西人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/guangxi.html',
  ),
  25 => 
  array (
    0 => '海南人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/hainan.html',
  ),
  26 => 
  array (
    0 => '陕西人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/shanxis.html',
  ),
  27 => 
  array (
    0 => '甘肃人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/gansu.html',
  ),
  28 => 
  array (
    0 => '新疆人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/xinjiang.html',
  ),
  29 => 
  array (
    0 => '青海人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/qinghai.html',
  ),
  30 => 
  array (
    0 => '西藏人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/xizang.html',
  ),
  31 => 
  array (
    0 => '黑龙江人事考试网',
    1 => 'http://www.renshikaoshi.net/renshibaoming/heilongjiang.html',
  ),
);
?>