<?php
return array (
  7 => '0',
);
?>