<?php
return array (
  820 => '0',
);
?>