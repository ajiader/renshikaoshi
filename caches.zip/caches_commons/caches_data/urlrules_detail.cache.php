<?php
return array (
  1 => 
  array (
    'urlruleid' => '1',
    'module' => 'content',
    'file' => 'category',
    'ishtml' => '1',
    'urlrule' => '{$categorydir}{$catdir}/index.html|{$categorydir}{$catdir}/{$page}.html',
    'example' => 'news/china/1000.html',
  ),
  6 => 
  array (
    'urlruleid' => '6',
    'module' => 'content',
    'file' => 'category',
    'ishtml' => '0',
    'urlrule' => 'index.php?m=content&c=index&a=lists&catid={$catid}|index.php?m=content&c=index&a=lists&catid={$catid}&page={$page}',
    'example' => 'index.php?m=content&c=index&a=lists&catid=1&page=1',
  ),
  11 => 
  array (
    'urlruleid' => '11',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '1',
    'urlrule' => '{$year}/{$catdir}_{$month}{$day}/{$id}.html|{$year}/{$catdir}_{$month}{$day}/{$id}_{$page}.html',
    'example' => '2010/catdir_0720/1_2.html',
  ),
  12 => 
  array (
    'urlruleid' => '12',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '1',
    'urlrule' => '{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}.html|{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}_{$page}.html',
    'example' => 'it/product/2010/0720/1_2.html',
  ),
  16 => 
  array (
    'urlruleid' => '16',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'index.php?m=content&c=index&a=show&catid={$catid}&id={$id}|index.php?m=content&c=index&a=show&catid={$catid}&id={$id}&page={$page}',
    'example' => 'index.php?m=content&c=index&a=show&catid=1&id=1',
  ),
  17 => 
  array (
    'urlruleid' => '17',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'kaoshi-{$catid}-{$id}-{$page}.html',
    'example' => 'kaoshi-1-1-1.html',
  ),
  18 => 
  array (
    'urlruleid' => '18',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'content-{$catid}-{$id}-{$page}.html',
    'example' => 'content-1-2-1.html',
  ),
  30 => 
  array (
    'urlruleid' => '30',
    'module' => 'content',
    'file' => 'category',
    'ishtml' => '0',
    'urlrule' => '/list-{$catid}-{$page}.html',
    'example' => '/list-1-1.html',
  ),
  31 => 
  array (
    'urlruleid' => '31',
    'module' => 'content',
    'file' => 'category',
    'ishtml' => '0',
    'urlrule' => '/{$categorydir}{$catdir}/|/{$categorydir}{$catdir}/{$page}.html|/{$categorydir}{$catdir}/{$pinyin}_{$page}.html|/{$categorydir}{$catdir}/m{$mid}_t{$typeid}_{$page}.html',
    'example' => '/栏目伪静态/',
  ),
  32 => 
  array (
    'urlruleid' => '32',
    'module' => 'zsask',
    'file' => 'question',
    'ishtml' => '0',
    'urlrule' => '/question/{$id}.html',
    'example' => '/question/1.html',
  ),
  33 => 
  array (
    'urlruleid' => '33',
    'module' => 'content',
    'file' => 'tags',
    'ishtml' => '0',
    'urlrule' => 'tags-{$tag}_{$catid}_{$page}.html ',
    'example' => 'tags-关键词-10-1.html',
  ),
  34 => 
  array (
    'urlruleid' => '34',
    'module' => 'content',
    'file' => 'city_list',
    'ishtml' => '0',
    'urlrule' => '/{$pinyin}/citylist-{$catids}-{$name}-{$page}.html',
    'example' => '/城市拼音/list-多个栏目id-栏目名称-分页.html',
  ),
  35 => 
  array (
    'urlruleid' => '35',
    'module' => 'content',
    'file' => 'zhuanjia',
    'ishtml' => '0',
    'urlrule' => '/zhuanjia/list_{$id}_{$page}.html',
    'example' => '/zhuanjia/list_1_1.html',
  ),
  36 => 
  array (
    'urlruleid' => '36',
    'module' => 'content',
    'file' => 'category',
    'ishtml' => '0',
    'urlrule' => '/{$catdir}/|/{$catdir}/{$page}.html',
    'example' => '/公务员大列表/',
  ),
  37 => 
  array (
    'urlruleid' => '37',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'jsj/{$catid}-{$id}-{$page}.html',
    'example' => 'jsj/1-1-1.html',
  ),
  38 => 
  array (
    'urlruleid' => '38',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'english/{$catid}-{$id}-{$page}.html',
    'example' => 'english/1-1-1.html',
  ),
  39 => 
  array (
    'urlruleid' => '39',
    'module' => 'content',
    'file' => 'show',
    'ishtml' => '0',
    'urlrule' => 'zyzg/{$catid}-{$id}-{$page}.html',
    'example' => '/zyzg/1-1-1.html',
  ),
);
?>