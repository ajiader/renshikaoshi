<?php
return array (
  'admin_email' => 'phpcms@phpcms.cn',
  'maxloginfailedtimes' => '8',
  'minrefreshtime' => '2',
  'mail_type' => '1',
  'mail_server' => 'smtp.qq.com',
  'mail_port' => '25',
  'category_ajax' => '0',
  'mail_user' => 'phpcms.cn@foxmail.com',
  'mail_auth' => '1',
  'mail_from' => 'phpcms.cn@foxmail.com',
  'mail_password' => '',
  'errorlog_size' => '20',
  'ftp_enable' => '0',
  'ftp_host' => '192.168.11.14',
  'ftp_user' => 'ajiader',
  'ftp_password' => '123123',
  'ftp_port' => '21',
  'ftp_pasv' => '1',
  'ftp_path' => '/uploadfile',
  'ftp_upload_url' => 'http://static.boda.com/uploadfile/',
);
?>