<?php
return array (
  'siteid' => '81351338',
  'password' => '9586627772',
);
?>