<?php
return array (
  1 => '超级管理员',
  11 => '采集器',
);
?>