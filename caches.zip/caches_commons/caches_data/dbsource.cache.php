<?php
return array (
  'cgk8' => 
  array (
    'hostname' => '27.54.227.48:3306',
    'database' => 'cgk8',
    'db_tablepre' => 'cdb_',
    'username' => 'boda_root',
    'password' => 'bdforever123456',
    'charset' => 'utf8',
    'debug' => 0,
    'pconnect' => 0,
    'autoconnect' => 0,
  ),
);
?>