<?php
return array (
  1 => '{$categorydir}{$catdir}/index.html|{$categorydir}{$catdir}/{$page}.html',
  6 => 'index.php?m=content&c=index&a=lists&catid={$catid}|index.php?m=content&c=index&a=lists&catid={$catid}&page={$page}',
  11 => '{$year}/{$catdir}_{$month}{$day}/{$id}.html|{$year}/{$catdir}_{$month}{$day}/{$id}_{$page}.html',
  12 => '{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}.html|{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}_{$page}.html',
  16 => 'index.php?m=content&c=index&a=show&catid={$catid}&id={$id}|index.php?m=content&c=index&a=show&catid={$catid}&id={$id}&page={$page}',
  17 => 'kaoshi-{$catid}-{$id}-{$page}.html',
  18 => 'content-{$catid}-{$id}-{$page}.html',
  30 => '/list-{$catid}-{$page}.html',
  31 => '/{$categorydir}{$catdir}/|/{$categorydir}{$catdir}/{$page}.html|/{$categorydir}{$catdir}/{$pinyin}_{$page}.html|/{$categorydir}{$catdir}/m{$mid}_t{$typeid}_{$page}.html',
  32 => '/question/{$id}.html',
  33 => 'tags-{$tag}_{$catid}_{$page}.html ',
  34 => '/{$pinyin}/citylist-{$catids}-{$name}-{$page}.html',
  35 => '/zhuanjia/list_{$id}_{$page}.html',
  36 => '/{$catdir}/|/{$catdir}/{$page}.html',
  37 => 'jsj/{$catid}-{$id}-{$page}.html',
  38 => 'english/{$catid}-{$id}-{$page}.html',
  39 => 'zyzg/{$catid}-{$id}-{$page}.html',
);
?>