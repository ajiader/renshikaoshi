<?php
return array (
  19 => 
  array (
    'typeid' => '110',
    'name' => '公务员人事内容',
    'sort' => '0',
  ),
);
?>