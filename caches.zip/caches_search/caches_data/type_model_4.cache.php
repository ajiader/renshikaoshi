<?php
return array (
  19 => '110',
);
?>