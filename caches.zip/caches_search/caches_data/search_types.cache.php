<?php
return array (
  0 => 
  array (
    'typeid' => '61',
    'siteid' => '2',
    'module' => 'search',
    'modelid' => '13',
    'name' => '公务员文章模型',
    'parentid' => '0',
    'typedir' => '',
    'url' => '',
    'template' => '',
    'listorder' => '0',
    'description' => '',
  ),
);
?>