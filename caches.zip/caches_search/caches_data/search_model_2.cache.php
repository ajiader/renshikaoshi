<?php
return array (
  13 => 
  array (
    'typeid' => '61',
    'name' => '公务员文章模型',
    'sort' => '0',
  ),
);
?>