<?php
return array (
  9 => 
  array (
    'id' => '9',
    'siteid' => '2',
    'sitename' => '河北人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/hebei.html',
    'thumb' => '',
    'listorder' => '30',
  ),
  10 => 
  array (
    'id' => '10',
    'siteid' => '2',
    'sitename' => '江苏人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/jiangsu.html',
    'thumb' => '',
    'listorder' => '29',
  ),
  11 => 
  array (
    'id' => '11',
    'siteid' => '2',
    'sitename' => '安徽人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/anhui.html',
    'thumb' => '',
    'listorder' => '28',
  ),
  12 => 
  array (
    'id' => '12',
    'siteid' => '2',
    'sitename' => '山东人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/shandong.html',
    'thumb' => '',
    'listorder' => '27',
  ),
  13 => 
  array (
    'id' => '13',
    'siteid' => '2',
    'sitename' => '上海人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/shanghai.html',
    'thumb' => '',
    'listorder' => '26',
  ),
  14 => 
  array (
    'id' => '14',
    'siteid' => '2',
    'sitename' => '浙江人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/zhejiang.html',
    'thumb' => '',
    'listorder' => '25',
  ),
  15 => 
  array (
    'id' => '15',
    'siteid' => '2',
    'sitename' => '江西人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/jiangxi.html',
    'thumb' => '',
    'listorder' => '24',
  ),
  16 => 
  array (
    'id' => '16',
    'siteid' => '2',
    'sitename' => '福建人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/fujian.html',
    'thumb' => '',
    'listorder' => '23',
  ),
  34 => 
  array (
    'id' => '34',
    'siteid' => '2',
    'sitename' => '西藏人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/xizang.html',
    'thumb' => '',
    'listorder' => '22',
  ),
  8 => 
  array (
    'id' => '8',
    'siteid' => '2',
    'sitename' => '湖北人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/hubei.html',
    'thumb' => '',
    'listorder' => '21',
  ),
  7 => 
  array (
    'id' => '7',
    'siteid' => '2',
    'sitename' => '山西人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/shanxi.html',
    'thumb' => '',
    'listorder' => '20',
  ),
  6 => 
  array (
    'id' => '6',
    'siteid' => '2',
    'sitename' => '天津人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/tianjin.html',
    'thumb' => '',
    'listorder' => '19',
  ),
  5 => 
  array (
    'id' => '5',
    'siteid' => '2',
    'sitename' => '北京人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/beijing.html',
    'thumb' => '',
    'listorder' => '18',
  ),
  17 => 
  array (
    'id' => '17',
    'siteid' => '2',
    'sitename' => '湖南人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/hunan.html',
    'thumb' => '',
    'listorder' => '17',
  ),
  18 => 
  array (
    'id' => '18',
    'siteid' => '2',
    'sitename' => '宁夏人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/ningxia.html',
    'thumb' => '',
    'listorder' => '16',
  ),
  19 => 
  array (
    'id' => '19',
    'siteid' => '2',
    'sitename' => '内蒙古人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/neimenggu.html',
    'thumb' => '',
    'listorder' => '15',
  ),
  33 => 
  array (
    'id' => '33',
    'siteid' => '2',
    'sitename' => '青海人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/qinghai.html',
    'thumb' => '',
    'listorder' => '14',
  ),
  32 => 
  array (
    'id' => '32',
    'siteid' => '2',
    'sitename' => '新疆人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/xinjiang.html',
    'thumb' => '',
    'listorder' => '13',
  ),
  31 => 
  array (
    'id' => '31',
    'siteid' => '2',
    'sitename' => '甘肃人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/gansu.html',
    'thumb' => '',
    'listorder' => '12',
  ),
  30 => 
  array (
    'id' => '30',
    'siteid' => '2',
    'sitename' => '陕西人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/sxs.html',
    'thumb' => '',
    'listorder' => '11',
  ),
  29 => 
  array (
    'id' => '29',
    'siteid' => '2',
    'sitename' => '海南人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/haingwy.html',
    'thumb' => '',
    'listorder' => '10',
  ),
  28 => 
  array (
    'id' => '28',
    'siteid' => '2',
    'sitename' => '广西人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/guangxs.html',
    'thumb' => '',
    'listorder' => '9',
  ),
  27 => 
  array (
    'id' => '27',
    'siteid' => '2',
    'sitename' => '广东人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/guangdong.html',
    'thumb' => '',
    'listorder' => '8',
  ),
  26 => 
  array (
    'id' => '26',
    'siteid' => '2',
    'sitename' => '吉林人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/jilin.html',
    'thumb' => '',
    'listorder' => '7',
  ),
  25 => 
  array (
    'id' => '25',
    'siteid' => '2',
    'sitename' => '辽宁人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/liaoning.html',
    'thumb' => '',
    'listorder' => '6',
  ),
  24 => 
  array (
    'id' => '24',
    'siteid' => '2',
    'sitename' => '云南人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/yunnan.html',
    'thumb' => '',
    'listorder' => '5',
  ),
  23 => 
  array (
    'id' => '23',
    'siteid' => '2',
    'sitename' => '贵州人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/guizhou.html',
    'thumb' => '',
    'listorder' => '4',
  ),
  20 => 
  array (
    'id' => '20',
    'siteid' => '2',
    'sitename' => '河南人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/henan.html',
    'thumb' => '',
    'listorder' => '3',
  ),
  22 => 
  array (
    'id' => '22',
    'siteid' => '2',
    'sitename' => '重庆人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/chongqing.html',
    'thumb' => '',
    'listorder' => '2',
  ),
  21 => 
  array (
    'id' => '21',
    'siteid' => '2',
    'sitename' => '四川人事考试网',
    'siteurl' => 'http://www.kaogwy.com/renshibm/sichuan.html',
    'thumb' => '',
    'listorder' => '1',
  ),
  35 => 
  array (
    'id' => '35',
    'siteid' => '1',
    'sitename' => 'renshikaoshi.net题库',
    'siteurl' => 'http://wwwrenshikaoshi.net/zhiruitiku/',
    'thumb' => '',
    'listorder' => '0',
  ),
  1 => 
  array (
    'id' => '1',
    'siteid' => '1',
    'sitename' => '职考之家',
    'siteurl' => 'http://www.renshikaoshi.net',
    'thumb' => '',
    'listorder' => '0',
  ),
  3 => 
  array (
    'id' => '3',
    'siteid' => '2',
    'sitename' => '博大弘仕国家公务员考试网',
    'siteurl' => 'http://www.kaogwy.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  4 => 
  array (
    'id' => '4',
    'siteid' => '1',
    'sitename' => '人事考试信息网职业资格',
    'siteurl' => 'http://www.renshikaoshi.net/zyzg/',
    'thumb' => '',
    'listorder' => '0',
  ),
  36 => 
  array (
    'id' => '36',
    'siteid' => '1',
    'sitename' => '枣庄人事考试网',
    'siteurl' => 'http://www.renshikaoshi.net/renshibaoming/sdshuzhao.html',
    'thumb' => '',
    'listorder' => '0',
  ),
);
?>