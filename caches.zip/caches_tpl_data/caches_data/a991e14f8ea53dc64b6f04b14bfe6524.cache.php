<?php
return array (
  2824 => 
  array (
    'id' => '2824',
    'catid' => '284',
    'typeid' => '0',
    'title' => '关于领取全国监理工程师初始注册证书及执业印章的通知',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '2100 
     
    注册监理工程师初始人员（5月10日至5月28日窗口受理,详见附件）持单位介绍信或本人身份证原件，到省建设执业资...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/248-2824-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1353651101',
    'updatetime' => '1422005121',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-2824',
    'views' => '315',
    'yesterdayviews' => '1',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  92788 => 
  array (
    'id' => '92788',
    'catid' => '284',
    'typeid' => '0',
    'title' => '上海市会计系列高级专业技术职务任职资格评审委员会评审通过高级会计师名单公示',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '




序 号

姓 名

工 作 单 位


1

刘佳涵

上海建工七建集团有限公司


2

柴晓霞

上海市城市建设投资开发总公司


3

衣杰

上...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-92788-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1357820625',
    'updatetime' => '1422543296',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-92788',
    'views' => '210',
    'yesterdayviews' => '2',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  107245 => 
  array (
    'id' => '107245',
    'catid' => '284',
    'typeid' => '0',
    'title' => '陕西省农民专业合作社百强示范社名单（238家）',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '

    
        
            
            陕西省农民专业合作社百强示范社名单（238家）
    ...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-107245-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1368619326',
    'updatetime' => '1422031227',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-107245',
    'views' => '205',
    'yesterdayviews' => '3',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  97333 => 
  array (
    'id' => '97333',
    'catid' => '284',
    'typeid' => '0',
    'title' => '免试名单：2013年度注册咨询师考试免试复核通过人员名单',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '
                                            
                    ...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-97333-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1360022808',
    'updatetime' => '1422538452',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-97333',
    'views' => '177',
    'yesterdayviews' => '1',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  93940 => 
  array (
    'id' => '93940',
    'catid' => '284',
    'typeid' => '0',
    'title' => '2013年南京二级建造师执业资格考试通知  ',
    'style' => '',
    'thumb' => '/uploadfile/2013/0115/20130115113949450.jpg',
    'keywords' => '2013年 南京 二级',
    'description' => '南京市2013年度二级建造师执业资格考试报名时间为2013年1月11日—2月21日。',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/245-93940-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1358208484',
    'updatetime' => '1413225529',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-93940',
    'views' => '172',
    'yesterdayviews' => '1',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  11219 => 
  array (
    'id' => '11219',
    'catid' => '284',
    'typeid' => '0',
    'title' => '山西省卫生厅转发卫生部关于内科执业医师出具心电图诊断报告单有关问题的批复的通知',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '                                                                 ...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/226-11219-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1353663253',
    'updatetime' => '1422034941',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-11219',
    'views' => '153',
    'yesterdayviews' => '1',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  76024 => 
  array (
    'id' => '76024',
    'catid' => '284',
    'typeid' => '0',
    'title' => '关于更新政府性债务系统管理公告',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => ' 为贯彻落实国家财政部、省财政厅关于推广运用财政部地方政府性债务管理系统的有关精神，在全市推广使用财政部地方政府性债务管理系统（文...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-76024-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1355975656',
    'updatetime' => '1422009825',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-76024',
    'views' => '130',
    'yesterdayviews' => '2',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  78896 => 
  array (
    'id' => '78896',
    'catid' => '284',
    'typeid' => '0',
    'title' => '临沂市会计准则制度有奖问答试题',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '临沂市会计准则制度有奖问答试题答题须知：1、除特殊说明外，所有题目所称&ldquo;企业&rdquo;或&ldquo;公司&rdquo;，均是指符合国家规定标准，应执行企业内控规...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-78896-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1355977501',
    'updatetime' => '1422843381',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-78896',
    'views' => '126',
    'yesterdayviews' => '2',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  101239 => 
  array (
    'id' => '101239',
    'catid' => '284',
    'typeid' => '0',
    'title' => '第二批市直继续教育会计从业资格证书领取人员名单',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => ' 请以下人员首先阅读衡水市财政局关于领取市直参加继续教育会计从业资格证书的通知（网站通知公告第三条）后3月11日至3月22日期间(正常工...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/284-101239-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1363004072',
    'updatetime' => '1422057576',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-101239',
    'views' => '123',
    'yesterdayviews' => '2',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
);
?>