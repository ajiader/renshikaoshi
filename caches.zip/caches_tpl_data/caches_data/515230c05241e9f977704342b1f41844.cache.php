<?php
return array (
  196690 => 
  array (
    'id' => '196690',
    'catid' => '924',
    'typeid' => '98',
    'title' => '吉林省第一批住院医师规范化培训基地、专业基地及协同医院名单',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/924-196690-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'wangnan',
    'inputtime' => '1419485723',
    'updatetime' => '1422664193',
    'city_id' => '10',
    'mid' => '',
    'hitsid' => 'c-1-196690',
    'views' => '5',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '2',
    'monthviews' => '2',
  ),
);
?>