<?php
return array (
  0 => 
  array (
    'linkageid' => '2',
    'name' => '北京市',
    'pinyin' => 'beijing',
  ),
  1 => 
  array (
    'linkageid' => '4',
    'name' => '天津市',
    'pinyin' => 'tianjin',
  ),
  2 => 
  array (
    'linkageid' => '6',
    'name' => '河北省',
    'pinyin' => 'hebei',
  ),
  3 => 
  array (
    'linkageid' => '7',
    'name' => '山西省',
    'pinyin' => 'shanxi',
  ),
  4 => 
  array (
    'linkageid' => '19',
    'name' => '湖北省',
    'pinyin' => 'hubei',
  ),
  5 => 
  array (
    'linkageid' => '12',
    'name' => '江苏省',
    'pinyin' => 'jiangshu',
  ),
  6 => 
  array (
    'linkageid' => '14',
    'name' => '安徽省',
    'pinyin' => 'anhui',
  ),
  7 => 
  array (
    'linkageid' => '17',
    'name' => '山东省',
    'pinyin' => 'shandong',
  ),
  8 => 
  array (
    'linkageid' => '3',
    'name' => '上海市',
    'pinyin' => 'shanghai',
  ),
  9 => 
  array (
    'linkageid' => '13',
    'name' => '浙江省',
    'pinyin' => 'zhejiang',
  ),
  10 => 
  array (
    'linkageid' => '16',
    'name' => '江西省',
    'pinyin' => 'jiangxi',
  ),
  11 => 
  array (
    'linkageid' => '15',
    'name' => '福建省',
    'pinyin' => 'fujian',
  ),
  12 => 
  array (
    'linkageid' => '20',
    'name' => '湖南省',
    'pinyin' => 'hunan',
  ),
  13 => 
  array (
    'linkageid' => '31',
    'name' => '宁夏',
    'pinyin' => 'ningxia',
  ),
);
?>