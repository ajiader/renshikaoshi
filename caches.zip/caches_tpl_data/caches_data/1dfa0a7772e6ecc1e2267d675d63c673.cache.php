<?php
return array (
  196949 => 
  array (
    'id' => '196949',
    'catid' => '420',
    'typeid' => '0',
    'title' => '福建省2015年职称英语报名时间安排公告',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/english/420-196949-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'renchunli',
    'inputtime' => '1419927646',
    'updatetime' => '1419927742',
    'city_id' => '15',
    'mid' => '',
  ),
);
?>