<?php
return array (
  195505 => 
  array (
    'id' => '195505',
    'catid' => '915',
    'typeid' => '71',
    'title' => '2014年辽宁省政法干警招考(招生)公安系统面试人选的公告',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/915-195505-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'wangnan',
    'inputtime' => '1417066619',
    'updatetime' => '1418550009',
    'city_id' => '9',
    'mid' => '',
    'hitsid' => 'c-1-195505',
    'views' => '1',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
);
?>