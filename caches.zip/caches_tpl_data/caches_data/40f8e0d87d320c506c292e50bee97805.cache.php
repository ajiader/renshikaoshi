<?php
return array (
  0 => 
  array (
    'qid' => '14940',
    'question' => '职称英语自学效果怎么样？',
    'url' => 'http://www.renshikaoshi.net/question/14940.html',
    'ip' => '',
    'catid' => '3',
    'aid' => '14586',
    'zid' => '0',
    'siteid' => '1',
    'content' => '<p>　　<span style="color:#ff0000;"><strong>更多职称英语信息</strong></span></p><p><br /></p><p>　　<span style="font-size:10px;color:#990000;">●</span><a href="http://www.renshikaoshi.net/question/14587.html" target="_blank">职称英语考试如何报名?</a></p><p><br /></p><p>　　<span style="font-size:10px;color:#990000;">●</span><a href="http://www.renshikaoshi.net/question/14585.html" target="_blank">2014年称英语考试如何备考?</a></p><p><br /></p><p>　　<span style="font-size:10px;color:#990000;">●</span><a href="http://www.renshikaoshi.net/question/14584.html" target="_blank">职称英语考试考哪些内容?</a></p><p><br /></p><p>　　<span style="font-size:10px;color:#990000;">●</span><a href="http://www.renshikaoshi.net/question/14586.html" target="_blank">职称英语考试难度大吗?</a></p><p><br /></p><p>　　<span style="font-size:10px;color:#990000;">●</span><a href="http://www.renshikaoshi.net/question/14544.html" target="_blank">职称英语应试技巧是什么?</a> </p><p><br /></p><p>　　2014年职称英语考试时间将近，相信考生们都已进入紧张的复习阶段，而复习备考不仅需要时间更需要适合的复习方法，那么什么样的方法才对考试有帮助呢?下面我们来看看。</p><p><br /></p><p>　　首先，大部分考生都属于基础较差的，都想通过参加面授班来系统学习，掌握知识。但是面授班的学习时间比较固定，对于上班的考生来说，还要在下班后匆忙地赶时间上课，路途中便会浪费大量的时间，且培训时间短，学费昂贵，受到这种种条件的限制，能参加面授培训考生少之又少。因此，大部分考生可能会选择自学，但是，自学真的会有好的效果吗，答题是否定的，特别是对于基础差的考生更是不可能通过考试，原因很简单，职称英语考试并非没有难度，而考生大多已经将英语知识遗忘，想在短短两三月就来个突飞猛进的提高是不可能的，并且在没有人监督学习的情况下，很容易就产生惰性，大多考生都无法坚持到最后。可见，自学并不是人人都适合的，基础较好的考生可以尝试，但是基础差的考生就一定得花更多时间和努力才有可能通过考试。</p><p><br /></p><p>　　努力也要找对方向才会成功，既然无法靠自学来通过考试，那么就需要选择其它适合的方式，怎么的方式是适合的呢，即能在家学习又有人监督是最好不过了，考试宝典<a href="http://www.renshikaoshi.net/download/zhichenyingyu/#zxwdcp1" target="_blank"><span style="color:#ff0000;"><strong>职称英语家庭式培训班</strong></span></a>真正做到了这一点，充分运用面授班与网校的优势，考生在家就可以学习，上班的空闲时间也可以学习，这样便可以充分利用时间，另外，培训班中有班主任老师监督学习，提醒考生学习进度，考生有任何疑问也可咨询班主任老师，实现了互动学习，培训班主要教授考生答题技巧，考生只要每天学习一点，通过长期的积累，便能完全掌握技巧要点，然后在考试中运用技巧答题，考生不记单词不学语法便能轻松通过考试，对于基础差的考生来说是最适合不过的选择。</p><p><br /></p><p><img src="/uploadfile/2013/1218/20131218052001547.jpg" title="12-10在线问答用.jpg" /><br /></p><p><br /></p><p>　　记单词太难，上班太忙，面授班时间太短，如何通过职称英语?考试宝典职称英语家庭式培训班，把面授带回家，不用背单词记语法，随时随地学，掌握技巧即可通关。<a href="http://www.renshikaoshi.net/download/zhichenyingyu/#zxwdcp2" target="_blank"><span style="color:#ff0000;"><strong>点击查看&gt;&gt;</strong></span></a></p><p><br /></p>',
    'userid' => '0',
    'status' => '0',
    'updatetime' => '1387358462',
    'addtime' => '1387358462',
  ),
  1 => 
  array (
    'qid' => '14939',
    'question' => '请问职称英语一年考几次？',
    'url' => 'http://www.renshikaoshi.net/question/14939.html',
    'ip' => '',
    'catid' => '3',
    'aid' => '14581',
    'zid' => '0',
    'siteid' => '1',
    'content' => '<p>
&nbsp;&nbsp;&nbsp;&nbsp;职称英语考试每年一次，全国统考。报名时间一般在前一年11月底到12月初报名，考试一般在每年3月底或4月初举行，A&nbsp;、B&nbsp;、C&nbsp;三个等级考试的总分各为100分，考试时间均为2小时。评职称，涨工资！不过职称英语怎么行？考试宝典职称英语家庭式培训班，零基础保过，不过退全款！
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;<br />
</p>',
    'userid' => '0',
    'status' => '0',
    'updatetime' => '1387357881',
    'addtime' => '1387357881',
  ),
  2 => 
  array (
    'qid' => '14938',
    'question' => '济南2014年职称英语可以补报名吗，之前报名我错过了？',
    'url' => 'http://www.renshikaoshi.net/question/14938.html',
    'ip' => '',
    'catid' => '3',
    'aid' => '14582',
    'zid' => '0',
    'siteid' => '1',
    'content' => '<p>
&nbsp;&nbsp;&nbsp;&nbsp;你好，可以的，济南市补报名时间为2013年12月18日9:00至2013年12月20日16:00，请关注本站开通报名入口，切勿再次错过。
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;记单词太难，上班太忙，面授班时间太短，如何通过职称英语？考试宝典职称英语家庭式培训班，把面授带回家，无需要背单词记语法，学会技巧即可通关。
</p>
<p>
&nbsp;&nbsp;&nbsp;&nbsp;<br />
</p>',
    'userid' => '0',
    'status' => '0',
    'updatetime' => '1387357920',
    'addtime' => '1387357920',
  ),
  3 => 
  array (
    'qid' => '14937',
    'question' => '我基础比较差，已经扔下二十多年了，怎么能过职称英语？',
    'url' => 'http://www.renshikaoshi.net/question/14937.html',
    'ip' => '',
    'catid' => '3',
    'aid' => '14583',
    'zid' => '0',
    'siteid' => '1',
    'content' => '<p>你好，英语考试并不难，通过率低的原因主要是学习时间不容易保障，会有学习中断的情况，考试宝典职称英语家庭式培训班的学习方式是非常符合基础薄弱考生的，在家就能学，并且有班主任督导，考试更容易通过。<a href="http://www.renshikaoshi.net/download/zhichenyingyu/#zxwd" target="_blank"><span style="color:#ff0000;"><strong>点击免费试听&gt;&gt;</strong></span></a></p><p><br /></p>',
    'userid' => '0',
    'status' => '0',
    'updatetime' => '1387357954',
    'addtime' => '1387357954',
  ),
);
?>