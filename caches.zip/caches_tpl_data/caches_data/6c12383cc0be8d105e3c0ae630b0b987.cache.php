<?php
return array (
  0 => 
  array (
    'linkageid' => '2',
    'name' => '北京市',
    'pinyin' => 'beijing',
  ),
  1 => 
  array (
    'linkageid' => '4',
    'name' => '天津市',
    'pinyin' => 'tianjin',
  ),
  2 => 
  array (
    'linkageid' => '6',
    'name' => '河北省',
    'pinyin' => 'hebei',
  ),
  3 => 
  array (
    'linkageid' => '7',
    'name' => '山西省',
    'pinyin' => 'shanxi',
  ),
  4 => 
  array (
    'linkageid' => '19',
    'name' => '湖北省',
    'pinyin' => 'hubei',
  ),
  5 => 
  array (
    'linkageid' => '12',
    'name' => '江苏省',
    'pinyin' => 'jiangshu',
  ),
  6 => 
  array (
    'linkageid' => '14',
    'name' => '安徽省',
    'pinyin' => 'anhui',
  ),
  7 => 
  array (
    'linkageid' => '17',
    'name' => '山东省',
    'pinyin' => 'shandong',
  ),
  8 => 
  array (
    'linkageid' => '3',
    'name' => '上海市',
    'pinyin' => 'shanghai',
  ),
  9 => 
  array (
    'linkageid' => '13',
    'name' => '浙江省',
    'pinyin' => 'zhejiang',
  ),
  10 => 
  array (
    'linkageid' => '16',
    'name' => '江西省',
    'pinyin' => 'jiangxi',
  ),
  11 => 
  array (
    'linkageid' => '15',
    'name' => '福建省',
    'pinyin' => 'fujian',
  ),
  12 => 
  array (
    'linkageid' => '20',
    'name' => '湖南省',
    'pinyin' => 'hunan',
  ),
  13 => 
  array (
    'linkageid' => '31',
    'name' => '宁夏',
    'pinyin' => 'ningxia',
  ),
  14 => 
  array (
    'linkageid' => '8',
    'name' => '内蒙古',
    'pinyin' => 'neimenggu',
  ),
  15 => 
  array (
    'linkageid' => '18',
    'name' => '河南省',
    'pinyin' => 'henan',
  ),
  16 => 
  array (
    'linkageid' => '24',
    'name' => '四川省',
    'pinyin' => 'sichuan',
  ),
  17 => 
  array (
    'linkageid' => '5',
    'name' => '重庆市',
    'pinyin' => 'chongqing',
  ),
  18 => 
  array (
    'linkageid' => '25',
    'name' => '贵州省',
    'pinyin' => 'guizhou',
  ),
  19 => 
  array (
    'linkageid' => '26',
    'name' => '云南省',
    'pinyin' => 'yunnan',
  ),
  20 => 
  array (
    'linkageid' => '9',
    'name' => '辽宁省',
    'pinyin' => 'liaoning',
  ),
  21 => 
  array (
    'linkageid' => '10',
    'name' => '吉林省',
    'pinyin' => 'jilin',
  ),
  22 => 
  array (
    'linkageid' => '21',
    'name' => '广东省',
    'pinyin' => 'guangdong',
  ),
  23 => 
  array (
    'linkageid' => '22',
    'name' => '广西',
    'pinyin' => 'guangxi',
  ),
  24 => 
  array (
    'linkageid' => '23',
    'name' => '海南省',
    'pinyin' => 'hainan',
  ),
  25 => 
  array (
    'linkageid' => '28',
    'name' => '陕西省',
    'pinyin' => 'shanxis',
  ),
  26 => 
  array (
    'linkageid' => '29',
    'name' => '甘肃省',
    'pinyin' => 'gansu',
  ),
  27 => 
  array (
    'linkageid' => '32',
    'name' => '新疆',
    'pinyin' => 'xinjiang',
  ),
  28 => 
  array (
    'linkageid' => '30',
    'name' => '青海省',
    'pinyin' => 'qinghai',
  ),
  29 => 
  array (
    'linkageid' => '27',
    'name' => '西藏',
    'pinyin' => 'xizang',
  ),
  30 => 
  array (
    'linkageid' => '11',
    'name' => '黑龙江省',
    'pinyin' => 'heilongjiang',
  ),
);
?>