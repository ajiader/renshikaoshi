<?php
return array (
  91259 => 
  array (
    'id' => '91259',
    'catid' => '295',
    'typeid' => '0',
    'title' => '保险公估人资格认定制度应该改革',
    'style' => '',
    'thumb' => '',
    'keywords' => '保险 资格认定 制度',
    'description' => '参加保险公估人从业资格考试者的学历不能太低，至少应为大专学历，凡通过保险公估人从业资格考试者，均可获得监管部门颁发的《公估师资格证书》。',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/zyzg/295-91259-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'lidechuan',
    'inputtime' => '1357454444',
    'updatetime' => '1386165795',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-91259',
    'views' => '17',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
);
?>