<?php
return array (
  126104 => 
  array (
    'id' => '126104',
    'catid' => '488',
    'typeid' => '71',
    'title' => '北京2014年全国注册化工工程师执业资格考试报名时间|考试时间|考试地点',
    'style' => '',
    'thumb' => '',
    'keywords' => '执业资格 考试时间 北京',
    'description' => '',
    'posids' => '1',
    'url' => 'http://www.renshikaoshi.net/zyzg/488-126104-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'denghongyu',
    'inputtime' => '1401960007',
    'updatetime' => '1420081668',
    'city_id' => '2',
    'mid' => '',
    'hitsid' => 'c-1-126104',
    'views' => '3',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
);
?>