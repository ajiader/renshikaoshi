<?php
return array (
  125706 => 
  array (
    'id' => '125706',
    'catid' => '283',
    'typeid' => '0',
    'title' => '贵州省直考区2014年5月职称计算机考试地点',
    'style' => '',
    'thumb' => '',
    'keywords' => '考区 省直 贵州',
    'description' => '',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-125706-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'caiji1',
    'inputtime' => '1399426367',
    'updatetime' => '1413454529',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-125706',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  125887 => 
  array (
    'id' => '125887',
    'catid' => '283',
    'typeid' => '0',
    'title' => '关于做好2014年度全国专业技术人员职称外语等级统一考试用书服务工作有关问题的通知',
    'style' => '',
    'thumb' => 'images/dot.gif',
    'keywords' => '',
    'description' => '
    鲁人考函〔2013〕60号各市人事考试中心，省直及中央驻济有关部门（单位），各大企业，各高等院校： 
 根据人力资源社会保障部人...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-125887-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1400235081',
    'updatetime' => '1421086451',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-125887',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127142 => 
  array (
    'id' => '127142',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度注册测绘师资格考试网上报名专题',
    'style' => '',
    'thumb' => '../ewebeditor/SysImage/file/zip.gif',
    'keywords' => '',
    'description' => '
               重要提示：报名注册登记前，请先到中国人事考试网(www.cpta.com.cn)或本地下载照片处理工具对报名照片进行...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127142-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825099',
    'updatetime' => '1415902954',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127142',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127144 => 
  array (
    'id' => '127144',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度全国房地产估价师、房地产经纪人执业资格网上报名专题',
    'style' => '',
    'thumb' => '/uploadfile/2014/0708/20140708091151616.gif',
    'keywords' => '',
    'description' => '
               重要提示
由于系统升级，原定2014年度房地产经纪人、房地产估价师资格考试报名老考生及新考生报名程序无效...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127144-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825110',
    'updatetime' => '1413832601',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127144',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '2',
  ),
  127147 => 
  array (
    'id' => '127147',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度执业药师资格考试江西考区网上报名专题',
    'style' => '',
    'thumb' => '/uploadfile/2014/0708/20140708091203526.gif',
    'keywords' => '',
    'description' => '
               特别提示：
全国执业药师资格考试为滚动考试
 （1）参加全部4个科目考试的人员必须在连续2个考试年度内通...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127147-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825123',
    'updatetime' => '1418740411',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127147',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127151 => 
  array (
    'id' => '127151',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度一级建造师及相应专业资格考试网上报名专题',
    'style' => '',
    'thumb' => '/uploadfile/2014/0708/20140708091217485.gif',
    'keywords' => '',
    'description' => '
               



特别提示：
全国注册一级建造师考试为滚动考试
全国一级建造师相应专业为非滚动考试
（1）一级建造师...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127151-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825137',
    'updatetime' => '1419908249',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127151',
    'views' => '2',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  125853 => 
  array (
    'id' => '125853',
    'catid' => '283',
    'typeid' => '0',
    'title' => '关于2014年度东营考区计算机应用能力考试第二批报名有关问题的通知',
    'style' => '',
    'thumb' => '',
    'keywords' => '',
    'description' => '各县、区人力资源和社会保障局，市直有关部门，中央、省属驻东营有关单位： 现将2014年度东营考区计算机应用能力第二批考试报名有关事宜通...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-125853-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1399972706',
    'updatetime' => '1411018605',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-125853',
    'views' => '1',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127143 => 
  array (
    'id' => '127143',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年江西省统计专业（初、中、高级）技术资格考试网上报名专题',
    'style' => '',
    'thumb' => '/uploadfile/2014/0708/20140708091144537.gif',
    'keywords' => '',
    'description' => '
               



  

















 
时间安排











网上注册登记时间为：2014年7月1日9:00-7日17:00 
现...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127143-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825103',
    'updatetime' => '1413886355',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127143',
    'views' => '1',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127145 => 
  array (
    'id' => '127145',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度企业法律顾问执业资格考试网上报名专题',
    'style' => '',
    'thumb' => '../ewebeditor/SysImage/file/zip.gif',
    'keywords' => '',
    'description' => '
               重要提示：报名注册登记前，请先到中国人事考试网(www.cpta.com.cn)或本地下载照片处理工具对报名照片进行...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127145-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825111',
    'updatetime' => '1413907860',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127145',
    'views' => '1',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
  127146 => 
  array (
    'id' => '127146',
    'catid' => '283',
    'typeid' => '0',
    'title' => '2014年度江西省国际商务专业人员职业资格考试网上报名专题',
    'style' => '',
    'thumb' => '../ewebeditor/SysImage/file/zip.gif',
    'keywords' => '',
    'description' => '
               重要提示：报名注册登记前，请先到中国人事考试网(www.cpta.com.cn)或本地下载照片处理工具对报名照片进行...',
    'posids' => '0',
    'url' => 'http://www.renshikaoshi.net/jsj/283-127146-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => '',
    'inputtime' => '1404825116',
    'updatetime' => '1414312011',
    'city_id' => '0',
    'mid' => '',
    'hitsid' => 'c-1-127146',
    'views' => '1',
    'yesterdayviews' => '0',
    'dayviews' => '1',
    'weekviews' => '1',
    'monthviews' => '1',
  ),
);
?>