<?php
return array (
  0 => 
  array (
    'linkageid' => '8',
    'name' => '内蒙古',
    'pinyin' => 'neimenggu',
  ),
  1 => 
  array (
    'linkageid' => '18',
    'name' => '河南省',
    'pinyin' => 'henan',
  ),
  2 => 
  array (
    'linkageid' => '24',
    'name' => '四川省',
    'pinyin' => 'sichuan',
  ),
  3 => 
  array (
    'linkageid' => '5',
    'name' => '重庆市',
    'pinyin' => 'chongqing',
  ),
  4 => 
  array (
    'linkageid' => '25',
    'name' => '贵州省',
    'pinyin' => 'guizhou',
  ),
  5 => 
  array (
    'linkageid' => '26',
    'name' => '云南省',
    'pinyin' => 'yunnan',
  ),
  6 => 
  array (
    'linkageid' => '9',
    'name' => '辽宁省',
    'pinyin' => 'liaoning',
  ),
  7 => 
  array (
    'linkageid' => '10',
    'name' => '吉林省',
    'pinyin' => 'jilin',
  ),
  8 => 
  array (
    'linkageid' => '21',
    'name' => '广东省',
    'pinyin' => 'guangdong',
  ),
  9 => 
  array (
    'linkageid' => '22',
    'name' => '广西',
    'pinyin' => 'guangxi',
  ),
  10 => 
  array (
    'linkageid' => '23',
    'name' => '海南省',
    'pinyin' => 'hainan',
  ),
  11 => 
  array (
    'linkageid' => '28',
    'name' => '陕西省',
    'pinyin' => 'shanxis',
  ),
  12 => 
  array (
    'linkageid' => '29',
    'name' => '甘肃省',
    'pinyin' => 'gansu',
  ),
  13 => 
  array (
    'linkageid' => '32',
    'name' => '新疆',
    'pinyin' => 'xinjiang',
  ),
  14 => 
  array (
    'linkageid' => '30',
    'name' => '青海省',
    'pinyin' => 'qinghai',
  ),
  15 => 
  array (
    'linkageid' => '27',
    'name' => '西藏',
    'pinyin' => 'xizang',
  ),
  16 => 
  array (
    'linkageid' => '11',
    'name' => '黑龙江省',
    'pinyin' => 'heilongjiang',
  ),
);
?>