<?php
return array (
  0 => 
  array (
    'id' => '4',
    'typeid' => '3372',
    'name' => '内科护理（高级）',
    'pinyin' => 'nkhlgj',
  ),
  1 => 
  array (
    'id' => '5',
    'typeid' => '3372',
    'name' => '外科护理（高级）',
    'pinyin' => 'wkhlgj',
  ),
  2 => 
  array (
    'id' => '6',
    'typeid' => '3372',
    'name' => '妇产科护理（高级）',
    'pinyin' => 'fckhlgj',
  ),
  3 => 
  array (
    'id' => '7',
    'typeid' => '3372',
    'name' => '儿科护理（高级）',
    'pinyin' => 'ekhlgj',
  ),
  4 => 
  array (
    'id' => '8',
    'typeid' => '3372',
    'name' => '中医护理（高级）',
    'pinyin' => 'zyhlgj',
  ),
  5 => 
  array (
    'id' => '9',
    'typeid' => '3372',
    'name' => '急救护理（高级）',
    'pinyin' => 'jjhlgj',
  ),
  6 => 
  array (
    'id' => '10',
    'typeid' => '3372',
    'name' => '口腔医学（高级）',
    'pinyin' => 'kqyxgj',
  ),
  7 => 
  array (
    'id' => '11',
    'typeid' => '3372',
    'name' => '口腔内科（高级）',
    'pinyin' => 'kqnkgj',
  ),
  8 => 
  array (
    'id' => '12',
    'typeid' => '3372',
    'name' => '口腔颌面外科（高级）',
    'pinyin' => 'kqemwkgj',
  ),
  9 => 
  array (
    'id' => '13',
    'typeid' => '3372',
    'name' => '口腔修复（高级）',
    'pinyin' => 'kqxfgj',
  ),
  10 => 
  array (
    'id' => '14',
    'typeid' => '3372',
    'name' => '口腔正畸（高级）',
    'pinyin' => 'kqzjgj',
  ),
  11 => 
  array (
    'id' => '15',
    'typeid' => '3372',
    'name' => '中医内科（高级）',
    'pinyin' => 'zynkgj',
  ),
  12 => 
  array (
    'id' => '16',
    'typeid' => '3372',
    'name' => '中医外科（高级）',
    'pinyin' => 'zywkgj',
  ),
  13 => 
  array (
    'id' => '17',
    'typeid' => '3372',
    'name' => '中医妇科（高级）',
    'pinyin' => 'zyfkgj',
  ),
  14 => 
  array (
    'id' => '18',
    'typeid' => '3372',
    'name' => '中医儿科（高级）',
    'pinyin' => 'zyekgj',
  ),
  15 => 
  array (
    'id' => '19',
    'typeid' => '3372',
    'name' => '中医眼科（高级）',
    'pinyin' => 'zyykgj',
  ),
  16 => 
  array (
    'id' => '20',
    'typeid' => '3372',
    'name' => '中医骨伤科（高级）',
    'pinyin' => 'zygskgj',
  ),
  17 => 
  array (
    'id' => '21',
    'typeid' => '3372',
    'name' => '中医针灸科（高级）',
    'pinyin' => 'zyzjkgj',
  ),
  18 => 
  array (
    'id' => '22',
    'typeid' => '3372',
    'name' => '中医耳鼻喉科（高级）',
    'pinyin' => 'zyebhkgj',
  ),
  19 => 
  array (
    'id' => '23',
    'typeid' => '3372',
    'name' => '中医皮肤与性病学（高级）',
    'pinyin' => 'zypfyxbxuegj',
  ),
  20 => 
  array (
    'id' => '24',
    'typeid' => '3372',
    'name' => '中医肛肠（高级）',
    'pinyin' => 'zygcgj',
  ),
  21 => 
  array (
    'id' => '25',
    'typeid' => '3372',
    'name' => '中医推拿（高级）',
    'pinyin' => 'zytngj',
  ),
  22 => 
  array (
    'id' => '26',
    'typeid' => '3372',
    'name' => '中西医结合外科（高级）',
    'pinyin' => 'zxyjhwkgj',
  ),
  23 => 
  array (
    'id' => '27',
    'typeid' => '3372',
    'name' => '中西医结合妇科（高级）',
    'pinyin' => 'zxyjhfkgj',
  ),
  24 => 
  array (
    'id' => '28',
    'typeid' => '3372',
    'name' => '中西医结合儿科（高级）',
    'pinyin' => 'zxyjhekgj',
  ),
  25 => 
  array (
    'id' => '29',
    'typeid' => '3372',
    'name' => '职业卫生（高级）',
    'pinyin' => 'zywsgj',
  ),
  26 => 
  array (
    'id' => '30',
    'typeid' => '3372',
    'name' => '环境卫生（高级）',
    'pinyin' => 'hjwsgj',
  ),
  27 => 
  array (
    'id' => '31',
    'typeid' => '3372',
    'name' => '营养与食品卫生（高级）',
    'pinyin' => 'yyyspwsgj',
  ),
  28 => 
  array (
    'id' => '32',
    'typeid' => '3372',
    'name' => '学校卫生与儿少卫生（高级）',
    'pinyin' => 'xxwsysews',
  ),
  29 => 
  array (
    'id' => '33',
    'typeid' => '3372',
    'name' => '放射卫生（高级）',
    'pinyin' => 'fswsgj',
  ),
  30 => 
  array (
    'id' => '34',
    'typeid' => '3372',
    'name' => '传染性疾病控制（高级）',
    'pinyin' => 'crxjbkzgj',
  ),
  31 => 
  array (
    'id' => '35',
    'typeid' => '3372',
    'name' => '慢性非传染性疾病控制（高级）',
    'pinyin' => 'mxfcrxjbkzgji',
  ),
  32 => 
  array (
    'id' => '36',
    'typeid' => '3372',
    'name' => '寄生虫病控制（高级）',
    'pinyin' => 'jscbkzgj',
  ),
  33 => 
  array (
    'id' => '37',
    'typeid' => '3372',
    'name' => '健康教育与健康促进（高级）',
    'pinyin' => 'jkjyyjkzjgj',
  ),
  34 => 
  array (
    'id' => '38',
    'typeid' => '3372',
    'name' => '卫生毒理（高级）',
    'pinyin' => 'wsdlgj',
  ),
  35 => 
  array (
    'id' => '39',
    'typeid' => '3372',
    'name' => '妇女保健（高级）',
    'pinyin' => 'fnbjgj',
  ),
  36 => 
  array (
    'id' => '40',
    'typeid' => '3372',
    'name' => '儿童保健（高级）',
    'pinyin' => 'etbjgj',
  ),
  37 => 
  array (
    'id' => '41',
    'typeid' => '3372',
    'name' => '全科医学（高级）',
    'pinyin' => 'qkyxgj',
  ),
  38 => 
  array (
    'id' => '42',
    'typeid' => '3372',
    'name' => '心血管内科（高级）',
    'pinyin' => 'xxgnkgj',
  ),
  39 => 
  array (
    'id' => '43',
    'typeid' => '3372',
    'name' => '呼吸内科（高级）',
    'pinyin' => 'hxnkgj',
  ),
  40 => 
  array (
    'id' => '44',
    'typeid' => '3372',
    'name' => '肾内科（高级）',
    'pinyin' => 'snkgj',
  ),
  41 => 
  array (
    'id' => '45',
    'typeid' => '3372',
    'name' => '内分泌（高级）',
    'pinyin' => 'nfmgj',
  ),
  42 => 
  array (
    'id' => '46',
    'typeid' => '3372',
    'name' => '血液病（高级）',
    'pinyin' => 'xybgj',
  ),
  43 => 
  array (
    'id' => '47',
    'typeid' => '3372',
    'name' => '传染病（高级）',
    'pinyin' => 'crbgj',
  ),
  44 => 
  array (
    'id' => '48',
    'typeid' => '3372',
    'name' => '风湿病（高级）',
    'pinyin' => 'fsbgj',
  ),
  45 => 
  array (
    'id' => '49',
    'typeid' => '3372',
    'name' => '胸心外科（高级）',
    'pinyin' => 'xxwk',
  ),
  46 => 
  array (
    'id' => '50',
    'typeid' => '3372',
    'name' => '神经外科（高级）',
    'pinyin' => 'sjwkgj',
  ),
  47 => 
  array (
    'id' => '51',
    'typeid' => '3372',
    'name' => '泌尿外科（高级）',
    'pinyin' => 'mnwkgj',
  ),
  48 => 
  array (
    'id' => '52',
    'typeid' => '3372',
    'name' => '烧伤外科（高级）',
    'pinyin' => 'sswkgj',
  ),
  49 => 
  array (
    'id' => '53',
    'typeid' => '3372',
    'name' => '整形外科（高级）',
    'pinyin' => 'zxwkgj',
  ),
  50 => 
  array (
    'id' => '54',
    'typeid' => '3372',
    'name' => '小儿外科（高级）',
    'pinyin' => 'xewkgj',
  ),
  51 => 
  array (
    'id' => '55',
    'typeid' => '3372',
    'name' => '骨外科（高级）',
    'pinyin' => 'gwkgj',
  ),
  52 => 
  array (
    'id' => '56',
    'typeid' => '3372',
    'name' => '眼科（高级）',
    'pinyin' => 'ykgj',
  ),
  53 => 
  array (
    'id' => '57',
    'typeid' => '3372',
    'name' => '耳鼻咽喉科（高级）',
    'pinyin' => 'ebyhkgj',
  ),
  54 => 
  array (
    'id' => '58',
    'typeid' => '3372',
    'name' => '皮肤与性病学（高级）',
    'pinyin' => 'zypfyxbxuegj',
  ),
  55 => 
  array (
    'id' => '59',
    'typeid' => '3372',
    'name' => '肿瘤内科（高级）',
    'pinyin' => 'znnkgji',
  ),
  56 => 
  array (
    'id' => '60',
    'typeid' => '3372',
    'name' => '肿瘤外科（高级）',
    'pinyin' => 'zlwkgj',
  ),
  57 => 
  array (
    'id' => '61',
    'typeid' => '3372',
    'name' => '放射肿瘤治疗学（高级）',
    'pinyin' => 'fszlzlxgj',
  ),
  58 => 
  array (
    'id' => '62',
    'typeid' => '3372',
    'name' => '急诊医学（高级）',
    'pinyin' => 'jzyxgj',
  ),
  59 => 
  array (
    'id' => '63',
    'typeid' => '3372',
    'name' => '麻醉学（高级）',
    'pinyin' => 'mzxgj',
  ),
  60 => 
  array (
    'id' => '64',
    'typeid' => '3372',
    'name' => '病理学（高级）',
    'pinyin' => 'blxgj',
  ),
  61 => 
  array (
    'id' => '65',
    'typeid' => '3372',
    'name' => '放射医学（高级）',
    'pinyin' => 'fsyxgj',
  ),
  62 => 
  array (
    'id' => '66',
    'typeid' => '3372',
    'name' => '核医学（高级）',
    'pinyin' => 'hyxgj',
  ),
  63 => 
  array (
    'id' => '67',
    'typeid' => '3372',
    'name' => '超声医学（高级）',
    'pinyin' => 'csyxgj',
  ),
  64 => 
  array (
    'id' => '68',
    'typeid' => '3372',
    'name' => '康复医学（高级）',
    'pinyin' => 'kfyxgj',
  ),
  65 => 
  array (
    'id' => '69',
    'typeid' => '3372',
    'name' => '结核病（高级）',
    'pinyin' => 'jhbgj',
  ),
  66 => 
  array (
    'id' => '70',
    'typeid' => '3372',
    'name' => '老年医学（高级）',
    'pinyin' => 'lnyxgj',
  ),
  67 => 
  array (
    'id' => '71',
    'typeid' => '3372',
    'name' => '计划生育（高级）',
    'pinyin' => 'jhsygj',
  ),
  68 => 
  array (
    'id' => '72',
    'typeid' => '3372',
    'name' => '精神病学（高级）',
    'pinyin' => 'sjbxgj',
  ),
  69 => 
  array (
    'id' => '73',
    'typeid' => '3372',
    'name' => '重症医学（高级）',
    'pinyin' => 'zzyxgj',
  ),
  70 => 
  array (
    'id' => '74',
    'typeid' => '3372',
    'name' => '临床营养（高级）',
    'pinyin' => 'lcyygj',
  ),
  71 => 
  array (
    'id' => '75',
    'typeid' => '3372',
    'name' => '临床医学检验技术（高级）',
    'pinyin' => 'lcyxjyjsjsgj',
  ),
  72 => 
  array (
    'id' => '76',
    'typeid' => '3372',
    'name' => '临床医学检验临床基础检验技术（高级）',
    'pinyin' => 'lcyxjylcjcjyjsgj',
  ),
  73 => 
  array (
    'id' => '77',
    'typeid' => '3372',
    'name' => '临床医学检验临床化学技术（高级）',
    'pinyin' => 'lcyxjylchxjs',
  ),
  74 => 
  array (
    'id' => '78',
    'typeid' => '3372',
    'name' => '临床医学检验临床免疫技术（高级）',
    'pinyin' => 'lcyxjylcmyjsgj',
  ),
  75 => 
  array (
    'id' => '79',
    'typeid' => '3372',
    'name' => '临床医学检验临床血液技术（高级）',
    'pinyin' => 'lcyxjylcxyjsgj',
  ),
  76 => 
  array (
    'id' => '80',
    'typeid' => '3372',
    'name' => '临床医学检验临床微生物技术（高级）',
    'pinyin' => 'lcyxjylcwswjsgj',
  ),
  77 => 
  array (
    'id' => '81',
    'typeid' => '3372',
    'name' => '病理学技术（高级）',
    'pinyin' => 'blxjsgj',
  ),
  78 => 
  array (
    'id' => '82',
    'typeid' => '3372',
    'name' => '放射医学技术（高级）',
    'pinyin' => 'fsyxjsgj',
  ),
  79 => 
  array (
    'id' => '83',
    'typeid' => '3372',
    'name' => '超声医学技术（高级）',
    'pinyin' => 'csyxjsgj',
  ),
  80 => 
  array (
    'id' => '84',
    'typeid' => '3372',
    'name' => '核医学技术（高级）',
    'pinyin' => 'hyxjsgj',
  ),
  81 => 
  array (
    'id' => '85',
    'typeid' => '3372',
    'name' => '康复医学技术（高级）',
    'pinyin' => 'kangfuyxjsgaoji',
  ),
  82 => 
  array (
    'id' => '86',
    'typeid' => '3372',
    'name' => '微生物检验技术（高级）',
    'pinyin' => 'wswjyjsgji',
  ),
  83 => 
  array (
    'id' => '87',
    'typeid' => '3372',
    'name' => '理化检验技术（高级）',
    'pinyin' => 'lhjyjsgji',
  ),
  84 => 
  array (
    'id' => '88',
    'typeid' => '3372',
    'name' => '输血技术（高级）',
    'pinyin' => 'sxjsgaoji',
  ),
  85 => 
  array (
    'id' => '89',
    'typeid' => '3372',
    'name' => '心电学技术（高级）',
    'pinyin' => 'xdxjsgji',
  ),
  86 => 
  array (
    'id' => '90',
    'typeid' => '3372',
    'name' => '脑电图技术（高级）',
    'pinyin' => 'ndtjsgj',
  ),
  87 => 
  array (
    'id' => '208',
    'typeid' => '3365',
    'name' => '临床执业医师资格考试',
    'pinyin' => 'lczyyszgks',
  ),
  88 => 
  array (
    'id' => '209',
    'typeid' => '3365',
    'name' => '临床执业助理医师资格考试',
    'pinyin' => 'lczyzlyszgks',
  ),
  89 => 
  array (
    'id' => '210',
    'typeid' => '3365',
    'name' => '中医执业医师资格考试',
    'pinyin' => 'zyzyyszgks',
  ),
  90 => 
  array (
    'id' => '211',
    'typeid' => '3365',
    'name' => '中医执业助理医师资格考试',
    'pinyin' => 'zyzyzlyszgks',
  ),
  91 => 
  array (
    'id' => '212',
    'typeid' => '3365',
    'name' => '中西医结合执业医师资格考试',
    'pinyin' => 'zxyjhzyyszgks',
  ),
  92 => 
  array (
    'id' => '213',
    'typeid' => '3365',
    'name' => '中西医结合执业助理医师资格考试',
    'pinyin' => 'zxyjhzyzlyszgks',
  ),
  93 => 
  array (
    'id' => '214',
    'typeid' => '3365',
    'name' => '口腔执业医师资格考试',
    'pinyin' => 'kqzyyszgks',
  ),
  94 => 
  array (
    'id' => '215',
    'typeid' => '3365',
    'name' => '口腔执业助理医师资格考试',
    'pinyin' => 'kqzyzlyszgks',
  ),
  95 => 
  array (
    'id' => '216',
    'typeid' => '3365',
    'name' => '公卫执业医师资格考试',
    'pinyin' => 'gwzyyszgks',
  ),
  96 => 
  array (
    'id' => '217',
    'typeid' => '3365',
    'name' => '公卫执业助理医师资格考试',
    'pinyin' => 'gwzyzlyszgks',
  ),
  97 => 
  array (
    'id' => '218',
    'typeid' => '3365',
    'name' => '临床执业医师实践技能考试',
    'pinyin' => 'lczyyssjjnks',
  ),
  98 => 
  array (
    'id' => '219',
    'typeid' => '3365',
    'name' => '临床执业助理医师实践技能考试',
    'pinyin' => 'lczyzlyssjjnks',
  ),
  99 => 
  array (
    'id' => '220',
    'typeid' => '3365',
    'name' => '中医执业医师实践技能考试',
    'pinyin' => 'zyzyyssjjnks',
  ),
  100 => 
  array (
    'id' => '221',
    'typeid' => '3365',
    'name' => '中医执业助理医师实践技能考试',
    'pinyin' => 'zyzyzlyssjjnks',
  ),
  101 => 
  array (
    'id' => '222',
    'typeid' => '3365',
    'name' => '中西医结合执业医师实践技能考试',
    'pinyin' => 'zxyjhzyyssjjnks',
  ),
  102 => 
  array (
    'id' => '223',
    'typeid' => '3371',
    'name' => '执业药师资格考试（中药）',
    'pinyin' => 'zyyszgkszy',
  ),
  103 => 
  array (
    'id' => '224',
    'typeid' => '3371',
    'name' => '执业药师资格考试（西药）',
    'pinyin' => 'zyyszgksxy',
  ),
  104 => 
  array (
    'id' => '225',
    'typeid' => '3372',
    'name' => '护士执业资格考试',
    'pinyin' => 'hszyzgks',
  ),
  105 => 
  array (
    'id' => '226',
    'typeid' => '3372',
    'name' => '护理学（护师）',
    'pinyin' => 'hlxhs',
  ),
  106 => 
  array (
    'id' => '227',
    'typeid' => '3372',
    'name' => '护理学考试（主管护师）',
    'pinyin' => 'hlxkszghs',
  ),
  107 => 
  array (
    'id' => '228',
    'typeid' => '3372',
    'name' => '主治医师（全科医学）',
    'pinyin' => 'zzysqkyx',
  ),
  108 => 
  array (
    'id' => '229',
    'typeid' => '3372',
    'name' => '主治医师（内科学）',
    'pinyin' => 'zzysnkx',
  ),
  109 => 
  array (
    'id' => '230',
    'typeid' => '3372',
    'name' => '主治医师（心血管内科学）',
    'pinyin' => 'zzysxxgnkx',
  ),
  110 => 
  array (
    'id' => '231',
    'typeid' => '3372',
    'name' => '主治医师（呼吸内科学）',
    'pinyin' => 'zzyshxnke',
  ),
  111 => 
  array (
    'id' => '232',
    'typeid' => '3372',
    'name' => '主治医师（消化内科学）',
    'pinyin' => 'zzysxhnkx',
  ),
  112 => 
  array (
    'id' => '233',
    'typeid' => '3372',
    'name' => '主治医师（肾内科学）',
    'pinyin' => 'zzyssnkx',
  ),
  113 => 
  array (
    'id' => '234',
    'typeid' => '3372',
    'name' => '主治医师（神经内科学）',
    'pinyin' => 'zzyssjnkx',
  ),
  114 => 
  array (
    'id' => '235',
    'typeid' => '3372',
    'name' => '主治医师（内分泌学）',
    'pinyin' => 'zzysnfmx',
  ),
  115 => 
  array (
    'id' => '236',
    'typeid' => '3372',
    'name' => '主治医师（血液病学）',
    'pinyin' => 'zzysxybx',
  ),
  116 => 
  array (
    'id' => '237',
    'typeid' => '3372',
    'name' => '主治医师（结核病学）',
    'pinyin' => 'zzysjhbx',
  ),
  117 => 
  array (
    'id' => '238',
    'typeid' => '3372',
    'name' => '主治医师（传染病学）',
    'pinyin' => 'zzyscrbx',
  ),
  118 => 
  array (
    'id' => '239',
    'typeid' => '3372',
    'name' => '主治医师（风湿与临床免疫学）',
    'pinyin' => 'zzysfsylcmyx',
  ),
  119 => 
  array (
    'id' => '240',
    'typeid' => '3372',
    'name' => '主治医师（普通外科学）',
    'pinyin' => 'zzysptwkx',
  ),
  120 => 
  array (
    'id' => '241',
    'typeid' => '3372',
    'name' => '主治医师（胸心外科学）',
    'pinyin' => 'zzysxxwkx',
  ),
  121 => 
  array (
    'id' => '242',
    'typeid' => '3372',
    'name' => '主治医师（神经外科学）',
    'pinyin' => 'zzyssjwkx',
  ),
  122 => 
  array (
    'id' => '243',
    'typeid' => '3372',
    'name' => '主治医师（泌尿外科学）',
    'pinyin' => 'zzysmnwkx',
  ),
  123 => 
  array (
    'id' => '244',
    'typeid' => '3372',
    'name' => '主治医师（小儿外科学）',
    'pinyin' => 'zzysxewkx',
  ),
  124 => 
  array (
    'id' => '245',
    'typeid' => '3372',
    'name' => '主治医师（烧伤外科学）',
    'pinyin' => 'zzyssswkx',
  ),
  125 => 
  array (
    'id' => '246',
    'typeid' => '3372',
    'name' => '主治医师（整形外科学）',
    'pinyin' => 'zzyszxwke',
  ),
  126 => 
  array (
    'id' => '247',
    'typeid' => '3372',
    'name' => '主治医师（妇产科学）',
    'pinyin' => 'zzysfckx',
  ),
  127 => 
  array (
    'id' => '248',
    'typeid' => '3372',
    'name' => '主治医师（儿科学）',
    'pinyin' => 'zzysekx',
  ),
  128 => 
  array (
    'id' => '249',
    'typeid' => '3372',
    'name' => '主治医师（骨外科学）',
    'pinyin' => 'zzysgwke',
  ),
  129 => 
  array (
    'id' => '250',
    'typeid' => '3372',
    'name' => '主治医师（眼科学）',
    'pinyin' => 'zzysykx',
  ),
  130 => 
  array (
    'id' => '251',
    'typeid' => '3372',
    'name' => '主治医师（耳鼻咽喉科学）',
    'pinyin' => 'zzysebyhkx',
  ),
  131 => 
  array (
    'id' => '252',
    'typeid' => '3372',
    'name' => '主治医师（皮肤与性病学）',
    'pinyin' => 'zzyspfyxbx',
  ),
  132 => 
  array (
    'id' => '253',
    'typeid' => '3372',
    'name' => '主治医师（麻醉学）',
    'pinyin' => 'zzysmzx',
  ),
  133 => 
  array (
    'id' => '254',
    'typeid' => '3372',
    'name' => '主治医师（口腔医学）',
    'pinyin' => 'zzyskqyx',
  ),
  134 => 
  array (
    'id' => '255',
    'typeid' => '3372',
    'name' => '主治医师（康复医学）',
    'pinyin' => 'zzyskfyx',
  ),
  135 => 
  array (
    'id' => '256',
    'typeid' => '3372',
    'name' => '主治医师（肿瘤内科学）',
    'pinyin' => 'zzysnlnkx',
  ),
  136 => 
  array (
    'id' => '257',
    'typeid' => '3372',
    'name' => '主治医师（肿瘤外科学）',
    'pinyin' => 'zzyszlwkx',
  ),
  137 => 
  array (
    'id' => '258',
    'typeid' => '3372',
    'name' => '主治医师（肿瘤放射治疗学）',
    'pinyin' => 'zzyszlfszlx',
  ),
  138 => 
  array (
    'id' => '259',
    'typeid' => '3372',
    'name' => '主治医师（疾病控制）',
    'pinyin' => 'zzysjbkz',
  ),
  139 => 
  array (
    'id' => '260',
    'typeid' => '3372',
    'name' => '主治医师（公共卫生）',
    'pinyin' => 'zzysggws',
  ),
  140 => 
  array (
    'id' => '261',
    'typeid' => '3372',
    'name' => '主治医师（职业卫生）',
    'pinyin' => 'zzyszyws',
  ),
  141 => 
  array (
    'id' => '262',
    'typeid' => '3372',
    'name' => '主治医师（妇幼保健）',
    'pinyin' => 'zzysfybj',
  ),
  142 => 
  array (
    'id' => '263',
    'typeid' => '3372',
    'name' => '主治医师（健康教育）',
    'pinyin' => 'zzysjkjy',
  ),
  143 => 
  array (
    'id' => '264',
    'typeid' => '3372',
    'name' => '主治医师（中医内科学）',
    'pinyin' => 'zzyszynkx',
  ),
  144 => 
  array (
    'id' => '265',
    'typeid' => '3372',
    'name' => '主治医师（中医外科学）',
    'pinyin' => 'zzyszywkx',
  ),
  145 => 
  array (
    'id' => '266',
    'typeid' => '3372',
    'name' => '主治医师（中医肛肠科学）',
    'pinyin' => 'zzyszygckx',
  ),
  146 => 
  array (
    'id' => '267',
    'typeid' => '3372',
    'name' => '主治医师（中医骨伤学）',
    'pinyin' => 'zzyszygsx',
  ),
  147 => 
  array (
    'id' => '268',
    'typeid' => '3372',
    'name' => '主治医师（中医妇科学）',
    'pinyin' => 'zzyszyfkx',
  ),
  148 => 
  array (
    'id' => '269',
    'typeid' => '3372',
    'name' => '主治医师（中医儿科学）',
    'pinyin' => 'zzyszyekx',
  ),
  149 => 
  array (
    'id' => '270',
    'typeid' => '3372',
    'name' => '主治医师（中医眼科学）',
    'pinyin' => 'zzyszyykx',
  ),
  150 => 
  array (
    'id' => '271',
    'typeid' => '3372',
    'name' => '主治医师（中医耳鼻喉科学）',
    'pinyin' => 'zzyszyebhkx',
  ),
  151 => 
  array (
    'id' => '272',
    'typeid' => '3372',
    'name' => '主治医师（中医皮肤与性病学）',
    'pinyin' => 'zzyszypfyxbx',
  ),
  152 => 
  array (
    'id' => '273',
    'typeid' => '3372',
    'name' => '主治医师（中医针灸学）',
    'pinyin' => 'zzyszyzjx',
  ),
  153 => 
  array (
    'id' => '274',
    'typeid' => '3372',
    'name' => '主治医师（推拿(按摩)学）',
    'pinyin' => 'zzystnx',
  ),
  154 => 
  array (
    'id' => '275',
    'typeid' => '3372',
    'name' => '主治医师全科医学（中医类）',
    'pinyin' => 'zzysqkyxzyl',
  ),
  155 => 
  array (
    'id' => '276',
    'typeid' => '3372',
    'name' => '主治医师（中西医结合内科学）',
    'pinyin' => 'zzyszxyjhnkx',
  ),
  156 => 
  array (
    'id' => '277',
    'typeid' => '3372',
    'name' => '主治医师（中西医结合外科学）',
    'pinyin' => 'zzyszxyjhwkx',
  ),
  157 => 
  array (
    'id' => '278',
    'typeid' => '3372',
    'name' => '主治医师（中西医结合骨伤科学）',
    'pinyin' => 'zzyszxyjhgskx',
  ),
  158 => 
  array (
    'id' => '279',
    'typeid' => '3372',
    'name' => '中药士',
    'pinyin' => 'zys',
  ),
  159 => 
  array (
    'id' => '280',
    'typeid' => '3372',
    'name' => '中药师',
    'pinyin' => 'zyshi',
  ),
  160 => 
  array (
    'id' => '281',
    'typeid' => '3372',
    'name' => '主管药师（中药学）',
    'pinyin' => 'zgyszyx',
  ),
  161 => 
  array (
    'id' => '282',
    'typeid' => '3372',
    'name' => '药剂士',
    'pinyin' => 'yjs',
  ),
  162 => 
  array (
    'id' => '283',
    'typeid' => '3372',
    'name' => '药剂师',
    'pinyin' => 'yjshi',
  ),
  163 => 
  array (
    'id' => '284',
    'typeid' => '3372',
    'name' => '主管药师（药学）',
    'pinyin' => 'zgysyx',
  ),
  164 => 
  array (
    'id' => '285',
    'typeid' => '3372',
    'name' => '临床医学检验技术（技士）',
    'pinyin' => 'lcyxjyjsjs',
  ),
  165 => 
  array (
    'id' => '286',
    'typeid' => '3372',
    'name' => '临床医学检验技术（技师）',
    'pinyin' => 'lcyxjyjsjshi',
  ),
  166 => 
  array (
    'id' => '287',
    'typeid' => '3372',
    'name' => '临床医学检验技术（中级）',
    'pinyin' => 'lcyxjyjszj',
  ),
  167 => 
  array (
    'id' => '288',
    'typeid' => '3372',
    'name' => '主治医师（精神病学）',
    'pinyin' => 'zzyssjbx',
  ),
  168 => 
  array (
    'id' => '289',
    'typeid' => '3372',
    'name' => '主治医师（核医学）',
    'pinyin' => 'zzyshyx',
  ),
  169 => 
  array (
    'id' => '290',
    'typeid' => '3372',
    'name' => '主治医师（放射医学）',
    'pinyin' => 'zzysgsyx',
  ),
  170 => 
  array (
    'id' => '291',
    'typeid' => '3372',
    'name' => '主治医师（计划生育）',
    'pinyin' => 'zzysjhsy',
  ),
  171 => 
  array (
    'id' => '292',
    'typeid' => '3372',
    'name' => '主管技师（心电学技术）',
    'pinyin' => 'zgjsxdxjs',
  ),
  172 => 
  array (
    'id' => '293',
    'typeid' => '3372',
    'name' => '主管技师（康复医学治疗技术）',
    'pinyin' => 'zgjskfyxzljs',
  ),
  173 => 
  array (
    'id' => '294',
    'typeid' => '3372',
    'name' => '主管技师（消毒技术）',
    'pinyin' => 'zgjsxdjs',
  ),
  174 => 
  array (
    'id' => '295',
    'typeid' => '3372',
    'name' => '主管技师（微生物检验技术）',
    'pinyin' => 'zgjswswjyjs',
  ),
  175 => 
  array (
    'id' => '296',
    'typeid' => '3372',
    'name' => '主管技师（口腔医学技术）',
    'pinyin' => 'zgjskqyxjs',
  ),
  176 => 
  array (
    'id' => '297',
    'typeid' => '3372',
    'name' => '主管技师（超声波医学技术）',
    'pinyin' => 'zgjscsbyxjs',
  ),
  177 => 
  array (
    'id' => '298',
    'typeid' => '3371',
    'name' => '主管技师（肿瘤放射治疗技术）',
    'pinyin' => 'zgjszlfszljs',
  ),
  178 => 
  array (
    'id' => '299',
    'typeid' => '3372',
    'name' => '主管技师（心理治疗）',
    'pinyin' => 'zgjsxlzl',
  ),
  179 => 
  array (
    'id' => '300',
    'typeid' => '3372',
    'name' => '主管技师（核医学技术）',
    'pinyin' => 'zgjshyxjs',
  ),
  180 => 
  array (
    'id' => '301',
    'typeid' => '3372',
    'name' => '主管技师（理化检验技术）',
    'pinyin' => 'zgjslhjyjs',
  ),
  181 => 
  array (
    'id' => '302',
    'typeid' => '3372',
    'name' => '主管技师（营养）',
    'pinyin' => 'zgjsyy',
  ),
  182 => 
  array (
    'id' => '303',
    'typeid' => '3372',
    'name' => '内科护理（中级）',
    'pinyin' => 'nkhlzj',
  ),
  183 => 
  array (
    'id' => '304',
    'typeid' => '3372',
    'name' => '外科护理（中级）',
    'pinyin' => 'wkhlzj',
  ),
  184 => 
  array (
    'id' => '305',
    'typeid' => '3372',
    'name' => '妇产科护理（中级）',
    'pinyin' => 'fckhlzj',
  ),
  185 => 
  array (
    'id' => '306',
    'typeid' => '3372',
    'name' => '儿科护理（中级）',
    'pinyin' => 'ekhlzj',
  ),
  186 => 
  array (
    'id' => '307',
    'typeid' => '3372',
    'name' => '社区护理（中级）',
    'pinyin' => 'sqhlzj',
  ),
  187 => 
  array (
    'id' => '308',
    'typeid' => '3372',
    'name' => '主管技师（放射医学技术）',
    'pinyin' => 'zgjsfsyxjs',
  ),
  188 => 
  array (
    'id' => '309',
    'typeid' => '3372',
    'name' => '主管技师（病案信息技术）',
    'pinyin' => 'zgjsalxxjs',
  ),
  189 => 
  array (
    'id' => '310',
    'typeid' => '3372',
    'name' => '主治医师（职业病学）',
    'pinyin' => 'zzyszybx',
  ),
  190 => 
  array (
    'id' => '311',
    'typeid' => '3372',
    'name' => '主治医师（超声波医学）',
    'pinyin' => 'zzyscsbyx',
  ),
  191 => 
  array (
    'id' => '312',
    'typeid' => '3372',
    'name' => '主治医师（病理学）',
    'pinyin' => 'zzysblx',
  ),
  192 => 
  array (
    'id' => '313',
    'typeid' => '3372',
    'name' => '主治医师（疼痛学）',
    'pinyin' => 'zzysttx',
  ),
  193 => 
  array (
    'id' => '314',
    'typeid' => '3372',
    'name' => '护理学（高级）',
    'pinyin' => 'hlxgj',
  ),
  194 => 
  array (
    'id' => '315',
    'typeid' => '3372',
    'name' => '主治医师（口腔修复学）',
    'pinyin' => 'zzyskqxfx',
  ),
  195 => 
  array (
    'id' => '316',
    'typeid' => '3372',
    'name' => '主治医师（口腔颌面外科学）',
    'pinyin' => 'zzyskqemwkx',
  ),
  196 => 
  array (
    'id' => '317',
    'typeid' => '3372',
    'name' => '主治医师（口腔内科学）',
    'pinyin' => 'zzyskqnkx',
  ),
  197 => 
  array (
    'id' => '318',
    'typeid' => '3372',
    'name' => '主治医师（口腔正畸学）',
    'pinyin' => 'zzyskqzjx',
  ),
  198 => 
  array (
    'id' => '319',
    'typeid' => '3372',
    'name' => '主管技师（病理学技术）',
    'pinyin' => 'zzjsblxjs',
  ),
  199 => 
  array (
    'id' => '320',
    'typeid' => '3372',
    'name' => '主管技师（输血技术）',
    'pinyin' => 'zgjssxjs',
  ),
);
?>