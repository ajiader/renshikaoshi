<?php
return array (
  196667 => 
  array (
    'id' => '196667',
    'catid' => '420',
    'typeid' => '0',
    'title' => '2015年零基础保过必看课程',
    'style' => '',
    'thumb' => '/uploadfile/2014/1225/20141225110705655.jpg',
    'keywords' => '',
    'description' => '',
    'posids' => '1',
    'url' => 'http://www.renshikaoshi.net/download/zhichenyingyu/',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '1',
    'username' => 'renchunli',
    'inputtime' => '1419476800',
    'updatetime' => '1419477056',
    'city_id' => '0',
    'mid' => '',
  ),
);
?>