<?php
return array (
  126100 => 
  array (
    'id' => '126100',
    'catid' => '484',
    'typeid' => '71',
    'title' => '北京2014年全国注册土木工程师（港口与航道工程）考试报名时间|考试时间|考试地点',
    'style' => '',
    'thumb' => '',
    'keywords' => '航道 考试时间 土木',
    'description' => '',
    'posids' => '1',
    'url' => 'http://www.renshikaoshi.net/zyzg/484-126100-1.html',
    'listorder' => '0',
    'status' => '99',
    'sysadd' => '1',
    'islink' => '0',
    'username' => 'denghongyu',
    'inputtime' => '1401958859',
    'updatetime' => '1401959182',
    'city_id' => '2',
    'mid' => '',
    'hitsid' => 'c-1-126100',
    'views' => '0',
    'yesterdayviews' => '0',
    'dayviews' => '0',
    'weekviews' => '0',
    'monthviews' => '0',
  ),
);
?>