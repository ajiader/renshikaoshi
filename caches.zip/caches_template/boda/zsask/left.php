<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="quizlf">
    	<div class="wdclass">
        	<h2>问答分类</h2>
            <?php $n=1;if(is_array($askcategorys)) foreach($askcategorys AS $v) { ?>
            <p <?php if($catid==$v['catid']) { ?>class="selected"<?php } ?>><a href="<?php echo siteurl($siteid);?>/question/qlist_<?php echo $v['catid'];?>_1.html"><?php echo $v['catname'];?><font>(<?php echo get_question($v['catid']);?>)</font></a></p>      <?php $n++;}unset($n); ?>
        </div>
        <span class="spbt"></span>
    </div>