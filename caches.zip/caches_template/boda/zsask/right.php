<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="quizrg">
    	<div class="quiztydv">
    		<span>最新答疑</span>
            <ul class="ymrightlnzt">
            <?php 
             if($info[catid]){
              $catsql = "and catid=$info[catid]";
             }
             ?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=446709e8504a903ef508e411c08219d8&sql=SELECT+qid%2Cquestion%2Cip%2Ccatid+from+v9_ask_question+WHERE++aid+%3E+%27%27+and+siteid%3D%24this-%3Esiteid+%24catsql++ORDER+BY+addtime+desc&cache=0&num=10&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT qid,question,ip,catid from v9_ask_question WHERE  aid > '' and siteid=$this->siteid $catsql  ORDER BY addtime desc LIMIT 10");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                <li><a href="<?php echo geturlrule($val['qid']);?>" target="_blank" title="<?php echo $val['question'];?>"><?php echo str_cut($val['question'],'54','');?></a></li>
              <?php $n++;}unset($n); ?>
           <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
          </ul>
        </div>
        <div class="quiztydv">
    		<span>热门问题</span>
            <ul class="ymrightlnzt">
            <?php
           $data=zsak_hits(array('limit'=>10,'siteid'=>$this->siteid,'catid'=>$info[catid]));
           ?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
              <li><a href="<?php echo geturlrule($val['qid']);?>" target="_blank" title="<?php echo $val['question'];?>"><?php echo str_cut($val['question'],'54','');?></a></li>
                <?php $n++;}unset($n); ?>
          </ul>
        </div>
    </div>