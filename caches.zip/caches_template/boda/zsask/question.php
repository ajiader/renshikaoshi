<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/kaozc/ask/css/online_quiz.css" />
<link href="<?php echo CSS_PATH;?>dialog.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php include template("content","rsks_top"); ?>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH;?>dialog.js"></script>
<script language="javascript">
$(function(){
	$('#question').keyup(function (e) { 
		var str = jQuery.trim($('#question').val());       
		//汉字的个数  
       // str2 = (str.replace(/\w/g,"")).length;  
        var total = str.length;           
		var title_num = 40 - total;
		$('#title_num').html(title_num);
		if (total >40) {
			_str = str.substring(0, 40);
			$('#question').val(_str);
			$('#title_num').html('0');
		}else {
			search_rs(str, 'question_rs');
		}
	});	
	
});

	function col_show() {
		if ($('#cont').attr('show') =='1') {
			$('#cont').attr('show', '0');
			$('#cont').hide('slow');
		}else {
			$('#cont').attr('show', '1');
			$('#cont').show('slow');
			$('#cont').focus(function () {
				$('#cont').addClass('border_focus');
			});
			$('#cont').focus();
			$('#cont').addClass('border_focus');
		}
	}
function on_submit() {
		var question = jQuery.trim($('#question').val());
		var catpath = jQuery.trim($('#catpath').val());
		if (!question) {
			window.top.art.dialog({id:'img', lock:false}).close();
			window.top.art.dialog({id:'img',content:"请输入您的疑问！",lock:false,width:'200',height:'30',time:1.5});
			$('#question').focus();
			return false;
		}else if (!catpath) {
			window.top.art.dialog({id:'img',content:"请选择分类！",lock:false,width:'200',height:'30',time:1.5});
			return false;
		}
	}

</script>
<div class="onlinequizct">

	<div class="quizdetail">
    	<div class="dqposition">当前位置：：<a href="<?php echo siteurl($siteid);?>">考职称</a>><a href="<?php echo siteurl($siteid);?>/question/">在线问答</a>><a href="<?php echo siteurl($siteid);?>/question/ask.html">提问</a></div>
        <div class="quiztiwen">
        	<span class="fjsp">方式一：填写您的问题</span>
          <form action="" method="post" onsubmit="return on_submit()">
            <div class="dvselec">请选择分类<select name="catid" id="catpath"> <option value="" >请选择</option>
            <?php $n=1;if(is_array($askcategorys)) foreach($askcategorys AS $r) { ?>
            <?php if($r[grade] ==1 && $r[status] ==99) { ?>
            <option value="<?php echo $r['catid'];?>"><?php echo $r['catname'];?></option>
            <?php } ?>
<?php $n++;}unset($n); ?>
            </select></div>
            
            <div class="dvarea"><textarea  name="question" id="question" ></textarea></div>
            <p><span>你还可以输入<strong id="title_num">40</strong>个字</span></p>
            <div id="buchong" onclick="col_show()" class="questionbuc"><span>问题补充（选填）</span></div>
             <div class="dvarea"><textarea  name="content" id="cont"  style="display:none" ></textarea></div>
            <div class="tjbtn"><input type="submit" name="dosubmit" value=" "  /></div>
            </form>
            <div class="zjxgb"><span class="fjsp rgzx">方式二：人工咨询</span></div>
            <p><a href="#" onclick="kefu_url(1)">联系在线客服</a></p>
        </div>
  	</div>
    
    <div class="quizrg">
    	<div class="quiztydv">
    		<span class="spde">答疑专家<a href="http://www.kaogwy.com/zhuanjia/" target="_blank">更多>></a></span>
             <?php
            $typeArr = gettypeurl();
            ?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=7d34e6a15979bee646a0d04becea49ca&sql=SELECT+%2A+from+v9_zhuanjia+where+siteid%3D%24this-%3Esiteid+ORDER+BY+id+asc&num=4&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from v9_zhuanjia where siteid=$this->siteid ORDER BY id asc LIMIT 4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
            <div class="zjpclsit"><a href="<?php echo siteurl($siteid);?>/<?php echo $typeArr[$val['typeid']]['typedir'];?>/zhuanjia/t_<?php echo $val['id'];?>_1.html" target="_blank"><img src="<?php echo $val['thumb'];?>"  width="100"/></a><p><a href="<?php echo siteurl($siteid);?>/<?php echo $typeArr[$val['typeid']]['typedir'];?>/zhuanjia/t_<?php echo $val['id'];?>_1.html" target="_blank"><?php echo $val['name'];?></a></p></div>
           <?php $n++;}unset($n); ?> <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
        </div>
    </div>
    
</div>
<?php include template("content","rsks_bottom"); ?>

</body>
</html>
