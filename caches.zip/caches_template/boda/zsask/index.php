<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?></title>
<meta name="keywords" content="">
<meta name="description" content="">
<link type="text/css" rel="stylesheet" href="/statics/kaozc/ask/css/online_quiz.css?xg1218" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script language="javascript">
function getObject(objID)
 {if (document.getElementById && document.getElementById(objID)) 
 {return document.getElementById(objID);} 
 else 
 {if (document.all && document.all(objID)) 
 {return document.all(objectId);} 
 else 
 {if (document.layers && document.layers[objID]) 
 {return document.layers[objID];} 
 else
 {return false;}
 }
 }
 }
function questionqh(n)
{
for (var i = 1; i <= 2; i++)
{
if (i == n) 
{
getObject("questionqh" + i).className = "selected";
getObject("questionqhDIV" + i).style.display = "";
}
else
{
getObject("questionqh" + i).className = "";
getObject("questionqhDIV" + i).style.display = "none";
}
}
}

</script>

</head>

<body>
<?php include template("zsask","header"); ?>
<div class="onlinequizct">

	<?php include template("zsask","left"); ?>
    
    <div class="quizcter">
    	<div class="dqposition">当前位置：<a href="<?php echo siteurl($siteid);?>">考职称网</a>><a href="<?php echo siteurl($siteid);?>/question/">在线问答</a></div>
        <div class="qhquestion"><a href="<?php echo siteurl($siteid);?>/question/qlist_1.html" class="selected">已解决<font></font></a><a href="<?php echo siteurl($siteid);?>/question/qlist_1.html" class="ywmore">更多>></a></div>
        <div id="questionqhDIV1">
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=64db3a5f10431c62ce02996ea3b3667c&sql=SELECT+aq.qid%2Caq.question%2Caq.ip%2Caq.catid%2Caa.%2A+from+v9_ask_question+aq+JOIN+v9_ask_answer+aa+ON+aq.qid%3Daa.qid%0AWHERE+aq.status+%21%3D+1+AND+aq.aid%3E0+and+aq.siteid%3D%24this-%3Esiteid+ORDER+BY+aq.qid+desc&cache=1800&num=5&page=%24page&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 5;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid
WHERE aq.status != 1 AND aq.aid>0 and aq.siteid=$this->siteid ORDER BY aq.qid desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT aq.qid,aq.question,aq.ip,aq.catid,aa.* from v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid
WHERE aq.status != 1 AND aq.aid>0 and aq.siteid=$this->siteid ORDER BY aq.qid desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
        	<div class="questiontydv">
            	<div class="questitle"><a href="<?php echo geturlrule($val['qid']);?>" title="<?php echo $val['question'];?>" target="_blank"><?php echo str_cut($val['question'],'80');?></a></div>
                <div class="quesauho"><span>专家回答</span><?php echo format_date($val['addtime']);?></div>
                <div class="quesnr"><?php echo str_cut(strip_tags(strip_tags($val['content'])),'200');?></div>
            </div>
           <?php $n++;}unset($n); ?>
           <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </div>
        <div class="qhquestion"><a href="<?php echo siteurl($siteid);?>/question/nqlist_1.html" class="selected">未解决<font></font></a><a href="<?php echo siteurl($siteid);?>/question/nqlist_1.html" class="ywmore">更多>></a></div>
        <div id="questionqhDIV2">
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=a821fbfe54c75eb4ddbb3d58c1fff379&sql=SELECT+qid%2Ccatid%2Cquestion%2Caddtime+from+v9_ask_question+WHERE+aid%3D0+and+status+%21%3D+1+and+siteid%3D%24this-%3Esiteid+ORDER+BY+qid+desc&cache=1800&num=5&page=%24page&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 5;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_ask_question WHERE aid=0 and status != 1 and siteid=$this->siteid ORDER BY qid desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT qid,catid,question,addtime from v9_ask_question WHERE aid=0 and status != 1 and siteid=$this->siteid ORDER BY qid desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
<div class="questiontydv dvbgone questionxghg">
            	<div class="questitle"><a href="<?php echo geturlrule($val['qid']);?>" title="<?php echo $val['question'];?>" target="_blank"><?php echo str_cut($val['question'],'80');?></a><span>(<?php echo format_date($val['addtime']);?>)</span></div>
            </div>
           <?php $n++;}unset($n); ?>
           <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
        </div>
    </div>
    
   <?php include template("zsask","right"); ?> 
    
</div>


<?php include template("content","rsks_bottom"); ?>
<!--异步加载开始-->
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
        BAIDU_CLB_fillSlotAsync('701537','701537');
		  BAIDU_CLB_fillSlotAsync('701584','701584');
		  <!--图文-->
		   BAIDU_CLB_fillSlotAsync('710248','710248');
		  
</script>

<!--异步加载结束 --> 
</body>
</html>
