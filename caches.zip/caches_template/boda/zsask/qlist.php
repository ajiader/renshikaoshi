<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?>博大弘仕国家公务员考试网</title>
<meta name="keywords" content="">
<meta name="description" content="">
<link type="text/css" rel="stylesheet" href="/statics/kaozc/ask/css/online_quiz.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />

<script language="javascript">
function getObject(objID)
 {if (document.getElementById && document.getElementById(objID)) 
 {return document.getElementById(objID);} 
 else 
 {if (document.all && document.all(objID)) 
 {return document.all(objectId);} 
 else 
 {if (document.layers && document.layers[objID]) 
 {return document.layers[objID];} 
 else
 {return false;}
 }
 }
 }
function questionqh(n)
{
for (var i = 1; i <= 2; i++)
{
if (i == n) 
{
getObject("questionqh" + i).className = "selected";
getObject("questionqhDIV" + i).style.display = "";
}
else
{
getObject("questionqh" + i).className = "";
getObject("questionqhDIV" + i).style.display = "none";
}
}
}
</script>
</head>

<body>
<?php include template("zsask","header"); ?>
<div class="onlinequizct">

	<?php include template("zsask","left"); ?>
    
    <div class="quizcter questionxgrg">
    	<div class="dqposition">当前位置：<a href="<?php echo siteurl($siteid);?>">考职称</a>><a href="<?php echo siteurl($siteid);?>/question/">在线问答</a><?php if($catid) { ?>><a href="<?php echo siteurl($siteid);?>/question/<?php if($s>0) { ?>n<?php } ?>qlist_<?php echo $catid;?>_1.html"><?php echo $askcategorys[$catid]['catname'];?></a><?php } ?></div>
        <div class="qhquestion"><a href="<?php echo siteurl($siteid);?>/question/<?php if($s>0) { ?>n<?php } ?>qlist_<?php if($catid) { ?><?php echo $catid;?>_<?php } ?>1.html" class="selected"><?php if($s>0) { ?>待<?php } else { ?>已<?php } ?>解决<font></font></a></div>
        <?php if($s>0) { ?>
        <div id="questionqhDIV2">
        <?php if(qlist) { ?>
        <?php $n=1; if(is_array($qlist)) foreach($qlist AS $key => $val) { ?>
        	<div class="questiontydv dvbgone questionxghg">
            	<div class="questitle"><a href="<?php echo geturlrule($val['qid']);?>" target="_blank"><?php if($fenciarr) { ?><?php echo replace_search($fenciarr,$val['question']);?><?php } else { ?><?php echo replace_search($q,$val['question']);?><?php } ?></a><span>(<?php echo format_date($val['addtime']);?>)</span></div>
            </div>
     <?php $n++;}unset($n); ?>
     <?php } else { ?>
     <div class="questitle">未找到相关问题！</div>
     <?php } ?>
     <div class="detailfy"><span> <?php echo $pages;?> </span></div>
        </div>
        <?php } else { ?>
        <div id="questionqhDIV1">
<?php $n=1; if(is_array($qlist)) foreach($qlist AS $key => $val) { ?>
        	<div class="questiontydv">
            	<div class="questitle"><a href="<?php echo geturlrule($val['qid']);?>" target="_blank"><?php if($fenciarr) { ?><?php echo replace_search($fenciarr,$val['question']);?><?php } else { ?><?php echo replace_search($q,$val['question']);?><?php } ?></a></div>
                <div class="quesauho"><span>专家回答</span><?php echo format_date($val['addtime']);?></div>
                <div class="quesnr"><?php echo str_cut(strip_tags(getAnswerContent($val['aid'])),'200');?></div>
            </div>
              <?php $n++;}unset($n); ?>
         

            <div class="detailfy"><span> <?php echo $pages;?> </span></div>
        </div>
        <?php } ?>
      
        
    </div>
    
    <?php include template("zsask","right"); ?>
</div>
<?php include template("content","rsks_bottom"); ?>
 <!--异步加载开始-->
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
        BAIDU_CLB_fillSlotAsync('701537','701537');
		  BAIDU_CLB_fillSlotAsync('701584','701584');
		   <!--图文-->
		   BAIDU_CLB_fillSlotAsync('710248','710248');
</script>

<!--异步加载结束 --> 
</body>
</html>
