<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $SEO['title'];?></title>
<meta name="keywords" content="<?php echo $SEO['keywords'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/kaozc/css/rsstyle.css?d=1204" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />

<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script language="javascript" src="/statics/kaozc/js/qhnews.js"></script>
<script language="javascript" src="/statics/kaozc/js/jq_scroll.js"></script>
<script language="javascript" src="/statics/zyzg/js/qh.js"></script>
<script language="javascript" src="/statics/js/53kefu.js"></script>
<script type="text/javascript">

$(document).ready(function(){

$("#teacheryiwen").Scroll({line:1,speed:500,timer:3000});
});

</script>
<script type="text/javascript">
$(document).ready(function(){
$("#menua li").mousemove(function(){$(this).find("div").show();});
$("#menua li").mouseleave(function(){$(this).find("div").hide();});
});
</script>
<script type="text/javascript">
function hftb(){
  window.open("http://item.taobao.com/item.htm?spm=a1z10.1.w6842337-6518291215.31.Q60c6b&id=37117006912","_blank");
}
</script>
</head>
<body>
 <?php include template("renshibaoming","header"); ?>
 <div class="cy-tyct kzx-dysx">
<div id="<?php echo $ad_ids['0'];?>"> </div>
    <div class="kzc-listym kzc-newsone">
    	<div class="kzc-posi">当前位置：<a href="http://www.renshikaoshi.net">首页</a><span> &gt; </span>  <a href="<?php echo siteurl($siteid);?>/<?php echo $typedir;?>/<?php echo $filename;?>.html"><?php echo $seotitle;?></a>  &gt; <a href="<?php echo siteurl($siteid);?>/<?php echo $typedir;?>/<?php echo $filename;?>-<?php echo $typeRow['typeid'];?>-1.html"><?php echo $typeRow['name'];?></a>  </div>
    	<div class="listymlf">
        	<div class="listcut"><span style="float:right; font-weight:normal; padding-right:10px; font-size:12px;"> </span><?php echo $title;?><?php echo $typeRow['name'];?> </div>
            
           
            
            <h3 class="bjtj" style="display:none;"><span>编辑推荐</span></h3>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=367c6a0e739b6f141cbef5157c1f9164&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cinputtime%2Cupdatetime+FROM+phpcms_news+where+%28title+like+%27%25%24title%25%27+or+title+like+%27%25%24cityname%25%27+or+city_id+in+%28%24arrchildid%29%29+and+typeid%3D%27%24type_id%27+and+status%3D99+order+by+id+desc&page=%24page&num=20++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 20;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where (title like '%$title%' or title like '%$cityname%' or city_id in ($arrchildid)) and typeid='$type_id' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,inputtime,updatetime FROM phpcms_news where (title like '%$title%' or title like '%$cityname%' or city_id in ($arrchildid)) and typeid='$type_id' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
           <ul class="newslist ftsmall listmore">
              <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
              <li><a href="<?php echo $r['url'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo str_cut($r[title],100,'...');?></a><span>(<?php echo date('Y-m-d',$r[inputtime]);?>)</span></li>
              <?php if($n%5==0) { ?></ul>  <ul class="newslist ftsmall listmore"><?php } ?>
                     <?php $n++;}unset($n); ?>
                    </ul>
                    <div class="detailfy"><?php echo $pages;?></div>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            
            <ul class="newslist ftsmall listmore">
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3c4a9342f60081a7d7d4c5fcee925738&sql=SELECT+%2A+from+phpcms_diypage+WHERE+cityid+in+%28%24arrchildid%29+and+level%3D1+order+by+id+desc&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE cityid in ($arrchildid) and level=1 order by id desc LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
<li><a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a></li>
<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        
        <?php include template("renshibaoming","right_rsks"); ?>
        <div class="clear"></div>
    </div>
</div>
 <?php include template("content","footer"); ?>
 
  <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
	<script type="text/javascript">   
		<!-- 广告位：地方人事-图文环绕 -->
		BAIDU_CLB_fillSlotAsync('943278', 'PAGE_AD_943278');
    </script>

</body>

</html>