<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBliC "-//W3C//DTD html 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!-- saved from url=(0033)http://www.13683.cn/index(8).html -->

<html>

<head>

<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<meta content="text/html; charset=utf-8" http-equiv=Content-Type>
<meta content=IE=EmulateIE7 http-equiv=X-Ua-Compatible>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<meta name=GENERaTOR content="MShtml 8.00.6001.19088">
<link media=screen href="/statics/css/boda/en_css.css" type=text/css rel=stylesheet>
<link media=screen href="/statics/css/boda/comm.css" type=text/css rel=stylesheet>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<style>
.font01{font-size:14px;font-weight:bold;color:red;text-align:center;font-family:"microsoft yahei";}
.font02{
	font-size:14px;
	font-weight:bold;
	text-align:center;
	font-family:"microsoft yahei";
}
.font03{font-size:12px;color:#176975;line-height:20px;}
.font03 a{color:#176975;}
.font03 a:hover{color:#f00;}
.font04{font-size:14px;font-weight:bold;color:#34a3eb;text-align:center;font-family:"microsoft yahei";}
.font05{font-size:16px;font-weight:bold;color:#176975;text-align:center;font-family:"microsoft yahei";}
.nav dl.ks{width:285px;float:left;}
.nav dl.dt{width:370px;float:left;}
.nav dl dd a {display: block;text-align: center;white-space: nowrap;border-left: 1px dotted #042941;height: 14px;margin-top: 8px;width: 83px;font-size: 12px;line-height: 14px;float: left;}
.cur_pos{background:#edf2ff;height:25px;border:1px solid #ececec;line-height:27px;padding-left:10px;}
.bm_left{width:695px;float:left;margin-top:10px;}
.bm_right{width:250px;float:right;margin-top:10px;}
.bao_acc h2{background:url(/statics/images/acc_bg.jpg) repeat-x;width:684px;height:35px;line-height:35px;border:1px solid #a4d6e9;font-size:18px;font-weight:bold;color:#059;padding-left:10px; font-family:"microsoft yahei"}
.bao_acc table td{border-left:1px solid #a4d6e9; text-align:center;height:30px;line-height:30px;border-bottom:1px solid #a4d5e9;}
.bao_acc table{border:1px solid #a4d6e9;border-left:none;border-bottom:none;font-size:13px;clear:both;}
.acc_tit{font-size:14px;font-weight:bold;padding-left:10px;border:1px solid #a4d6e9;border-bottom:none;width:683px;height:30px;line-height:30px;background:#ededed;font-family:"microsoft yahei"}
.bm_right .row{clear:both;margin-top:10px;}
.bm_right .row .tit{background:url(/statics/images/r2_bg.jpg) repeat-x;width:240px;height:29px;line-height:29px;border:1px solid #a4d6e9;font-size:14px;font-weight:bold;padding-left:8px;}
.bm_right .row .tit a{color:#059;}
.bm_right .row  ul{border:1px solid #a4d6e9;border-top:none;width:240px;padding-left:8px;padding-top:8px;padding-bottom:8px;}
.bm_right .row  ul li{line-height:24px;font-size:13px;}
.bm_right .row  ul li a{color:#059;}
.bm_right .row  ul li a span{color:red;padding-left:10px;}
.even{background:#effcff;}
.odd{background:#ffffef;}
.adv{margin-top:10px;}
.tab2 td{background:#fff;}
.tab2 td{border:1px solid #d0cfe1;padding-left:5px;vertical-align:middle;}
.tab2 td img{padding:0 4px;}
.new_tt{background:url(/statics/images/boda/temp/llt.jpg) repeat-x;width:100%;height:29px;line-height:29px;}
.new_center{height:160px;border-left:1px solid #e9e4e0;border-right:1px solid #e9e4e0;border-bottom:1px solid #e9e4e0;}
.new_center ul li{width:48%;float:left;line-height:22px;padding-left:10px;}
.new_center ul{margin:10px 0;}
.new_tt .tit{width:84px;height:25px;background:#225585;text-align:center;display:inline-block;font-size:14px;font-weight:bold;color:#fff;margin-top:4px;margin-left:8px;}
.new_tt .more{padding-left:80px;}

</style>
</head>
<script>
 $(function(){
  $(".tab1 tr:odd").addClass("odd");
  $(".tab1 tr:even").addClass("even");
 })

</script>


<body>


   <div id="main" >

   <div class="w_980"  >

        <div class="white_bg" style="margin-top:10px;" >

        <div class="w_960">

      <div class="nav">

         <div class="home"><a href="http://www.kaozc.com/" target="_blank" >首&nbsp;页</a></div>

         <dl class="ks">

          <dt><a href="http://www.kaozc.com/" target="_blank" >考试</a> </dt>

          <dd>

          <a href="http://www.kaozc.com/En/" target="_blank" style="color:#fff; border:none" >职称英语</a>

          <a href="http://www.kaozc.com/jsj/" target="_blank" >职称计算机</a>

          <a href="http://www.kaozc.com/zyzg/yy/" target="_blank" >医药卫生</a>

          <a href="http://www.kaozc.com/zyzg/ckl/" target="_blank"  style="color:#fff; border:none">金融财会</a>

          <a href="http://www.kaozc.com/zyzg/jz/" target="_blank" >建筑工程</a>

          <a href="http://www.kaozc.com/zyzg/sf/" target="_blank" >司法外贸</a>
          </dd>
          </dl>
          
           <dl class="dt">
          <dt><a href="http://www.kaozc.com/" target="_blank" >动态</a> </dt>
          <dd>

          <a href="http://www.kaozc.com/" target="_blank" style="color:#fff; border:none" >考试资讯</a>

          <a href="http://www.kaozc.com/" target="_blank" >考试报名</a>

          <a href="http://www.kaozc.com/" target="_blank" >准考证</a>

          <a href="http://www.kaozc.com/" target="_blank" >成绩查询</a>

          <a href="http://www.kaozc.com/" target="_blank" style="color:#fff; border:none">证书领取</a>

          <a href="http://www.kaozc.com/" target="_blank" >历年真题</a>
          
           <a href="http://www.kaozc.com/" target="_blank" >考试大纲</a>

          <a href="http://www.kaozc.com/list-286-1.html" target="_blank" >名师讲座</a>
          </dd>
          </dl>

          <dl class="hd">

           <dt><a href="http://www.kaozc.com/" target="_blank" >互动</a> </dt>

          <dd>
          <a href="http://cpzx.cdbroad.com/Booking.aspx" target="_blank" style="border:none">在线测评</a>

          <a href="http://www.cdbroad.com/mall/xxrj" target="_blank" >计算机辅导</a>

          <a href="http://www.cdbroad.com/mall/yy" target="_blank" style=" border:none">培训班 </a>

          <a href="http://www.cdbroad.com/mall/tkrj" target="_blank" >职业资格辅导 </a>

          </dd>

         </dl>

      </div>

     <div class="row_1">

        <div class="fl">热门关键词：<a href="http://www.kaozc.com/" target="_blank" >2013国家公务员</a> |<a href="http://www.kaozc.com/" target="_blank" >2013法检系统公招</a> |<a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank" >在线咨询</a> | <a href="http://www.kaozc.com/" target="_blank" >考试报名入口</a> | <a href="http://www.kaozc.com/" target="_blank" >职位查询入口</a> | <a href="http://www.kaozc.com/" target="_blank" >成绩查询入口</a></div>

         <div class="fr">

         <form class="serach" method="get">

           <input type="hidden" name="m" value="search"/>

			  <input type="hidden" name="c" value="index"/>

			  <input type="hidden" name="a" value="init"/>

			  <input type="hidden" name="typeid" value="<?php echo $typeid;?>" id="typeid"/>

			  <input type="hidden" name="siteid" value="<?php echo $siteid;?>" id="siteid"/>

          站内搜索：<input name="q" type="text" /><input name="" type="submit" value="搜索" class="ser_btn" />

         </form>

         </div>

   </div>

     <div class="row_2">

        <div class="area" >
<?php $catid=9?>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=623affb008b6dfb2aec0212ae4162666&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%29&cache=0&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>

<a title="<?php echo $v['name'];?>" href="<?php echo $CATEGORYS[$catid]['url'];?><?php echo $v['pinyin'];?>/"target=_blank><?php echo $v['name'];?><a> |

 <?php $n++;}unset($n); ?>

<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

    </div>

     <div class="stu_acc">

      <div class="fl">全国</div>

      <div class="fr">

         <div class="ds"><a target="_blank" href="http://www.kaozc.com/">学习入口</a></div>

         <div class="ds"><a target="_blank" href="http://www.kaozc.com/">模拟考场</a></div>

      </div>

     </div>

     </div>
      <div style="margin-top:10px;clear:both;"></div>
     <div class="cur_pos">当前位置：全国各省<?php echo $typearr['name'];?>系统</div>
     <div class="bm_left">
       <div class="new_center">
         <div class="new_tt"><span class="tit">新闻中心</span><font color="red">&nbsp;&nbsp;人事考试中心推荐：</font><a href="http://www.kaozc.com/En/english2013/" target="_blank"><font color="red">2013年职称英语考试绝密资料</font></a> <a href="http://www.kaogwy.com/gongwuyuan/" target="_blank"> <font color="red">2013年公务员考试官方培训班报名！</font></a> <span class="more"><a href="http://www.kaozc.com/" target="_blank">更多》</a></span></div>
        <ul>
          <li><b><a href="http://www.kaozc.com/zyzg/ckl/zqcy/" target="_blank"><font color="red">人事中心考试热点：证券从业报名入口</font></a></b></li>
          <li><b><a href="http://www.kaozc.com/En/" target="_blank"><font color="red">人事中心考试热点：2013职称英语新教材</font></a></b></li>
          <li><a href="http://www.kaozc.com/En/" target="_blank">新闻：2013年职称英语考试试题及答案汇总</a> </li>
          <li><a href="http://www.kaozc.com/zyzg/ckl/kjcy/" target="_blank">新闻：2013年初级会计报考 </a></li>
          <li><a href="http://www.kaozc.com/zyzg/jz/jzs1/" target="_blank">新闻：一级建造师名师解析/真题</a></li>
          <li><a href="http://www.kaozc.com/jsj/" target="_blank">新闻：计算机资格考试章节考点/全真试卷</a> </li>
          <li><a href="http://www.kaozc.com/En/" target="_blank">新闻：英语四六级试题答案及解析</a> </li>
          <li><a href="http://www.kaozc.com/zyzg/yy/" target="_blank">新闻：2013年护士执业资格考试报名专题</a></li>
          <li><a href="http://www.kaozc.com/jsj/" target="_blank">新闻：2013年全国计算机等级考试指南</a> </li>
          <li><a href="http://www.kaozc.com/zyzg/jz/jzs1/" target="_blank">新闻：2013年一级建造师报考条件解说专题</a> </li>

         </ul>
       </div>
       <div class="adv"><img src="/statics/images/boda/temp/ad4.jpg" width="692" height="58"></div>
   <table width="100%"  cellspacing="0" cellpadding="0"  class="tab2">
  <tr>
    <td colspan="4"  style="background:#3c67ac;height:35px;text-align:center;font-size:14px;font-weight:bold;color:#fff;">2013年职称英语家庭式培训班</td>
  </tr>
  <tr >
    <td width="25%" style="background:#dbe6ff;"><img src="/statics/images/boda/temp/en_t.jpg" width="168" height="39"></td>
    <td width="25%" class="font01" style="background:#dbe6ff;">VIP学员协议班</td>
    <td width="25%" class="font01" style="background:#dbe6ff;">零基础学员协议班</td>
    <td width="25%" class="font02" style="background:#dbe6ff;">强化冲刺班</td>
  </tr>
  <tr >
    <td height="33" class="font02">价格</td>
    <td class="font01">现价：850元</td>
    <td class="font01">现价：550元</td>
    <td class="font02">现价：280元</td>
  </tr>
  <tr>
    <td rowspan="3" class="font02">购买</td>
    <td height="36" >理工类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>理工类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>理工类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td height="36">卫生类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>卫生类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>卫生类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>

  </tr>
  <tr>
    <td height="36">综合类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>综合类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
    <td>综合类<a href="http://www.cdbroad.com/mall/yy" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td  class="font02">课程介绍</td>
    <td class="font03"><a href="http://www.cdbroad.com/mall/yy" target="_blank"><p> 49课专家视频，49课强化训练</p>
      <p>14课阶段性练习...了解详细》</p></a></td>
    <td class="font03"><a href="http://www.cdbroad.com/mall/yy" target="_blank"><p>49课专家视频，49课强化训练</p>
      <p>14课阶段性练习...了解详细》</p></a></td>
    <td class="font03"><a href="http://www.cdbroad.com/mall/yy" target="_blank"><p>2课专家视频培训，49课强化训练14课阶段性练习...了解详细》</p></a>
<p>&nbsp;</p></td>
  </tr>
  <tr>
    <td  class="font02">特色服务</td>
    <td class="font03"><p>班主任全程督导学习</p>
      <p>名师传授独家解题技巧</p>
      <p><font color="red">未通过，全额退款（保障服务）</font></p></td>
    <td class="font03"><p>班主任全程督导学习</p>
      <p>手把手教学，零基础过关无忧</p>
      <p><font color="red">未通过，全额退款（保障服务）</font></p></td>
    <td bgcolor="#FFFFFF" class="font03"><p>名师传授高分技巧</p>
      <p>冲刺高分的保障</p></td>
  </tr>
</table>
     <div style="margin-top:10px"></div>
    <table width="100%" cellspacing="0" cellpadding="0" class="tab2">
  <tr>
    <td colspan="4" style="background:#3c67ac;height:35px;text-align:center;font-size:14px;font-weight:bold;color:#fff;">2013年全国职称计算机考试辅导软件模块</td>
  </tr>
  <tr style="background:#dbe6ff;">
    <td width="26%" style="background:#dbe6ff;"><img src="/statics/images/boda/temp/jsj_t.jpg" width="168" height="39"></td>
    <td width="38%" class="font02" style="background:#dbe6ff;">模块介绍</td>
    <td width="18%" class="font02" style="background:#dbe6ff;">版本选择</td>
    <td width="18%" class="font02" style="background:#dbe6ff;">模块购买</td>
  </tr>
  <tr>
    <td style="background:#ebf7f7;" class="font04"><img src="/statics/images/boda/temp/pat_5.jpg" width="19" height="19">Internet应用</td>
    <td class="font03"><p>10套全真模拟，真实考试环境，考后即知成绩</p>
      <p>452道权威题目，免费在线升级，与人事考试题库同步.</p>
      </td>
    <td rowspan="5" class="font05"><p >协 议 版</p>
      <p>完 整 版</p>
      <p>手 把 手</p>
      <p>题 库 版</p></td>
    <td><a href="http://www.cdbroad.com/mall/xxrj" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td style="background:#ebf7f7;" class="font04"><img src="/statics/images/boda/temp/pat_4.jpg" width="19" height="19">Word2003</td>
    <td class="font03"><p>10套全真模拟，真实考试环境，考后即知成绩</p>
      <p>452道权威题目，免费在线升级，与人事考试题库同步.</p></td>
    <td><a href="http://www.cdbroad.com/mall/xxrj" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td style="background:#ebf7f7;" class="font04"><img src="/statics/images/boda/temp/pat_1.jpg" width="19" height="19">Excel2003</td>
    <td class="font03"><p>10套全真模拟，真实考试环境，考后即知成绩</p>
      <p>452道权威题目，免费在线升级，与人事考试题库同步.</p></td>
    <td><a href="http://www.cdbroad.com/mall/xxrj" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td style="background:#ebf7f7;" class="font04"><img src="/statics/images/boda/temp/pat_2.jpg" width="19" height="19">WindowsXP</td>
    <td class="font03"><p>10套全真模拟，真实考试环境，考后即知成绩</p>
      <p>452道权威题目，免费在线升级，与人事考试题库同步.</p></td>
    <td><a href="http://www.cdbroad.com/mall/xxrj" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
  <tr>
    <td style="background:#ebf7f7;" class="font04"><img src="/statics/images/boda/temp/pat_3.jpg" width="19" height="19">用友T3会计信息化软件</td>
    <td class="font03"><p>10套全真模拟，真实考试环境，考后即知成绩</p>
      <p>452道权威题目，免费在线升级，与人事考试题库同步.</p></td>
    <td><a href="http://www.cdbroad.com/mall/xxrj" target="_blank"><img src="/statics/images/boda/temp/zx_btn.jpg" width="43" height="22"></a><a href="http://www3.53kf.com/webCompany.php?arg=cdbroadcom&style=1&language=zh-
cn&lytype=0&charset=gbk&kflist=on&kf=sl864,lq834,ycy875,lilinglin,tanggl,zhoucl,qinwe
n,yushunlai,litingting,zhangjing,fanxuemei,zhouq835,lijanq,hr869,zhangyu,yangjiao,lin
j,lijiao867,xiangrj&zdkf_type=1&referer=http%3A%2F%2Fwww.kaozc.com%2Frenshibm%
2F&keyword=http%3A//www3.53kf.com/setting/chat_msg_list.php%3Fa%3Da%26kf_id6d%3D%
26search_type%3Dguest_referer%26search_text%3Dkaozc.com%26start_time%3D2013-01-10%
26end_time%3D2013-01-18%26order%3D11%26onlyguest%3D1%26select_chat_theme%3D%26del%
3D%26arg%3Dpcdbroadcom_5362243%26search_mode%3Dsimple%26page%3D4%26perpage%
3D30&tfrom=1&tpl=crystal_blue&timeStamp=1358734923750" target="_blank"><img src="/statics/images/boda/temp/gm_btn.jpg" width="43" height="22"></a></td>
  </tr>
</table>
    
<div style="margin-top:10px;clear:both;"></div>
<div class="bao_acc">
  <h2>全国各省近期<?php echo $typearr['name'];?>系统快速入口</h2>
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=a5a7bfa3e120a8bc426e1cea5788c353&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358)',)).'a5a7bfa3e120a8bc426e1cea5788c353');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tab1">
       <tr  >
         <div  class="acc_tit" ><?php echo $v['name'];?><?php echo $typearr['name'];?>快速通道</div>
       </tr>
        <tr>
        <?php $num = 0?>
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=217fa5b66638c0d440f3b376a333a1e6&sql=SELECT+%2A+FROM+v9_renshibaoming+WHERE+cityid+%3D+%27%24v%5Blinkageid%5D%27+AND+status+%3D+%271%27+and+typeid%3D%27%24typeid%27+and+siteid%3D%24this-%3Esiteid+order+by+id+asc&cache=0&return=data2&num=1000\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM v9_renshibaoming WHERE cityid = '$v[linkageid]' AND status = '1' and typeid='$typeid' and siteid=$this->siteid order by id asc LIMIT 1000");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data2 = $a;unset($a);?>
<?php $n=1; if(is_array($data2)) foreach($data2 AS $k => $val) { ?>
         <td>
         <?php if($val['filename']) { ?>
         <a href="<?php echo KSBM_PATH;?><?php echo $val['filename'];?>.html" target="_blank"><?php echo $val['title'];?></a>
         <?php } else { ?>
          <a href="<?php echo KSBM_PATH;?><?php echo $val['id'];?>.html" target="_blank"><?php echo $val['title'];?></a>
         <?php } ?>
         </td>
         <?php if(($k+1)%3==0) { ?></tr><tr><?php } ?>
         <?php $num++?>
     <?php $n++;}unset($n); ?>
     <?php 
     for($i=1; $i<2-$num%3; $i++){ 
     ?>
      <td>&nbsp;</td>
      <?php } ?>
        <td>&nbsp;</td><td>&nbsp;</td>
       </tr>

     </table>
       <div style="margin-top:10px;clear:both;"></div>
     <?php $n++;}unset($n); ?>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>  
   </div>
     </div>
     <div class="bm_right">
    <div class="adv" style="margin-top:0" id="PAGE_AD_552783"><!-- 广告位：右侧01 --></div>
     <div class="row" >
      <div class="tit">职称英语培训班</div>
      <ul >
       <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a20ff3ed493445e78edadc1e30b7be31&action=position&posid=196&order=listorder+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'196','order'=>'listorder DESC','limit'=>'10',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
 <li><a style="FONT-WEIGHT: normal" href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?>  title="<?php echo $r['title'];?>" target=_blank><?php echo str_cut(trim($r[title]),36,'');?><span>咨询报名》</span></a></li>
 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      </ul>
      </div>
       <div class="row">
      <div class="tit">职称计算机考试辅导</div>
      <ul >
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=4b04c3fdb9d5aeb43a7c0926587c654d&action=position&posid=197&order=listorder+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'197','order'=>'listorder DESC','limit'=>'10',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
 <li><a style="FONT-WEIGHT: normal" href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?>  title="<?php echo $r['title'];?>" target=_blank><?php echo str_cut(trim($r[title]),36,'');?><span>咨询报名》</span></a></li>
 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      </ul>
      </div>
       
       <div class="adv" id="PAGE_AD_552798"><!-- 广告位：右侧02 -->
</div>
       <div class="adv" id="PAGE_AD_552796"><!-- 广告位：右侧03 -->
</div> 
      <div class="adv" id="PAGE_AD_552786"><!-- 广告位：右侧04 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("552798");</script>
</div>
       <div class="row">
      <div class="tit"><a href="#" target="_blank">最新考试资讯</a></div>
      <ul >
               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=eca77723bdb126959c766e7fa42a2ea9&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription+FROM+v9_news+where+catid+in+%28420%2C187%29+AND+status%3D99+order+by+id+desc&cache=3600&page=%24page&return=data&start=0&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 10;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_news where catid in (420,187) AND status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description FROM v9_news where catid in (420,187) AND status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?> <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'50','');?></a></li>
       <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      </ul>
      </div>
      <div class="row">
      <div class="tit"><a href="#" target="_blank">名师辅导专栏</a></div>
      <ul >
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=ccc4b57f2fa112c142a11828d50a905d&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription+FROM+v9_news+where+catid+in+%28316%2C342%2C341%29+AND+status%3D99+order+by+id+desc&cache=3600&page=%24page&return=data&start=0&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 10;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_news where catid in (316,342,341) AND status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description FROM v9_news where catid in (316,342,341) AND status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?> <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'50','');?></a></li>
       <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

      </ul>
      </div>
      
     </div>
    </div>

</div>

</div>


     <div class="cl"></div>
     
        
      </div>
  </div>





  <div style="margin-top:10px;clear:both;">

 <?php include template("content","footer"); ?>

 </div>



</div>

</div>

<!--异步加载开始-->
 <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
 <script type="text/javascript">
    BAIDU_CLB_fillSlotAsync('552798','PAGE_AD_552798');
	BAIDU_CLB_fillSlotAsync('552796','PAGE_AD_552796');
	BAIDU_CLB_fillSlotAsync('552786','PAGE_AD_552786');
	BAIDU_CLB_fillSlotAsync('552783','PAGE_AD_552783');
	
</script>

<!--异步加载结束 --> 



</body>

</html>

