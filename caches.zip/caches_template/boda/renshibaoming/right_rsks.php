<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="listymrg">
<div class="kzc-newsone" id="<?php echo $ad_ids['1'];?>">load...</div>
        	<div class="rgcut">计算机推荐</div>
            <div class="rgctdv">
            	<ul>
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f03e0903495f10653fdf910390f3a3c9&action=hits&catid=11&num=10&order=views+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'11','order'=>'views DESC',)).'f03e0903495f10653fdf910390f3a3c9');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'11','order'=>'views DESC','limit'=>'10',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
                    <?php $i=1?>
                    <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                        <li><i <?php if($i>3) { ?>class="i1"<?php } ?>><?php echo $i;?></i><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 50, '');?></a></li>
                        <?php $i++?>
                    <?php $n++;}unset($n); ?>
                	<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
           <div class="kzc-newsone" id="<?php echo $ad_ids['2'];?>">load...</div>
            <div class="rgcut">职业资格推荐</div>
            <div class="rgctdv">
            	<ul>
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=8d1dddcec70866bd1fb0c1d7b7728e75&action=hits&catid=16&num=10&order=views+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'16','order'=>'views DESC',)).'8d1dddcec70866bd1fb0c1d7b7728e75');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'16','order'=>'views DESC','limit'=>'10',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
                    <?php $i=1?>
                    <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                        <li><i <?php if($i>3) { ?>class="i1"<?php } ?>><?php echo $i;?></i><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 50, '');?></a></li>
                        <?php $i++?>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
          
        </div>
        <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
 <?php
    //考职称英语
if(strstr($CATEGORYS[$catid]['arrparentid'],'0,9') or $catid == 9 ):
?>
BAIDU_CLB_fillSlotAsync("874630","ad1");
BAIDU_CLB_fillSlotAsync("874631","ad2");
 <?php
    //考职计算机
elseif(strstr($CATEGORYS[$catid]['arrparentid'],'0,9') or $catid == 9 ):
?>
BAIDU_CLB_fillSlotAsync("874633","ad1");
BAIDU_CLB_fillSlotAsync("874636","ad2");
 <?php
    //职业资格
elseif(strstr($CATEGORYS[$catid]['arrparentid'],'0,9') or $catid == 9 ):
?>
BAIDU_CLB_fillSlotAsync("874630","ad1");
BAIDU_CLB_fillSlotAsync("874631","ad2");
<?php endif; ?>
</script>