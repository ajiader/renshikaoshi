<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="rshead">

	<div class="rsxs">

        <div class="rstobanner"></div>

        <div class="rsmenu">

			<div class="rsctty">
            
        		<ul id="menua">

                    <li><a href="<?php echo siteurl($siteid);?>/" target="_blank">首页</a></li>
    
                    <li><a href="/jsj/" target="_blank">职称计算机</a></li>
    
                    <li><a href="/En/" target="_blank">职称英语</a></li>
    
                    <li><a href="/zyzg/yy/yxgjks/">医学高级</a></li>
    
                    <li><a href="/zyzg/yy/zyyaos/">执业药师</a></li>
    
                    <li><a href="/zyzg/yy/zyys/" target="_blank">执业医师</a></li>
    
                    <li><a href="/zyzg/jz/jzs1/">一级建造师</a></li>
    
                    <li><a href="/zyzg/jz/ejjzs/" target="_blank">二级建造师</a></li>
                    
                    <li><a href="/download/" target="_blank">学习资料免费下载</a></li>
    
                </ul>
            
            </div>

        </div>

        

    </div>

</div>


<div class="rsctty">

<div class="rshotnew"><h1><?php echo $seotitle;?></h1>网上报名入口(<?php echo $url;?>)</div>
<div class="rscitydq">

     <?php if($cityid>0) { ?>
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=14de1a49cb53ace1373ac1f8a649b88e&sql=SELECT+%2A+FROM+v9_renshibaoming+WHERE+cityid+%3D+%27%24cityid%27+AND+status+%3D+%271%27+and+typeid%3D%27104%27+and+siteid%3D1+order+by+id+asc&cache=0&return=data2&num=50\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM v9_renshibaoming WHERE cityid = '$cityid' AND status = '1' and typeid='104' and siteid=1 order by id asc LIMIT 50");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data2 = $a;unset($a);?>
    <?php if($data2) { ?>
     <span>当前城市的下级导航</span>
 <div class="xjct">
    <?php $n=1; if(is_array($data2)) foreach($data2 AS $k => $val) { ?> 
     <?php if($val['filename']) { ?>
             <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $val['filename'];?>.html" title="<?php echo $val['seotitle'];?>" target="_blank"><?php echo $val['title'];?></a>
             <?php } else { ?>
              <!-- <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $val['id'];?>.html" target="_blank"><?php echo $val['title'];?></a> -->
             <?php } ?>
     <?php $n++;}unset($n); ?>
     </div> 
     <?php } ?>
    <?php } ?>
    
    <div class="clear"></div>
</div>
	