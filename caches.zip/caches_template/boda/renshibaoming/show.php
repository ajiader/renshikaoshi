<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $SEO['title'];?></title>
<meta name="keywords" content="<?php echo $SEO['keywords'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/kaozc/css/rsstyle.css?d=20150114" />
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script language="javascript" src="/statics/kaozc/js/qhnews.js"></script>
<script language="javascript" src="/statics/kaozc/js/jq_scroll.js"></script>
<script language="javascript" src="/statics/zyzg/js/qh.js"></script>
<script language="javascript" src="/statics/js/53kefu.js"></script>
<script language="javascript" src="http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js&"></script>
<script type="text/javascript">

$(document).ready(function(){

$("#teacheryiwen").Scroll({line:1,speed:500,timer:3000});
});

</script>
<script type="text/javascript">
$(document).ready(function(){
$("#menua li").mousemove(function(){$(this).find("div").show();});
$("#menua li").mouseleave(function(){$(this).find("div").hide();});
});
</script>
<script type="text/javascript">
function hftb(){
  window.open("http://item.taobao.com/item.htm?spm=a1z10.1.w6842337-6518291215.31.Q60c6b&id=37117006912","_blank");
}
</script>
</head>
<body>
 <?php include template("renshibaoming","header"); ?>
    <div class="gwyadd" style="padding-bottom:0px;">
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" target="_blank">职称计算机考试题</a>
        <a href="http://www.renshikaoshi.net/jsj/" target="_blank">报名入口</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" target="_blank">职称计算机真题</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" target="_blank">3小时过职称计算机</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" target="_blank">职称计算机模拟软件</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/jsjwz.html" target="_blank">职称计算机零基础保过</a>
    </div>
    
    <div id="PAGE_AD_943278"></div>
    
    <div class="gwyadd" style="padding-top:0px;">
        <a href="http://www.renshikaoshi.net/download/" target="_blank">职业资格考试题库</a>
        <a href="http://www.renshikaoshi.net/download/zhichenyingyu/" target="_blank">职称英语通关秘诀</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" target="_blank">职称计算机考试模拟题</a>
        <a href="http://www.renshikaoshi.net/download/zhichenyingyu/" target="_blank">职称英语通关技巧</a>
        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/jsjcc.html" target="_blank">10元过职称计算机</a>
        <a href="http://www.renshikaoshi.net/download/zhichenyingyu/" target="_blank">职称英语通关攻略</a>
    </div>



<div class="computerctone rstymgbt">

    	<div class="computeroneleft">

        <!-- 广告位：仿人事-幻灯片 -->

        <div id="PAGE_AD_943280"></div>

    	</div>

        

        <div class="computeronecenter">

			<div class="newstitle"><span class="sp1">新闻中心</span><span class="sp2"><a href="<?php echo $CATEGORYS['11']['url'];?>" target="_blank">职业资格</a><a href="<?php echo $CATEGORYS['10']['url'];?>"  target="_blank">职称计算机</a><a href="<?php echo $CATEGORYS['9']['url'];?>"  target="_blank">职称英语</a></span></div>

            <ul class="tyullist">

             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=8d7ab5180f9c8971f86820079296b099&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24title%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$title%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$title%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

            <?php $i=1?>

            <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>

            	<li><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo str_cut($r[title],70,'');?></a><?php if($i<4) { ?><img src="/statics/kaozc/images/newsicon2.jpg" /><?php } ?></li>

              <?php $i++?>

                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

        </div>

        

        <div class="computeroneright">

           	 <div class="newstitle"><span class="sp1">考试辅导</span><span class="sp2"><a href="#">更多>></a></span></div>

             <ul class="tyullist">

             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c5962863507bc93c225ccabd39aae2d8&action=position&posid=296&order=listorder+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'296','order'=>'listorder DESC','limit'=>'8',));}?>

             <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>

            	<li> <a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo $val['title'];?></a></li>

                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

       	</div>

        <div class="newsclear"></div>

    </div>
    
    
    <!-- 职称计算机考试 -->
    <div class="computerstudycut"><span class="lftitle">职称计算机考试</span></div>
	<div class="computerctone rstymgbt hgl">

    	<div class="computeroneleft hglsp" id="PAGE_AD_943283">

			<!-- 广告位：仿人事-下左-计算机图文环绕 -->

    	</div>

        

        <div class="computeronecenter hgl wdtwo">

            <ul class="tyullist">

            	     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d965e4b6a5fe028873b099d8cf8a4f04&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24title%25%27+and+title+like+%27%25%E8%AE%A1%E7%AE%97%E6%9C%BA%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$title%' and title like '%计算机%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$title%' and title like '%计算机%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

 <?php if(!$data) { ?>

<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=1a1ef8f4d14942de7caa4efcbf980b79&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24cityname%25%27+and+title+like+%27%25%E8%AE%A1%E7%AE%97%E6%9C%BA%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$cityname%' and title like '%计算机%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$cityname%' and title like '%计算机%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

<?php } ?>

                   <?php $i=1?>

                 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                <li><span>(<?php echo date('Y-m-d',$r['updatetime']);?>)</span><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'70','');?></a><?php if($i<4) { ?><img src="/statics/kaozc/images/newsicon2.jpg" /><?php } ?></li>

   <?php $i++?>

  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

        </div>

        

        <div class="computeroneright hgl bgone wdone">

        	 <span class="spancut">职称计算机考试指南</span>

             <ul class="tyullist">

            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f656e534ea1a694f8815957e98e4ba24&action=position&posid=295&order=listorder+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'295','order'=>'listorder DESC','limit'=>'7',));}?>

             <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>

            	<li> <a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut(trim($val[title]),'40','');?></a></li>

                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

       	</div>

        <div class="newsclear"></div>

    </div>
    
    
    <!-- 考试模块 -->
    <div class="computerstudynr rstymgbt">
		<div class="rstymgbt"><?php echo $diycode;?></div>
        <h2 class="h2js">2015年考试宝典职称计算机考试模拟题-全真题库，模拟真实考试操作，全国同类题库过关率最高，过万考生好评<a href="javascript:hftb()">[查看评价]</a></h2>
        <ul>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/pointer2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">PowerPoint2007</a><br>科目代码：213 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/excel2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">Excel2007</a><br>科目代码：212 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/word2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">Word2007</a><br>科目代码：211 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/Internet.jpg"></a><a href="javascript:hftb()" rel="nofollow">Internet应用</a><br>科目代码：303 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/PowerPoint2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">PowerPoint2003</a><br>科目代码：207 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/Excel2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">Excel2003</a><br>科目代码：206 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/wrod2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">Word2003</a><br>科目代码：205 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/xp.jpg"></a><a href="javascript:hftb()" rel="nofollow">WindowsXP</a><br>科目代码：102 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">FrontPage2003</a><br>科目代码：305 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/jswz.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山文字2005</a><br>科目代码：208 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/jsbg.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山表格2005</a><br>科目代码：209 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/jsys.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山演示2005</a><br>科目代码：210 常考模块</li>

            <li class="duoa"><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/wpsoffice.jpg"></a><a href="javascript:hftb()" rel="nofollow">WPSOffice办公组合中文字处理</a><br>科目代码：204 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">FrontPage2000</a><br>科目代码：302 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/cad.jpg"></a><a href="javascript:hftb()" rel="nofollow">AutoCAD2004</a><br>科目代码：503 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/u8.jpg"></a><a href="javascript:hftb()" rel="nofollow">用友U8</a><br>科目代码：403 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/VisualFoxPro.jpg"></a><a href="javascript:hftb()" rel="nofollow">VisualFoxPro5.0</a><br>科目代码：401 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Flash.jpg"></a><a href="javascript:hftb()" rel="nofollow">FlashMX2004动画制作</a><br>科目代码：504 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Authorware.jpg"></a><a href="javascript:hftb()" rel="nofollow">Authorware7.0</a><br>科目代码：505 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">Project2000项目管理</a><br>科目代码：901 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Access2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">Access2000</a><br>科目代码：402 常考模块</li>

            <li class="duoa"><a href="javascript:hftb()"><img src="/statics/kaozc/images/ps.jpg"></a><a href="javascript:hftb()" rel="nofollow">PhotoshopCS4图像处理</a><br>科目代码：506 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/u8.jpg"></a><a href="javascript:hftb()" rel="nofollow">用友T3会计信息化软件</a><br>科目代码：404 常考模块</li>

        

        </ul>

        <div class="newsclear"></div>

   	</div>
    

	<!-- 职业资格考试 -->
    <div class="computerstudycut"><span class="lftitle">职业资格考试信息</span></div>   
    <div class="computerctone rstymgbt hgl">

    	<div class="computeroneleft hglsp" id="PAGE_AD_943282">

			<!-- 广告位：仿人事-下左-致睿图文环绕 -->

    	</div>

        

        <div class="computeronecenter hgl wdtwo">

            <ul class="tyullist">

            	 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=794492d6a3e05e9ddb22a95f03793223&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24title%25%27+and+title+like+%27%25%E8%B5%84%E6%A0%BC%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$title%' and title like '%资格%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$title%' and title like '%资格%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

 <?php if(!$data) { ?>

<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=0fcebdbe6f3223435b6753a52e0eb3f2&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24cityname%25%27+and+title+like+%27%25%E8%B5%84%E6%A0%BC%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$cityname%' and title like '%资格%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$cityname%' and title like '%资格%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

<?php } ?>

                   <?php $i=1?>

                 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

  <li><span>(<?php echo date('Y-m-d',$r['updatetime']);?>})</span><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'70','');?></a><?php if($i<4) { ?><img src="/statics/kaozc/images/newsicon2.jpg" /><?php } ?></li>

   <?php $i++?>

  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

        </div>

        

        <div class="computeroneright hgl bgone wdone">

        	 <span class="spancut">考试专题<a href="#">更多>></a></span>

             <ul class="tyullist">

            	 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=71d5776c8340b1496c4c190e53632387&action=position&posid=293&order=listorder+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'293','order'=>'listorder DESC','limit'=>'7',));}?>

             <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>

            	 <li> <a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut(trim($val[title]),'40','');?></a></li>

                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

       	</div>

        <div class="newsclear"></div>

    </div>
    
    <!-- 职业资格考试题库下载 -->
    <dl class="daohang">
  <dt>
    <h1>软件分类导航</h1>
    <span>热门标签：<a target="_blank" href="/download/yiyaokaoshi/gaojizhichen/">医学高级</a> <a target="_blank" href="/download/yiyaokaoshi/weishengzige/">卫生资格</a> <a target="_blank" href="/download/zhichenyingyu/">职称英语</a> <a target="_blank" href="/download/jisuanjilei/zhichenjisuanji/">职称计算机</a></span></dt>
    <dd>
    <h2><a href="/download/yiyaokaoshi/">医药考试</a></h2>
    <ul>
       <li><a target="_blank" href="/download/yiyaokaoshi/zhiyeyishi/">执业医师</a></li><li><a style="color:#e10000;" target="_blank" href="/download/yiyaokaoshi/gaojizhichen/">医学高级</a></li><li><a target="_blank" href="/download/yiyaokaoshi/">卫生资格</a></li><li><a target="_blank" href="/download/yiyaokaoshi/yaoxuezhicheng/">药师资格</a></li><li><a target="_blank" href="/download/yiyaokaoshi/zhuyuanyishi/">住院医师</a></li><li><a target="_blank" href="/download/yiyaokaoshi/hulikaoshi/">护士考试</a></li><li><a target="_blank" href="/download/yiyaokaoshi/yixuesanji/">医学三基</a></li><li><a style="color:#e10000;" target="_blank" href="/download/yiyaokaoshi/zhiyeyaoshi/soft1238.html">执业药师(西药)</a></li><li><a target="_blank" href="/download/yiyaokaoshi/zhiyeyaoshi/soft1239.html">执业药师(中药)</a></li>    
   <li><a style="color:#e10000;" target="_blank" href="/download/yiyaokaoshi/zhiyeyishi/soft2107.html">临床执业医师</a></li><li><a target="_blank" href="/download/yiyaokaoshi/gaojizhichen/hulixilie/soft1242.html">外科护理高级职称</a></li><li><a style="color:#e10000;" target="_blank" href="/download/yiyaokaoshi/gaojizhichen/fuchankexilie/soft1269.html">妇产科高级职称</a></li><li><a target="_blank" href="/download/yiyaokaoshi/zhuzhiyishi/neikexilie/soft2123.html">内科主治医师</a></li><li><a target="_blank" href="/download/yiyaokaoshi/gaojizhichen/hulixilie/soft1244.html">内科护理高级职称</a></li><li><a target="_blank" href="/download/yiyaokaoshi/zhuzhiyishi/fuchankexilie/soft1345.html">妇产科主治医师</a></li> </ul>
    <br class="clear">
  </dd>
  <dd>
    <h2><a href="/download/jianzhugongcheng/">建筑工程</a></h2>
    <ul>
       <li><a target="_blank" href="/download/jianzhugongcheng/yijijianzaoshi/">一级建造师</a></li><li><a target="_blank" href="/download/download/jianzhugongcheng/gongchengshizhicheng/">土地代理人</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2260.html">环境评价师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/zhucejianzhushi/soft2268.html">一级建筑师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/">中级质量师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2259.html">注册安全师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/">资产评估师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2251.html">注册电气师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2267.html">监理工程师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/zhucejianzhushi/soft2246.html">二级建筑师</a></li><li><a style="color:#e10000;" target="_blank" href="/download/jianzhugongcheng/erjijianzaoshi/">二级建造师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2258.html">招标师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/">初级质量师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2257.html">土地估价师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2265.html">房地产估价</a></li><li><a target="_blank" href="/download/zhiyezige/wuyeguanlishi/soft2256.html">物业管理师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2255.html">设备监理师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2264.html">造价工程师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/">房产经纪人</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2263.html">一级结构师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2252.html">注册岩土师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2261.html">投资项目管理师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2250.html">城市规划师</a></li><li><a target="_blank" href="/download/jianzhugongcheng/gongchengshizhicheng/soft2262.html">咨询工程师</a></li> 
    </ul>
    <br class="clear">
  </dd>
  <dd>
    <h2><a href="/download/caihuijingji/">财会经济</a></h2>
    <ul>
      <li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2304.html">保险代理</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2310.html">基金从业</a></li><li><a target="_blank" href="/download/caihuijingji/caihuikaoshi/soft2323.html">会计电算化</a></li><li><a target="_blank" href="/download/caihuijingji/jingjishikaoshi/zhongjijingjishi/">中级经济师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2309.html">期货从业</a></li><li><a target="_blank" href="/download/caihuijingji/caihuikaoshi/soft2321.html">初级会计师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2308.html">保险公估人</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2320.html">银行从业</a></li><li><a target="_blank" href="/download/caihuijingji/jingjishikaoshi/chujijingjishi/">初级经济师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2305.html">保险经纪人</a></li><li><a style="color:#e10000;" target="_blank" href="/download/caihuijingji/caihuikaoshi/soft2317.html">中级会计师</a></li><li><a target="_blank" href="/download/caihuijingji/caihuikaoshi/soft2322.html">注册会计师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/">注册税务师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2367.html">理财规划师</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/soft2312.html">证券从业</a></li><li><a target="_blank" href="/download/caihuijingji/jinrongkaoshi/">证券经纪人</a></li> 
    </ul>
    <br class="clear">
  </dd>
  
  <dd>
    <h2><a href="/download/zhichenyingyu/">职称英语</a></h2>
    <ul>
      <li><a href="/download/zhichenyingyu/ligongxue/">理工类</a></li>
 <li><a href="/download/zhichenyingyu/weishengxue/">卫生类</a></li>
 <li><a href="/download/zhichenyingyu/zonghelei/">综合类</a></li>
      <li class="point"><a href="/download/zhichenjisuanji/">计算机类</a></li>
      <li><a target="_blank" href="/download/zhichenjisuanji/">职称计算机</a></li> 
      
    </ul>
    
    <br class="clear">
  </dd>
  
  <dd>
    <h2><a href="/download/waimaokaoshi/">外贸考试</a></h2>
    <ul>
       <li><a target="_blank" href="/download/zhiyezige/wuliushi/">物流师</a></li> 
      <li class="point"><a href="/download/xuelikaoshi/">学历考试</a></li>
       <li><a target="_blank" href="/download/qita/shuoshi/">考研</a></li>
    </ul>
    <br class="clear">
  </dd>
  <dd style="border-bottom:0">
    <h2><a href="/download/zhiyezige/">职业资格</a></h2>
    <ul>
       <li><a target="_blank" href="/download/zhiyezige/jiaoshizige/">教师资格</a></li><li><a target="_blank" href="/download/zhiyezige/renliziyuanshi/">人力资源师</a></li><li><a target="_blank" href="/download/zhiyezige/xinlizixunshi/">心理咨询师</a></li><li><a target="_blank" href="/download/qita/sifakaoshi/">司法考试</a></li><li><a target="_blank" href="/download/qita/gongwuyuan/">公务员</a></li><li><a target="_blank" href="/download/qita/shenzhenzhiyuankaoshi/">深圳职员</a></li>
    </ul>
    <br class="clear">
  </dd>
  
  
</dl>


 	<!-- 职称英语考试 -->

    <div class="computerstudycut"><span class="lftitle">职称英语考试</span></div>
    <div class="computerctone rstymgbt hgl">

    	<div class="computeroneleft hglsp" id="PAGE_AD_943281">

			<!-- 广告位：仿人事-下左-英语图文环绕 -->

    	</div>

        

        <div class="computeronecenter hgl wdtwo">

            <ul class="tyullist">

            	

    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d16cf6f58b93b03b6078abbecf1a9516&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24title%25%27+and+title+like+%27%25%E8%8B%B1%E8%AF%AD%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$title%' and title like '%英语%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$title%' and title like '%英语%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

 <?php if(!$data) { ?>

<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=263f7c467e3a8df18496a6f1530984f8&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+phpcms_news+where+title+like+%27%25%24cityname%25%27+and+title+like+%27%25%E8%8B%B1%E8%AF%AD%25%27+and+status%3D99+order+by+id+desc&page=%24page&num=8++urlrule%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 8;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  phpcms_news where title like '%$cityname%' and title like '%英语%' and status=99 order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM phpcms_news where title like '%$cityname%' and title like '%英语%' and status=99 order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>

<?php } ?>

                   <?php $i=1?>

                 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                <li><span>(<?php echo date('Y-m-d',$r['updatetime']);?>})</span><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'70','');?></a><?php if($i<4) { ?><img src="/statics/kaozc/images/newsicon2.jpg" /><?php } ?></li>

   <?php $i++?>

  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

        </div>

        

        <div class="computeroneright hgl bgone wdone">

        	 <span class="spancut">职称英语考试指南</span>

             <div class="dvbor">
            	<a href="http://www.renshikaoshi.net/kaoshi-154-110018-1.html">考试简介</a><a href="http://www.renshikaoshi.net/kaoshi-154-110027-1.html">报名时间</a><a href="http://www.renshikaoshi.net/kaoshi-154-110026-1.html">考试时间</a><a href="http://www.renshikaoshi.net/kaoshi-154-113623-1.html">考试题型</a><a href="http://www.renshikaoshi.net/kaoshi-154-110029-1.html">考试内容</a><a href="http://www.renshikaoshi.net/tg/zcyy/zz/">考试用书</a><a href="http://www.renshikaoshi.net/kaoshi-154-89297-1.html">免考规定</a><a href="http://www.renshikaoshi.net/En/ksdt/cjcx/">成绩查询</a><a href="http://www.renshikaoshi.net/kaoshi-154-110296-1.html">成绩有效期</a><a href="http://www.renshikaoshi.net/kaoshi-154-113624-1.html">考试级别</a><a href="http://www.renshikaoshi.net/kaoshi-154-110277-1.html">合格标准</a><a href="http://www.renshikaoshi.net/En/ksdt/zslq/">证书领取</a>
            </div>

    	</div>
        <div class="newsclear"></div>

    </div>
    

    <div class="addfooter">
    
    	<div class="rscitydq ftssrk">
        	<span>考试专栏</span>
            <div class="xjct">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3c4a9342f60081a7d7d4c5fcee925738&sql=SELECT+%2A+from+phpcms_diypage+WHERE+cityid+in+%28%24arrchildid%29+and+level%3D1+order+by+id+desc&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE cityid in ($arrchildid) and level=1 order by id desc LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
<a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a>
<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </div>
            <div class="clear"></div>
        </div>
		
        <div class="rscitydq ftssrk">
        	<span>省市入口</span>
            <div class="xjct">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $v['pinyin'];?>.html" target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?>人事考试网</a>
<?php $n++;}unset($n); ?>
            </div>
            <div class="clear"></div>
        </div>
        

    </div>
    <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
	<script type="text/javascript">   
		<!-- 广告位：地方人事-图文环绕 -->
		BAIDU_CLB_fillSlotAsync('943278', 'PAGE_AD_943278');
		<!-- 广告位：地方人事-幻灯片 -->
		BAIDU_CLB_fillSlotAsync('943280', 'PAGE_AD_943280');
		<!-- 广告位：人事页面-职称英语 -->
		BAIDU_CLB_fillSlotAsync('943281', 'PAGE_AD_943281');
		<!-- 广告位：地方人事-职业资格 -->
		BAIDU_CLB_fillSlotAsync('943282', 'PAGE_AD_943282');
		<!-- 广告位：地方人事-职称计算机 -->
		BAIDU_CLB_fillSlotAsync('943283', 'PAGE_AD_943283');
    </script>



</div>
<?php include template("content","rsks_bottom"); ?>
</body>

</html>

