<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php include template("zrmokuai","header"); ?>
	</div>
    <table cellpadding="0" cellspacing="0" class="zg_listtable">
        <tr class="bg1">
            <td colspan="10"><?php echo $type_list[$typeid]['name'];?></td>
        </tr>
        <tr>
            <td width="68"><strong>总块数</strong></td>
            <td width="64"><?php echo $type_list[$typeid]['count']['count_num'];?>个</td>
            <td width="64"><strong>总题量</strong></td>
            <td width="98"><?php echo intval($type_list[$typeid]['count']['name_num']);?></td>
            <td width="127"></td>
            <td width="57"></td>
            <td width="124"></td>
            <td width="42"></td>
            <td width="204"></td>
            <td width="108"></td>
        </tr>
        <tr>
            <td width="68"><strong>售价</strong></td>
            <td width="90">133元/模块</td>
            <td colspan="8">点击以下模块名称查看详情</td>
        </tr>
        <?php if($type_list[$typeid]['child'] == 1) { ?> <!--有子类情况-->
        <?php $n=1;if(is_array($type_list[$typeid]['zilei'])) foreach($type_list[$typeid]['zilei'] AS $c) { ?>
        <tr>
            <td colspan="10"><strong><?php echo $c['name'];?>（<?php echo $c['count']['count_num'];?>）个</strong></td>
        </tr>
        <tr>
        <?php
        $typeid = $c['linkageid'];
        $num=1;
        ?>
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d1d70d63106cb7084ecef5f3fc437a09&sql=SELECT+%2A+FROM+v9_zirui_mokuai+where+typeid%3D+%24typeid&cache=0&return=data&num=100\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM v9_zirui_mokuai where typeid= $typeid LIMIT 100");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
          <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
            <td width="96"><a href="<?php echo siteurl($siteid);?>/zrmokuai/<?php echo $r['id'];?>.html" target="_blank"><?php echo $r['name'];?></a></td>
            <?php if($num%10==0) { ?></tr><tr><?php } ?>
            <?php $num++?>
            <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </tr>
        
        <?php $n++;}unset($n); ?>
        <?php } else { ?> <!--无子类情况-->

          <tr>
        <?php
        $num=1;
        ?>
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d1d70d63106cb7084ecef5f3fc437a09&sql=SELECT+%2A+FROM+v9_zirui_mokuai+where+typeid%3D+%24typeid&cache=0&return=data&num=100\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM v9_zirui_mokuai where typeid= $typeid LIMIT 100");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
          <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
            <td width="96"><a href="<?php echo siteurl($siteid);?>/zrmokuai/<?php echo $r['id'];?>.html" target="_blank"><?php echo $r['name'];?></a></td>
            <?php if($num%10==0) { ?></tr><tr><?php } ?>
            <?php $num++?>
            <?php $n++;}unset($n); ?>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </tr>
        <?php } ?><!--判断子类情况结束-->
    </table>
     <?php include template("content","footer"); ?>
          <!--异步加载开始-->
 <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
 <script type="text/javascript">
 <!--图文-->
   // BAIDU_CLB_fillSlotAsync('728639','728639');
 -->
</script>
<!-- 广告位：致睿-查询-浮窗 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("749415");</script>
<!--异步加载结束 --> 
</div>
</body>
</html>
