<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if($r['name']) { ?><?php echo $r['name'];?>_<?php } ?>职业资格查询系统</title>

 <link rel="stylesheet" type="text/css" href="<?php echo JS_PATH?>calendar/jscal2.css">
<link rel="stylesheet" type="text/css" href="<?php echo JS_PATH?>calendar/border-radius.css">
<link rel="stylesheet" type="text/css" href="<?php echo JS_PATH?>calendar/win2k.css">
<script type="text/javascript" src="<?php echo JS_PATH?>calendar/calendar.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH?>calendar/lang/en.js"></script>
<script language="javascript">
window.onload=function()
{
	var txt=document.getElementById("mgseletxt");
	txt.onclick=function()
	{
		document.getElementById("mfseleul").style.display="block";	
	}
	var mful=document.getElementById("mfseleul").getElementsByTagName("li");
	for(var i=0; i<mful.length; i++)
	{
		mful[i].onclick=function()
		{
			txt.value=this.innerHTML;
			document.getElementById("mfseleul").style.display="none";
		}	
	}	
}
</script>
<link type="text/css" rel="stylesheet" href="<?php echo CSS_PATH;?>boda/zg_search.css" />
</head>

<body>
<?php if($_GET['iframe'] != 1) { ?>
<div class="zg_searchtop"><img src="<?php echo IMG_PATH;?>zrmokuai/top_img.jpg" /></div>
<div class="zg_topbg">
	<div class="zg_topbgcenter">
    	<div class="searchdiv">
        <form method="get" action="<?php echo siteurl($siteid);?>/zrmokuai/"><label>模块搜索</label><input type="text" name="q" class="searchtxt" /><input type="submit" name="searchbtn" class="searchbtn" value="查询" />
        <input type="hidden" name="m" value="zrmokuai">
        </form>
        </div>
    </div>
</div>
<?php } ?>
<div class="zg_searchtop">
<?php if($_GET['iframe'] != 1) { ?>
	<div class="zg_menu">
    	<span class="menutitle">分类<br />检索</span>
        <span class="menuclass">
        <?php $n=1;if(is_array($type_list)) foreach($type_list AS $v) { ?><a href="<?php echo siteurl($siteid);?>/zrmokuai/type_<?php echo $v['linkageid'];?>.html" <?php if($v['linkageid']==$typeid) { ?> class="selected"<?php } ?>><?php echo $v['name'];?></a> <?php $n++;}unset($n); ?></span>
    </div><?php } ?>
    <div class="zg_content">
     <form method="get" action="<?php echo siteurl($siteid);?>/zrmokuai/">
      <input type="hidden" name="m" value="zrmokuai">
		<span class="span1"><label class="bel1">高级搜索</label><label>类别</label><select name="typeid">
        <option value="">请选择</option>
        <?php $n=1;if(is_array($type_list)) foreach($type_list AS $v) { ?>
        <option value="<?php echo $v['linkageid'];?>"  <?php if($v['linkageid'] == $typeid) { ?> selected="selected"<?php } ?>><?php echo $v['name'];?></option>
        <?php $n++;}unset($n); ?>
        </select>
        
        <label>上市时间</label><input type="text" name="start_time" id="start_time" value="<?=$start_time?>" size="21" class="put2" readonly=""><script type="text/javascript">
      Calendar.setup({
      weekNumbers: true,
        inputField : "start_time",
        trigger    : "start_time",
        dateFormat: "%Y-%m-%d",
        showTime: true,
        minuteStep: 1,
        onSelect   : function() {this.hide();}
      });
        </script>
        <label>至</label>
        <input type="text" name="end_time" id="end_time" value="<?=$end_time?>" size="21" class="put2" readonly=""><script type="text/javascript">
      Calendar.setup({
      weekNumbers: true,
        inputField : "end_time",
        trigger    : "end_time",
        dateFormat: "%Y-%m-%d",
        showTime: true,
        minuteStep: 1,
        onSelect   : function() {this.hide();}
      });
        </script>
        <label>考试时间</label>
        <select name="kstime">
        <option>选择月份</option>
        <?php $n=1; if(is_array($this->marr)) foreach($this->marr AS $k => $v) { ?>
        <option value="<?php echo $v;?>" <?php if($bmtime == $v) { ?> selected="selected"<?php } ?>><?php echo $v;?>月</option>
        <?php $n++;}unset($n); ?>
        </select>
        <input type="submit" class="put3" value="搜索" />
        </span>
  <?php if($_GET['iframe']==1) { ?>
  <input type="hidden" name="iframe"  value="1" />    <?php } ?>  
        </form>
        <div style="clear:both;"></div>
        <span class="span1 span2">按字母查询：<?php $n=1; if(is_array($this->zmarr)) foreach($this->zmarr AS $k => $v) { ?>
        <a href="<?php echo siteurl($siteid);?>/zrmokuai/?zm=<?php echo $v;?><?php if($_GET['iframe']==1) { ?>&iframe=1<?php } ?>" <?php if(strtoupper($v)==strtoupper($zm)) { ?>class="selected"<?php } ?>><?php echo strtoupper($v);?></a><?php $n++;}unset($n); ?>
</span>