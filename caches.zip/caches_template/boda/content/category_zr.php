<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<script language="javascript" src="/statics/renshikaoshi/js/dvqh.js"></script>
<script language="javascript">
$(document).ready(function(){
	$('#ckksA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#ckksDIV > ul").eq($('#ckksA a').index(this)).show().siblings().hide();
	});
	$('#jzgcA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#jzgcDIV > ul").eq($('#jzgcA a').index(this)).show().siblings().hide();
	});
	$('#yywsA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#yywsDIV > ul").eq($('#yywsA a').index(this)).show().siblings().hide();
	});
	$('#sfksA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#sfksDIV > ul").eq($('#sfksA a').index(this)).show().siblings().hide();
	});
	$('#wmksA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#wmksDIV > ul").eq($('#wmksA a').index(this)).show().siblings().hide();
	});
	$('#qtksA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#qtksDIV > ul").eq($('#qtksA a').index(this)).show().siblings().hide();
	});
});
</script>
</head>

<body>
<?php include template("content","rsks_top"); ?>

<div class="cy-tyct">
	<div class="kzc-jsj-top">
    	<div class="kzc-jsj-lfpic">
            <div class="slider-wrapper theme-default">
                <div class="ribbon"></div>
                <div id="sliderjsj" class="nivoSlider">
                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bd23d84035c56b358e31732c1c2a8046&action=position&posid=109&order=listorder+DESC&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'109','order'=>'listorder DESC','limit'=>'5',));}?> <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                        <a href="<?php echo $val['url'];?>"><img src="<?php echo thumb($val['thumb'],308,272);?>" title="<?php echo $val['title'];?>" /></a>
                         <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>      
                </div>
            </div>
        	<script type="text/javascript" src="/statics/renshikaoshi/js/jquery.nivo.slider.pack.js"></script>
			<script type="text/javascript">
            $(window).load(function() {
                $('#sliderjsj').nivoSlider();
            });
            </script>
        </div>
        
        <div class="kzc-jsj-ctnew">
        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a22f9bcddd453c26ecaff1beaf8c42b9&action=lists&catid=255&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        	<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'45','');?></a></h2>
            <p class="hotcontent"><?php echo str_cut($r['description'],152);?> <a href="<?php echo $r['url'];?>" target="_blank">详细>></a></p>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7ad127dca235ef7ffee8711cfb5a8e48&action=lists&catid=255&order=id+DESC&num=2&start=3\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'3,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3cd7c99405ac1afa28d3eb5f35d5c029&action=lists&catid=255&order=id+DESC&num=2&start=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'5,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=383edbd19b1d0417f221412ed9ddb9da&action=lists&catid=255&order=id+DESC&num=1&start=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'7,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        	<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'45','');?></a></h2>
            <p class="hotcontent"><?php echo str_cut($r['description'],120);?> <a href="<?php echo $r['url'];?>" target="_blank">详细>></a></p>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=720cda4af3bb83598214cdbfb2607048&action=lists&catid=255&order=id+DESC&num=2&start=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'8,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f7d7a22dbfb6d679cbe80e0de0e13b05&action=lists&catid=255&order=id+DESC&num=2&start=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'255','order'=>'id DESC','limit'=>'10,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
        </div>
        
        <div class="kzc-jsj-rgtj kzc-jsj-rgzr">
        	<div class="rgcut zrcut">精彩推荐<span>Recommend</span></div>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=8482b5e546af110c18ff183e3d20e2df&action=position&posid=292&order=listorder+DESC&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'292','order'=>'listorder DESC','limit'=>'1',));}?>
            <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
            <div class="rgtjpic"><a href="<?php echo $r['url'];?>"  title="<?php echo $r['title'];?>"><img src="<?php echo thumb($r['thumb'],260,110);?>" width="260"  height="110"/></a><p><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo str_cut($r['title'],46);?></a></p></div>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            <ul class="newslist ftsmall">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ffa722ea94409d8e5cf6d3bca9e18455&action=position&posid=292&order=listorder+DESC&num=5&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'292','order'=>'listorder DESC','limit'=>'1,5',));}?>
                    <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                        <li><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 46, '');?></a></li>
                    <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="kzc-jsjtwo">
    	<div class="kzc-zrlft">
        	<div class="onecut twocut">报考指南<a href="<?php echo $CATEGORYS['252']['url'];?>" class="more zrmore">more</a></div>
            <ul class="daitime">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dac1490c369a2fd7ed372a4e978b33d8&action=position&posid=252&order=listorder+DESC&num=9&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'252','order'=>'listorder DESC','limit'=>'1,9',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'58','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            </ul>
        </div>
        
        <div class="jsjzixun">
        	<div class="zxcut zrcut">最近更新</div>
            <ul class="daitime">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=362deb38cfc2b66f530090b03682bddd&action=lists&catid=867&order=id+DESC&num=9&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'867','order'=>'id DESC',)).'362deb38cfc2b66f530090b03682bddd');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'867','order'=>'id DESC','limit'=>'9',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            </ul>
        </div>
        
        <div class="kzc-onerg">
            <div class="onecut twocut">试题排行<a href="<?php echo $CATEGORYS['867']['url'];?>" class="more zrmore">more</a></div>
            <ul class="daitime">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=831173f9d50f6901ef1f1387557f9816&action=hits&catid=867&order=weekviews+DESC&num=9\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'867','order'=>'weekviews DESC','limit'=>'9',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'50','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            </ul>
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="kzc-newsone" id="PAGE_AD_1">加载中...</div>
    
    <div class="rs-zrcontent">
    	<div class="zrtydv">
        	<div class="tycut">财会考试<span id="ckksA"><a href="<?php echo $CATEGORYS['255']['url'];?>" target="_blank" class="selected">会计从业</a><a href="<?php echo $CATEGORYS['256']['url'];?>" target="_blank">初级会计职称</a><a href="<?php echo $CATEGORYS['271']['url'];?>" target="_blank">经济师</a></span></div>
            <div id="ckksDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=052aa42dbaaf4720856546a5be16242d&action=hits&catid=255&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'255','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c62e60ca2cbd626d7e93ed061ace4b69&action=hits&catid=256&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'256','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none;">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cf534b4d4efe7d678d5a28ed792be2af&action=hits&catid=271&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'271','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
        <div class="zrtydv zrctmg">
        	<div class="tycut">建筑工程<span id="jzgcA"><a href="<?php echo $CATEGORYS['245']['url'];?>" target="_blank" class="selected">一级建造师</a><a href="<?php echo $CATEGORYS['233']['url'];?>" target="_blank">二级建造师</a></span></div>
            <div id="jzgcDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f312e829333539d7a79669b651627ab7&action=hits&catid=245&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'245','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=23325bd566e2641b0cb4a146352e1070&action=hits&catid=233&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'233','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
        <div class="zrtydv">
        	<div class="tycut">医药卫生<span id="yywsA"><a href="<?php echo $CATEGORYS['226']['url'];?>" target="_blank" class="selected">执业医师</a><a href="<?php echo $CATEGORYS['228']['url'];?>" target="_blank">执业药师</a><a href="<?php echo $CATEGORYS['869']['url'];?>" target="_blank">卫生资格</a></span></div>
            <div id="yywsDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=db614dd373de750a337c711567da5ac3&action=hits&catid=226&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'226','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bbed3e458f7e9365257c6828ddb7feeb&action=hits&catid=228&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'228','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=85a9825cb20f978a180bcc104051668c&action=hits&catid=869&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'869','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
    </div>
    
    <div class="kzc-newsone" id="PAGE_AD_2">加载中。。。</div>
    
    <div class="rs-zrcontent">
    	<div class="zrtydv">
        	<div class="tycut">司法考试<span id="sfksA"><a href="<?php echo $CATEGORYS['491']['url'];?>" target="_blank" class="selected">国家司法</a><a href="<?php echo $CATEGORYS['456']['url'];?>" target="_blank">法律顾问</a></span></div>
            <div id="sfksDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=e0c6c5f18f1cf51f1422fc3a3c410d2a&action=hits&catid=491&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'491','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=483936c5c8847be01853d7f55a81de0d&action=hits&catid=456&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'456','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
        <div class="zrtydv zrctmg">
        	<div class="tycut">外贸考试<span id="wmksA"><a href="<?php echo $CATEGORYS['223']['url'];?>" target="_blank" class="selected">跟单员</a><a href="<?php echo $CATEGORYS['224']['url'];?>" target="_blank">单证员</a><a href="<?php echo $CATEGORYS['221']['url'];?>" target="_blank">报关员</a></span></div>
            <div id="wmksDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=1cfe40b930a2ab7975e85c89f38d5891&action=hits&catid=223&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'223','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=904b226317016d038542ddd8a980727f&action=hits&catid=224&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'224','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=40ff22283bc08c278b68d9b6f1e252d2&action=hits&catid=221&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'221','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
        <div class="zrtydv">
        	<div class="tycut">其他考试<span id="qtksA"><a href="<?php echo $CATEGORYS['303']['url'];?>" target="_blank" class="selected">秘书资格</a><a href="<?php echo $CATEGORYS['301']['url'];?>" target="_blank">社会工作师</a></span></div>
            <div id="qtksDIV">
            	<ul class="daitime">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=79f44aa55d1038a782f43523dc06c9c6&action=hits&catid=303&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'303','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
                <ul class="daitime" style="display:none">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9560be9dc23b3d3caddb40e219ec6743&action=hits&catid=301&order=weekviews+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'301','order'=>'weekviews DESC','limit'=>'8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
            	</ul>
            </div>
        </div>
    </div>
    
</div>

<?php include template("content","rsks_bottom"); ?>

<!-- 请置于所有广告位代码之前 -->
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
    BAIDU_CLB_fillSlotAsync('874625', 'PAGE_AD_1');
    BAIDU_CLB_fillSlotAsync('874627', 'PAGE_AD_2');
</script>
</body>

</html>







