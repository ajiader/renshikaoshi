<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?>人事考试资讯网</title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css?xg0126" />
</head>

<body>
<?php include template("content","rsks_top"); ?>
<?php $ad_ids = explode('|',$CATEGORYS[$catid][ad_ids])?>
<div class="cy-tyct kzx-dysx ">

<div class="schoolsk">
    <span class="lfsk">各地人事考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $v['pinyin'];?>.html" title="<?php echo replace_arr($v['name'],array('省','市'));?>人事考试网" target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
		<a href="sitemaps.html#rsbmrk" target="_blank">更多>></a>
    </span>
    <span class="map"></span>
</div>

<div id="<?php echo $ad_ids['0'];?>"> </div>
    <div class="kzc-listym kzc-newsone">
    	<div class="kzc-posi">当前位置：<a href="<?php echo siteurl($siteid);?>">首页</a><span> &gt; </span> <?php if(!in_array($catid, GetCaijiCatid()) ) { ?><a href="<?php echo $CATEGORYS[$catid]['url'];?>"><?php echo $CATEGORYS[$catid]['catname'];?></a> <span> &gt; </span> <?php } else { ?> <a href="<?php echo siteurl($siteid);?>/news/">资讯中心</a> <span> &gt; </span><?php } ?><?php echo $title;?></div>
    	<div class="kzc-detaillf">
        	<h1 class="h2title"><?php echo $title;?></h1>
            <div class="dtly kzc-newsone">来源：<?php if($topCityList) { ?> <a target="_blank" href="/renshibaoming/<?php echo $topCityList['pinyin'];?>.html"><?php echo str_replace(array('省',市),'',$topCityList['name']);?>人事考试网</a><?php } else { ?> <a href="<?php echo siteurl($siteid);?>">人事考试资讯网</a> <?php } ?>&nbsp;&nbsp;&nbsp;发布：<?php echo date('Y-m-d',$rs[inputtime]);?></div>
            <?php if($description) { ?><div class="dtdd kzc-newsone" ><strong>导读：</strong><?php echo $description;?></div><?php } ?>
            <div class="nrcontent">
            	<?php echo $content;?><br />
 本文链接：<?php echo $url;?>
                
            </div>
            <div id="pages" class="text-c"><?php echo str_replace("_0.html","_1.html",$pages);?></div>
            <div class="bjtj"><span>上一篇：</span><a href="<?php echo $previous_page['url'];?>"><?php echo str_cut($previous_page[title],60);?></a></div>
            <div class="bjtj"><span>下一篇：</span><a href="<?php echo $next_page['url'];?>"><?php echo str_cut($next_page[title],60);?></a></div>
            <div class="kzc-dtline"></div>
            <div id="<?php echo $ad_ids['3'];?>"> </div>
           <ul class="newslist ftsmall listmore <?php echo $city_id;?>">
              <?php $where = "catid=$catid and level=1";?>
              <?php $where = ($city_id>0)?$where." and cityid=$city_id":$where;?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=93a41709ef79f0c53b3f51377d9abcff&sql=SELECT+%2A+from+phpcms_diypage+WHERE+%24where&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE $where LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
<li><a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a></li>
<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        
        <?php include template("content","right_rsks"); ?>
        <div class="clear"></div>
    </div>
</div>

<?php include template("content","rsks_bottom"); ?>
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
<?php $n=1; if(is_array($ad_ids)) foreach($ad_ids AS $k => $v) { ?>
<?php if($v>0) { ?>
    BAIDU_CLB_fillSlotAsync('<?php echo $v;?>', '<?php echo $v;?>');
	<?php } ?>
	<?php $n++;}unset($n); ?>
</script>
<!--异步加载结束 -->
</body>
</html>
