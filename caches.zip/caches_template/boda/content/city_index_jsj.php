<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/jsj/css/cyjsjre.css" />
<link rel="stylesheet" type="text/css" href="/statics/jsj/css/cycity.css"/>
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script language="javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<script language="javascript" src="/statics/jsj/js/jq_scroll.js"></script>
<script language="JavaScript" type="text/javascript">
var scrollCount=1;
var pauseTime=3*1000; /*数字越小移动的时间越快*/
var timer1;
function changeClips() {
 for (i=1; i<5; i++){
  var allCtn="ctn"+i;
  var allTtl="ttl"+i;
  document.getElementById(allCtn).style.display="none";
  document.getElementById(allTtl).className="default";
  }
 }
 
function ttlOn(n) {
 var curCtn="ctn"+n;
 var curTtl="ttl"+n;
 changeClips();
 document.getElementById(curCtn).style.display="block";
 document.getElementById(curTtl).className="selected";
 scrollCount=n;
 }
 
function affScroll() {
 stopScroll();
 ttlOn(scrollCount);
 scrollCount+=1;
 if (scrollCount==5) {
  scrollCount=1;
  }
  timer1=setTimeout("affScroll()",pauseTime);
 }
 
function stopScroll() {
 clearTimeout(timer1);
 }
</script>
<base target="_blank" />
</head>

<body>
<div class="jsjcontent">
	<?php include template("content","rsks_top"); ?>
    <div class="jsj_ct jsjpdtp">
      <div class="schoolsk">
    <span class="lfsk">计算机各地考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/jsj/<?php echo $v['pinyin'];?>/" title="<?php echo replace_arr($v['name'],array('省','市'));?>职称计算机考试"  target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
    </span>
    <span class="map"></span>
</div>
        <div class="select-city-box">
             <div class="select-title"><?php echo citys2city($cityList['name']);?>站</div>
             <div class="select-city-all">
             	<?php $n=1;if(is_array($childCitylist)) foreach($childCitylist AS $v) { ?>
                  <?php if($v['pinyin']) { ?> <a href="<?php echo $CATEGORYS[$catid]['url'];?><?php echo $v['pinyin'];?>/" title="<?php echo $v['name'];?>职称计算机考试网"<?php if($nametid == $v['linkageid']) { ?> style="color:#f00000;"<?php } ?>><?php echo citys2city($v['name']);?></a><span>|</span><?php } ?>
                <?php $n++;}unset($n); ?>
             </div>
        </div>
        <!--//select city box-->
        <div class="jsj_nr1">
        
        	<div class="nr1-lf">
            	<div class="pictab jsjtymg">
                	<ul><li class="selected" id="ttl1" onmouseover="ttlOn(1);" ><a href="javascript:;">全真模拟</a></li><li id="ttl2" onmouseover="ttlOn(2)" ><a href="javascript:;">快速通关</a></li><li id="ttl3" onmouseover="ttlOn(3)" ><a href="javascript:;">真题题库</a></li><li id="ttl4" onmouseover="ttlOn(4)" style="margin-right:0px;"><a href="javascript:;">升职加薪</a></li></ul>
                    <div class="picdv">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=62790d4a11a9121e4f38e476408989d1&action=position&posid=242&order=listorder+DESC&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'242','order'=>'listorder DESC','limit'=>'4',));}?>
                        <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
				           <p id="ctn<?php echo $n;?>" ><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><img src="<?php echo thumb($val['thumb'],300,560);?>" alt="<?php echo $val['title'];?>" /></a></p>
                        <?php $n++;}unset($n); ?> <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </div>
                    <script language="JavaScript" type="text/javascript">affScroll();</script>
                </div>
                <div class="nrtydv jsjtymg">
                	<div class="tycut">历年真题<a href="<?php echo $CATEGORYS['189']['url'];?>" class="more">更多>></a></div>
                    <ul class="newsty">
                       <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b08d7524a5adc884249db476bcee3888&action=lists&catid=189&order=id+DESC&num=9\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'189','order'=>'id DESC','limit'=>'9',));}?>
                        <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    	<li><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank" ><?php echo str_cut($r['title'],48);?></a></li>
                        <?php $n++;}unset($n); ?>
                       <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
            </div>
            
            <div class="nr1-ct">
            	<h1><span>资讯</span>
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f8cc056ee640b17f4d7ac169f2d624cc&action=position&posid=183&order=listorder+DESC&num=1&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'183','order'=>'listorder DESC','limit'=>'1',));}?>
				  <?php $n=1; if(is_array($data)) foreach($data AS $key => $r) { ?>
                   <a href="<?php echo $r['url'];?>" target="_blank" style="float:left;" title="<?php echo $r['title'];?>"><?php echo str_cut($r['sl_title'],80,'');?></a>
                  <?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></h1>
                <h2><span>报名</span>：<a href="/jsj/ksdt/kssj_<?php echo $cityList_t['pinyin'];?>/">[<?php echo citys2city($cityList['name']);?>职称计算机考试时间]</a> <a href="/jsj/ksdt/bmsj_<?php echo $cityList_t['pinyin'];?>/">[<?php echo citys2city($cityList['name']);?>职称计算机报名时间]</a><br />
				<span>指南</span>：<a href="http://www.renshikaoshi.net/kaoshi-185-106623-1.html">[考试条件]</a> <a href="http://www.renshikaoshi.net/kaoshi-185-106620-1.html">[考试介绍]</a> <a href="http://www.renshikaoshi.net/kaoshi-185-106642-1.html">[成绩查询]</a> <a href="http://www.renshikaoshi.net/kaoshi-185-106640-1.html">[考试科目]</a></h2>
                
				<h3><span>真题</span><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c1ed0c099e4ad3f8022571962630e73c&action=category&catid=198&num=3&order=listorder+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'198','order'=>'listorder DESC','limit'=>'3',));}?>
				 <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>		 
				   <a href="http://www.renshikaoshi.net/jsj/lnzt/"><?php echo $r['catname'];?></a>
				 <?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> </h3>
                
				<h2><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b7b5f6ccce96da181e404db3c8e6502a&action=position&catid=189&posid=171&order=listorder+DESC&num=4&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('catid'=>'189','posid'=>'171','order'=>'listorder DESC','limit'=>'4',));}?>
					<?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
					<?php $num++;?>
                	  <a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['sl_title'],50,'');?></a>
					<?php if($num % 2 == 0) { ?><br /><?php } ?>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?><span>模块</span>：<a href="http://www.renshikaoshi.net/jsj/ksmk/Word2003/">Word2003</a> | <a href="http://www.renshikaoshi.net/jsj/ksmk/excel/">Excel2003</a> | <a href="http://www.renshikaoshi.net/jsj/ksmk/ppt/">Powerpoint2003</a></h2>            
			 
                <h3><span>辅导</span>				
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=e5eba616c3f08e339edc6bd25aaf6033&action=position&posid=317&order=listorder+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'317','order'=>'listorder DESC','limit'=>'1',));}?>
				  <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
				   <a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" <?php echo title_style($r[style]);?>  target="_blank"><?php echo str_cut($r['sl_title'],60);?></a>
				  <?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
				</h3>
                <h2><a href="javascript:;">辅导</a>：				
				<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=70e0aa01ba43b23399aef772b92ad5b3&action=position&posid=317&order=listorder+DESC&num=2&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'317','order'=>'listorder DESC','limit'=>'1,2',));}?>
				  <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
				   <a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" <?php echo title_style($r[style]);?>  target="_blank"><?php echo str_cut($r['sl_title'],60);?></a>
				   <?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?><br /><a href="javascript:;">必看</a>：				 
				 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=51cf4066a9dd03818ba22f66e0e37f8c&action=position&posid=318&order=listorder+DESC&num=2\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'318','order'=>'listorder DESC','limit'=>'2',));}?>
				  <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
				   <a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" <?php echo title_style($r[style]);?>  target="_blank"><?php echo str_cut($r['sl_title'],60);?></a>
				   <?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
				 </h2>
				 
                <div class="newstab" id="newstabone"><a href="javascript:;" class="selected">最近更新</a><a href="javascript:;">报考通知</a><a href="javascript:;">成绩查询</a><a href="javascript:;">准考证打印</a></div>
                <div class="newsdv jsjtymg" id="newsdvone">
                	<ul class="newsty">
                		<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9655e234519bb5e6ac8f4d8034a8a578&action=lists&catid=10&order=id+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'10','order'=>'id DESC','limit'=>'8',));}?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],66);?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="newsty" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3d984b41ff76054ae5630ba43857caa1&action=lists&catid=187&order=id+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'8',));}?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],66);?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="newsty" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3998b1f799e271e6658411c5beb27427&action=lists&catid=188&order=id+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'188','order'=>'id DESC','limit'=>'8',));}?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],66);?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="newsty" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d92082373bbde4d1835a156c95487f9b&action=lists&catid=196&order=id+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'196','order'=>'id DESC','limit'=>'8',));}?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],66);?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    

                </div>
                
            </div>
            
            <div class="nr1-rg">
            	<div class="nrtydv jsjtymg">
                	<div class="tycut jsjtymg">报考指南<a href="<?php echo $CATEGORYS['184']['url'];?>" class="more">更多>></a></div>
                    <div class="bkzn">
                    	<a href="http://www.renshikaoshi.net/kaoshi-185-106620-1.html">考试介绍</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106620-1.html">考试教材</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106623-1.html">报考条件</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106640-1.html" class="a1">考试科目</a>
                        <a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/">报名时间</a>
                        <a href="http://www.renshikaoshi.net/jsj/lnzt/">历年真题</a>
                        <a href="http://www.renshikaoshi.net/jsj/jqxd/">考试心得</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106622-1.html" class="a1">考试实施</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106642-1.html">成绩查询</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106684-1.html">合格标准</a>
                        <a href="http://www.renshikaoshi.net/kaoshi-185-106686-1.html">证书领取</a>
                        <a href="http://www.renshikaoshi.net/download/zhichenjisuanji/" class="a1">题库下载</a>
                    </div>
                </div>
                <div class="jsjtymg" id="PAGE_AD_675854"></div>
                <div class="nrtydv jsjtymg">
                	<div class="tycut jsjtymg">在线问答</div>
                    <div class="zkquestion">
                      <form action="/question/" target="_blank">
						 <input type="text" name="serch" value="请输入您需要了解的问题" onfocus="this.value='';this.style.color='#333333'" class="ip1" />
						 <input type="submit" name="questionbtn" value="搜索问题" class="ip2" />
				      </form>		 
			        </div>
                    <div class="quesdv" id="teacheryiwen">
                    	<ul>
                       <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=7ed27c59587e3827f9da6692c19acc84&sql=SELECT+aq.qid%2Caq.question%2Caq.url%2Caq.ip%2Caq.catid%2Caa.%2A+from+v9_ask_question+aq+JOIN+v9_ask_answer+aa+ON+aq.qid%3Daa.qid+WHERE+aq.status+%21%3D+1+AND+aa.content+%21%3D+%27%27+and+aq.catid%3D1+and+aq.siteid%3D1+ORDER+BY+aa.qid+desc&cache=3600&return=data&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT aq.qid,aq.question,aq.url,aq.ip,aq.catid,aa.* from v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid WHERE aq.status != 1 AND aa.content != \'\' and aq.catid=1 and aq.siteid=1 ORDER BY aa.qid desc',)).'7ed27c59587e3827f9da6692c19acc84');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT aq.qid,aq.question,aq.url,aq.ip,aq.catid,aa.* from v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid WHERE aq.status != 1 AND aa.content != '' and aq.catid=1 and aq.siteid=1 ORDER BY aa.qid desc LIMIT 6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
                         <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                        <li><p><a href="<?php echo $val['url'];?>" target="_blank" title="<?php echo $val['question'];?>"><?php echo str_cut($val['question'],'45');?></a></p><p><?php echo trim(str_cut(strip_tags($val['content']),'70'));?></p></li>
                         <?php $n++;}unset($n); ?>
						<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
                        </ul>
                    </div>
                </div>
                </div>
            
            <div class="clear"></div>
        </div>

        
        <!--//考试模块-->
        <div class="city-box">
           <div class="city-mk-title">
               <h2 class="cmth2">学习软件</h2>
               <div class="cmtintro">
                  <span></span>
                  
               </div>
           </div>
           <div class="clear"></div>
           <!--//city-mk-title-->
           <div class="city-box-border">
               <div class="pd8">
                   <h3 class="mkh3">2015年考试宝典职称计算机考试软件 - 全国过关率最高,真题率最高职称计算机考试模拟题软件</h3>
                   <div class="detail-mk">
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/pointer2007.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">PowerPoint2007</a><br />科目代码：213 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/excel2007.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Excel2007</a><br />科目代码：212 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/word2007.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Word2007</a><br />科目代码：211 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Internet.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Internet应用</a><br />科目代码：303 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/PowerPoint2003.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">PowerPoint2003</a><br />科目代码：207 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Excel2003.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Excel2003</a><br />科目代码：206 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/wrod2003.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">wrod2003</a><br />科目代码：205 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/xp.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">WindowsXP</a><br />科目代码：102 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Frontpage2000.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Frontpage2003</a><br />科目代码：305 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/jswz.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">金山文字2005</a><br />科目代码：208 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/jsbg.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">金山表格2005</a><br />科目代码：209 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/jsys.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">金山演示2005</a><br />科目代码：210 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/wpsoffice.jpg" width="45" height="45" /></a></dt>
                          <dd class="dou"><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">WPSOffice办公组合中文字处理</a><br />科目代码：204 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Frontpage2000.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Frontpage2000</a><br />科目代码：302 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/cad.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">AutoCAD2004</a><br />科目代码：503 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/u8.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">用友U8</a><br />科目代码：403 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/VisualFoxPro.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">VisualFoxPro5.0</a><br />科目代码：401 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Flash.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">FlashMX2004动画制作</a><br />科目代码：504 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Authorware.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Authorware7.0</a><br />科目代码：505 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Frontpage2000.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Project2000项目管理</a><br />科目代码：901 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/Access2000.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Access2000</a><br />科目代码：402 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/ps.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">PhotoshopCS4图像处理</a><br />科目代码：506 常考模块</dd>
                       </dl>
                       <dl class="mk-dl">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/u8.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">用友T3会计信息化软件</a><br />科目代码：404 常考模块</dd>
                       </dl>
                       <dl class="mk-dl" style="margin-right:0px;">
                          <dt><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912"><img src="/statics/kaozc/images/ps.jpg" width="45" height="45" /></a></dt>
                          <dd><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.lwaC2Q&id=37117006912">Photoshop6.0图像处理</a><br />科目代码：502 常考模块</dd>
                       </dl>
                   </div>
               </div>
           
           </div>
        </div>
        <div class="space10"></div>
        <!--//ad-->
        <div class="city-box">
            <div class="zxfd-title"><h2>专项辅导</h2></div>
            <div class="zxfd-box">
                <div class="zxfd-box-left">
                    <div class="zxfd-h40">
                        <h2 class="zxfd-md-tt">XP、Internet、Office系列</h2>
                        <div class="zxfd-more"><a href="<?php echo $CATEGORYS['199']['url'];?>">word</a><a href="<?php echo $CATEGORYS['201']['url'];?>">Excel</a><a href="<?php echo $CATEGORYS['202']['url'];?>">PowerPoint</a><a href="<?php echo $CATEGORYS['10']['url'];?>" class="orange">更多&gt;&gt;</a></div>
                    </div>
                    <div class="zxfd-bd">
                        <div class="zxfd-mk-b">
                            <div class="changtab-box" id="mk01"><span class="on">word2003</span><span>word2007</span><span>Excel2003</span><span>Excel2007</span></div>
                            <div class="changtab-content" id="mk01_tab">
                                <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9e387c80d549886a207f9f43bea71840&action=lists&catid=199&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'199','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=04b42ffdee9f3ca239711046de17dcab&action=lists&catid=809&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'809','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=35f2ea3f47cd5e35d55dad61100a5573&action=lists&catid=201&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'201','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fc664c6d491bae42b29074458fe24a32&action=lists&catid=842&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'842','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
								
                            </div>
                        </div>
                        <!--//box-->
                        <div class="zxfd-mk-b" style="float:right;">
                            <div class="changtab-box" id="mk02"><span class="on">Powerpoint2003</span><span>Powerpoint2007</span><span>windows XP</span><span>Internet</span></div>
                            <div class="changtab-content" id="mk02_tab">
                                <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3bb57fc5e7b46cef7ffcc1d7733fabc9&action=lists&catid=202&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'202','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5f99425ec254a1fc8557d4a741eab8bc&action=lists&catid=843&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'843','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a6cc567770fff2db2f5fe61d90dd63c6&action=lists&catid=200&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'200','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=822a27d712e4f26c42769250b749b9a5&action=lists&catid=203&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'203','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                            </div>
                        </div>
                        <!--//box-->
                    </div>
                    <div class="clear"></div>
                </div>
                <!--//left-->
                <div class="zxfd-box-right">
                    <div class="zxfd-br-title"><h2>考试政策</h2></div>
                    <ul class="list-zxfd-br">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c3f9395f45d22811aaa6e91c510994ab&action=lists&catid=185&order=id+DESC&num=10&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'185','order'=>'id DESC','limit'=>'10',));}?> 
                      <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                       <li><a  href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'40','');?></a><span>[<?php echo date('m-d',$val['updatetime']);?>]</span></li>
                       <?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                   </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="space10"></div>
        <!--//-->
        <div class="city-box" id="PAGE_AD_538171">
       
        </div>
        <div class="space10"></div>
        <!--//ad-->
        <div class="city-box">
            <div class="zxfd-box">
                <div class="zxfd-box-left">
                    <div class="zxfd-h40">
                        <h2 class="zxfd-md-tt">金山、CAD、网页制作系列</h2>
                        <div class="zxfd-more"><a href="<?php echo $CATEGORYS['214']['url'];?>">AutoCAD 2004</a><a href="<?php echo $CATEGORYS['215']['url'];?>">Frontpage 2000</a><a href="<?php echo $CATEGORYS['10']['url'];?>" class="orange">更多&gt;&gt;</a></div>
                    </div>
                    <div class="zxfd-bd">
                        <div class="zxfd-mk-b">
                            <div class="changtab-box" id="mk03"><span class="on">AutoCAD 2004</span><span>Frontpage 2000</span><span>Frontpage 2003</span></div>
                            <div class="changtab-content" id="mk03_tab">
                                <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3b0b9412a08cb4f8a21c4dd93b72f64c&action=lists&catid=214&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'214','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bee662c80d241599c79c01cbfd6bb816&action=lists&catid=215&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'215','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=26bcae9ebb39d16f729f6ef63cd1b906&action=lists&catid=845&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'845','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                            </div>
                        </div>
                        <!--//box-->
                        <div class="zxfd-mk-b" style="float:right;">
                            <div class="changtab-box" id="mk04"><span class="on">WPS Office</span><span>金山表格05</span><span>金山文字05</span><span>金山演示05</span></div>
                            <div class="changtab-content" id="mk04_tab">
                                <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f296503f28d32a7f7ab7c9ed9549973a&action=lists&catid=213&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'213','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2279b81350d18894559cc8015ab69a0a&action=lists&catid=204&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'204','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f754197690311ca8c6176173abf44a83&action=lists&catid=205&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'205','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=945149421a29e100553fb1d5fd85226a&action=lists&catid=207&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'207','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                            </div>
                        </div>
                        <!--//box-->
                    </div>
                    <div class="clear"></div>
                </div>
                <!--//left-->
                <div class="zxfd-box-right">
                    <div class="zxfd-br-title"><h2>考试答疑</h2></div>
                    <ul class="list-zxfd-br">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b789ef89341595faf4074be1afc027a5&action=lists&catid=194&order=id+DESC&num=10&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'194','order'=>'id DESC','limit'=>'10',));}?> 
                      <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                       <li><a  href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'40','');?></a><span>[<?php echo date('m-d',$val['updatetime']);?>]</span></li>
                       <?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                   </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="space10"></div>
        <!--//-->
        <div class="city-box" id="PAGE_AD_675847">
        </div>
        <div class="space10"></div>
        <!--//ad-->
        <div class="city-box">
            <div class="zxfd-box">
                <div class="zxfd-box-left">
                    <div class="zxfd-h40">
                        <h2 class="zxfd-md-tt">图像制作、数据库管理系列</h2>
                        <div class="zxfd-more"><a href="<?php echo $CATEGORYS['208']['url'];?>">Access 2000</a><a href="<?php echo $CATEGORYS['216']['url'];?>">Aithorware 7.0</a><a href="<?php echo $CATEGORYS['10']['url'];?>" class="orange">更多&gt;&gt;</a></div>
                    </div>
                    <div class="zxfd-bd">
                        <div class="zxfd-mk-b">
                            <div class="changtab-box" id="mk05"><span class="on">Flash MX 2004</span><span>Access 2000</span><span>Aithorware 7.0</span><span>用友U8</span></div>
                            <div class="changtab-content" id="mk05_tab">
                           <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=33908592989ffd0cfa106331dec2860a&action=lists&catid=210&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'210','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6e4a57d02b3cd185831d79547d770046&action=lists&catid=208&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'208','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3dd275e2d51366a14e43b82618c93f03&action=lists&catid=216&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'216','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=262384ba9043b2520f31463bc2418cea&action=lists&catid=844&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'844','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                            </div>
                        </div>
                        <!--//box-->
                        <div class="zxfd-mk-b" style="float:right;">
                            <div class="changtab-box" id="mk06"><span class="on">用友T3</span><span>Visual Foxpro 5.0</span><span>Project 2000</span><span>Photoshop CS4</span></div>
                            <div class="changtab-content" id="mk06_tab">
                           <ul class="list-chang-content" style="display:block;">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6b8d5cfd7a7961dae4084e05f4ff588d&action=lists&catid=206&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'206','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cf10db196fbd2f1709a58b894ab50cb2&action=lists&catid=212&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'212','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6070b2d59f2db1c51a75d3aebfd89171&action=lists&catid=211&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'211','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                                <ul class="list-chang-content">
                                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ecef3bedd47ba871b72ee439ee8d0866&action=lists&catid=209&order=id+DESC&num=8&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'209','order'=>'id DESC','limit'=>'8',));}?>
								 <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                                   <li><span>[<?php echo date('m-d',$r['updatetime']);?>]</span><a  href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],'50','');?></a></li>
								  <?php $n++;}unset($n); ?>
								 <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                                </ul>
                            </div>
                        </div>
                        <!--//box-->
                    </div>
                    <div class="clear"></div>
                </div>
                <!--//left-->
                <div class="zxfd-box-right">
                    <div class="zxfd-br-title"><h2>技巧心得</h2></div>
                    <ul class="list-zxfd-br">
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d37ccec8525b64eab03b9098c9af643c&action=lists&catid=192&order=id+DESC&num=10&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'192','order'=>'id DESC','limit'=>'10',));}?> 
                      <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                       <li><a  href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'40','');?></a><span>[<?php echo date('m-d',$val['updatetime']);?>]</span></li>
                       <?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                   </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="space10"></div>
        <!--//-->
        
    </div>
    
    <!--footer-->
     <?php include template("content","rsks_bottom"); ?>
</div>
<script language="javascript">
$(document).ready(function(){
	$('#mk01 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk01_tab > ul").eq($('#mk01 span').index(this)).show().siblings().hide();
	});
	$('#mk02 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk02_tab > ul").eq($('#mk02 span').index(this)).show().siblings().hide();
	});
	$('#mk03 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk03_tab > ul").eq($('#mk03 span').index(this)).show().siblings().hide();
	});
	$('#mk04 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk04_tab > ul").eq($('#mk04 span').index(this)).show().siblings().hide();
	});
	$('#mk05 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk05_tab > ul").eq($('#mk05 span').index(this)).show().siblings().hide();
	});
	$('#mk06 span').mouseover(function(){
		$(this).addClass("on").siblings().removeClass();
		$("#mk06_tab > ul").eq($('#mk06 span').index(this)).show().siblings().hide();
	});
	$('#newstabone a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#newsdvone > ul").eq($('#newstabone a').index(this)).show().siblings().hide();
	});

});

</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#teacheryiwen").Scroll({line:1,speed:500,timer:3000});
});
</script>

</body>
</html>
