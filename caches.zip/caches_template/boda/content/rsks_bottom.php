<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div class="cdbroadxgfoot">
	<div class="cy-tyct">
    	<span class="wzlf">
        	<p>人事考试资讯网www.renshikaoshi.net</p>
            <p>Copyright©2012-2018 RENSHIKAOSHI, All Rights Reserved. 备案编号: 皖ICP备13019968号-1<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1253711652'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1253711652%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script></p>
        </span>
        <a href="http://www.cdnet110.com/" target="_blank"><span class="bjdh">网络110<br />报警服务</span></a>
        <div class="clear"></div>
    </div>
</div>
<script type="text/javascript">
function nav_show(obj)
{
	document.getElementById("nav"+obj).className="litwo";
	document.getElementById("navdv"+obj).style.display="block";
}
function nav_dow(obj)
{
document.getElementById("nav"+obj).className="lione";
document.getElementById("navdv"+obj).style.display="none";
}
</script>
<script type="text/javascript" id="bdshare_js" data="type=tools&uid=499558" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();</script>