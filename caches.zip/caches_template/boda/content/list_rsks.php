<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php if ($catid == '820') { $catid='9';}
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css?xg=0105" />
</head>

<body>
<style>
.red{color:#F00}
</style>
<?php include template("content","rsks_top"); ?>

<?php $ad_ids = explode('|',$CATEGORYS[$catid][ad_ids])?>

<div class="cy-tyct kzx-dysx">
<div id="<?php echo $ad_ids['0'];?>"> </div>
    <div class="kzc-listym kzc-newsone">
    	<div class="kzc-posi">当前位置：<a href="http://www.renshikaoshi.net">首页</a><span> &gt; </span>  <a href="<?php echo $CATEGORYS[$catid]['url'];?>"><?php echo $CATEGORYS[$catid]['catname'];?></a>  &gt; <a href="<?php echo $CATEGORYS[$catid]['url'];?>mk<?php echo $mpinyin;?>/"><?php echo get_mokuainame($mid);?></a>  </div>
    	<div class="listymlf">
        	<div class="listcut"><?php if($catid != '9') { ?><span style="float:right; font-weight:normal; padding-right:10px; font-size:12px;"><a href="<?php echo $CATEGORYS[$catid]['url'];?>list.html?typeid=71"  <?php if($typeid==71) { ?>class="red"<?php } ?>>考试报名</a> | <a href="<?php echo $CATEGORYS[$catid]['url'];?>list.html?typeid=72" <?php if($typeid==72) { ?>class="red"<?php } ?>>考试指南</a> | <a href="<?php echo $CATEGORYS[$catid]['url'];?>list.html?typeid=96" <?php if($typeid==96) { ?>class="red"<?php } ?>>准考证打印</a> | <a href="<?php echo $CATEGORYS[$catid]['url'];?>list.html?typeid=97" <?php if($typeid==97) { ?>class="red"<?php } ?>>成绩查询</a> </span> <?php } ?> <?php echo $CATEGORYS[$catid]['catname'];?><?php if($typeid>0) { ?><?php echo get_typename($typeid);?><?php } ?> </div>
            
            <?php
                $cat_inarr=array(9,427,428,147,148,149,150,151,152,159,160,161,163,164,165,167,168,169);
                if(!in_array($catid,$cat_inarr)):
                ?>
                
            <div class="othertydaohao">
                <span class="otherdhbg">地区导航</span>
                <a href="<?php echo $CATEGORYS[$catid]['url'];?>" <?php if(!$pinyin) { ?> class="selected"<?php } ?>>全部</a><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=9e81e79a1d2f7b4d7361b70d0d7dc4f3&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+keyid%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3360%29&cache=0&return=data&num=32\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND keyid=1 AND linkageid NOT IN (33,34,35,3358,3360) LIMIT 32");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
              <?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>
<a href="<?php echo $CATEGORYS[$catid]['url'];?><?php echo $v['pinyin'];?>_1.html" <?php if($pinyin==$v['pinyin']) { ?> class="selected"<?php } ?>><?php echo replace_arr($v['name'],array('省','市'));?></a> <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </div>
             <?php
                endif;
                ?>
            
            <h3 class="bjtj" style="display:none;"><span>编辑推荐</span><a href="#">司法部：未举办任何形式的考前培训班</a></h3>
            <?php if($pinyin) { ?>
                    <?php $where = "islink=0 and status=99 and (city_id in ($cityList[arrchildid]) or title like '%$cityname%')"?>
                      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2c5e156c9fb64e047449f992f679d2ed&action=lists&catid=%24catid&num=40&order=id+DESC&page=%24page&where=%24where\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 40;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'order'=>'id DESC','where'=>$where,'limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','where'=>$where,'limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
                    <?php } else { ?>
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7d8b8e9d777e46dc8c95683a1adc1f45&action=lists&catid=%24catid&num=40&order=id+DESC&page=%24page\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$pagesize = 40;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$content_total = $content_tag->count(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));$pages = pages($content_total, $page, $pagesize, $urlrule);$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>$offset.",".$pagesize,'action'=>'lists',));}?>
                  <?php } ?>
           <ul class="newslist ftsmall listmore">
              <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
              <li><a href="<?php echo $r['url'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo str_cut($r[title],180,'...');?></a><span>(<?php echo date('Y-m-d',$r[inputtime]);?>)</span></li>
              <?php if($n%5==0) { ?></ul>  <ul class="newslist ftsmall listmore"><?php } ?>
                     <?php $n++;}unset($n); ?>
                    </ul>
                    <div class="detailfy"><?php echo $pages;?></div>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <div class="zr_kszl">
            	<span>考试专栏：</span>
                <div class="kszlA">
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d2abae37329b33fe145163aeb965746b&sql=SELECT+%2A+from+phpcms_diypage+WHERE+catid%3D%24catid+and+level%3D1+order+by+id+desc&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE catid=$catid and level=1 order by id desc LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                    <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a>
                    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        
        <?php include template("content","right_rsks"); ?>
        <div class="clear"></div>
    </div>
</div>

<?php include template("content","rsks_bottom"); ?>

<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
<?php $n=1; if(is_array($ad_ids)) foreach($ad_ids AS $k => $v) { ?>
<?php if($k>0) { ?>
    BAIDU_CLB_fillSlotAsync('<?php echo $k;?>', '<?php echo $k;?>');
	<?php } ?>
	<?php $n++;}unset($n); ?>
</script>
<!--异步加载结束 -->

</body>
</html>
