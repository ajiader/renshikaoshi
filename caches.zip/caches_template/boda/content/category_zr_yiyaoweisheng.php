<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html xmlns="http://www.w3.org/1999/xhtml">



<head>



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />



<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>



<meta name="keywords" content="<?php echo $SEO['keyword'];?>">



<meta name="description" content="<?php echo $SEO['description'];?>">



<link type="text/css" rel="stylesheet" href="/statics/zyzg/css/toruistyle.css" />



<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />



<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />



<script language="javascript" src="/statics/zyzg/js/qh.js"></script>



</head>







<body>



<div id="bdshare_l"></div>



<!-- heaer<start>-->



<?php include template("content","rsks_top"); ?>







<!-- heaer<end>-->







<!-- center<start>-->



<div class="toruitycenter">



	<?php include template("content","zr_banner"); ?>



    



    <div class="toruiyywscx toruitymg">



    	<div class="spcxcut">按字母查询： <?php



            $zmarr =  range('a','z'); 



            ?><?php $n=1; if(is_array($zmarr)) foreach($zmarr AS $k => $v) { ?><a href="<?php echo siteurl($siteid);?>/zrmokuai/?zm=<?php echo $v;?>" target="_blank"><?php echo strtoupper($v);?></a><?php $n++;}unset($n); ?></div>



        <div class="toruiyymk">



        	<ul>



            <?php



            $linkageid = 3364;



             $type_arr = GetTypeName(" `keyid` = '3362' AND `linkageid` =$linkageid");



             $mk_arrchildid = $type_arr[$linkageid]['arrchildid'];



            ?> 



            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=fd51fd7235e80149a5b2d66114ea4008&sql=SELECT+id%2Ctypeid%2Cname%2Cpinyin+from+phpcms_zirui_mokuai+WHERE++siteid%3D%24siteid+and+status%3D1+and+typeid+in+%28%24mk_arrchildid%29+ORDER+BY+id+asc&cache=3600&return=data&num=200\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT id,typeid,name,pinyin from phpcms_zirui_mokuai WHERE  siteid=$siteid and status=1 and typeid in ($mk_arrchildid) ORDER BY id asc',)).'fd51fd7235e80149a5b2d66114ea4008');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,typeid,name,pinyin from phpcms_zirui_mokuai WHERE  siteid=$siteid and status=1 and typeid in ($mk_arrchildid) ORDER BY id asc LIMIT 200");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>







             <?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>



        	<li><a href="<?php echo $CATEGORYS['11']['url'];?>ksmk/mk<?php echo $v['pinyin'];?>/" title="<?php echo $v['name'];?>" target="_blank"><?php echo $v['name'];?></a></li>



     



              <?php $n++;}unset($n); ?>



            </ul>



            <div class="toruiclear"></div>



        </div>



    </div>



    



    <div class="toruihotnews toruitymg">



    



    	<div class="qhpic">



         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6b123fc60ce0b48f935f5a0c5e1e2d07&action=position&posid=255&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'255','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



        <a href="<?php echo $r['url'];?>" target="_blank"><img src="<?php echo $r['thumb'];?>" width="308" height="201" /></a>



        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



        </div>



        



        <div class="rnct yywsli">



        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=14b9fff5cd847f885b5f139b899ef841&action=position&posid=256&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'256','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><p class="firstnw"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a> </p> <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            <ul>



            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=824697d15511f66d98c46529059fae59&action=position&posid=256&order=listorder+DESC&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'256','order'=>'listorder DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            	   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'40','');?></a> </li>



  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </ul>



           <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c139e378cd4684235439dba0729141fc&action=position&posid=257&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'257','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><p class="firstnw"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a> </p> <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            <ul>



            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a41092fa14a4c5c4f6c614fd76c14739&action=position&posid=257&order=listorder+DESC&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'257','order'=>'listorder DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            	   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'40','');?></a> </li>



  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </ul>



        </div>



        



        <div class="toruitydv">



        	<span class="yywsrgcut">精彩推荐</span>



           <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=e83b630bba0bb7158a7e52dccc11f19c&action=position&posid=254&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'254','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            <ul class="toruinewslist uisize">



            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2aefa3346dcc36d506c2d70ca6cb9787&action=position&posid=254&order=listorder+DESC&start=1&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'254','order'=>'listorder DESC','limit'=>'1,4',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                  <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>







              <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </ul>



        </div>



        <div class="toruiclear"></div>



    </div>



    



    <!-- 医学高级<start>-->



    <div class="toruitydiv toruitymg">



    	<div class="toruitydivtitle"><span class="title">医学高级</span><span class="kja"><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



        	<div class="qhpic">



   	      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=d75d1265ac255f7ce74e25879834eb96&pos=zyzg_yyws_wszg\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_wszg',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t71_1.html" class="selected" id="yywsone1" onmouseover="yywsone(1)">考试报名</a><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t97_1.html" id="yywsone2" onmouseover="yywsone(2)">成绩查询</a></span>



                <div id="yywsoneDIV1">



                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2edc4a8ef1ce42ba3f874ea9b2ad52ad&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=387c49e1e2eccc13f2055393e360822d&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywsoneDIV2" style="display:none;">



                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b9b2c2725906353932bd3aaeb15e2b71&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e6a53a60b4424cc61528b788501b4547&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">考试提醒</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=8856d99c893397889c8a500935f2abb0&pos=yyws_wszg_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_wszg_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



        	<div class="qhpic">



            	<span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                  



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3c51627bb6b58b2acaf1f08c0df8f930&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273372%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3372') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



               <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>    



                </ul>







            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t96_1.html" target="_blank" class="selected" id="yywstwo1" onmouseover="yywstwo(1)">准考证打印</a><a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t98_1.html" id="yywstwo2" onmouseover="yywstwo(2)">证书领取</a></span>



                <div id="yywstwoDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b49ae16d217270b9f969d8e2625bcf0a&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=740acd7036aae669e7ea134c0b81fa26&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywstwoDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e0b2b83fa8365a4a509d792dd816b18a&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=343406cb13f35737beb05f3360f8aebb&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D227+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=227 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">在线做题</span>



               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f13dfd0de6ab42da9300df2562c740fa&action=position&posid=278&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>



    



    <!-- 执业医师<start>-->



    <div class="toruitydiv toruitymg">



    	<div class="toruitydivtitle"><span class="title">执业医师</span><span class="kja"><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['869']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



        	<div class="qhpic">



            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=1d78ee66cff47ec96f676d2f643f4642&pos=zyzg_yyws_zyys\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_zyys',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t71_1.html" class="selected" id="yywsthree1" onmouseover="yywsthree(1)">考试报名</a><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t97_1.html" id="yywsthree2" onmouseover="yywsthree(2)">成绩查询</a></span>



                <div id="yywsthreeDIV1">



                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=a50acdf78f60a6c31221f156a60d35f5&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=54caad14aebf4ee1aa9dd85ca6527ee4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywsthreeDIV2" style="display:none;">



                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=dc702041e6f9dc14d793e3a1e6659069&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=dc881ef2d6ee062cb8a7aee230adccf9&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">考试提醒</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=3ed6473454d7d997044b65e5f09e07b7&pos=yyws_zyys_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_zyys_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



        	<div class="qhpic">



            	<span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2f42b683ddc8e2218d4c4bd87d2b1c32&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273365%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3365') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



               <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>    



                </ul>







            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t96_1.html" class="selected" id="yywsfoure1" onmouseover="yywsfoure(1)">准考证打印</a><a href="<?php echo $CATEGORYS['226']['url'];?>m<?php echo $mid;?>_t98_1.html" id="yywsfoure2" onmouseover="yywsfoure(2)">证书领取</a></span>



                <div id="yywsfoureDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=f6790b24279459742dbd1e9e357e1a57&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=fd1897be01cffb68fc65ea8989d26711&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywsfoureDIV2" style="display:none;">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=cf62b44c3cb7cc8102f66603fe271c6f&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=21f82959957ccfdffba2aaa9aff9dfec&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D226+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=226 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">在线做题</span>



               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0d305a16d3ccb1d99a4c6917e2f00eef&action=position&posid=278&order=listorder+DESC&start=1&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'1,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>



    



    <!-- 执业药师<start>-->



    <div class="toruitydiv toruitymg">



    	<div class="toruitydivtitle"><span class="title">执业药师</span><span class="kja"><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



        	<div class="qhpic">



            	 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=45b7b98869a44561289d88bfc48308b5&pos=zyzg_yyws_zyyaos\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_zyyaos',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank" class="selected" id="yywsfive1" onmouseover="yywsfive(1)">考试报名</a><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t97_1.html" id="yywsfive2" onmouseover="yywsfive(2)">成绩查询</a></span>



                <div id="yywsfiveDIV1">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=4387be245ec1e5d1531cc43c01276d0a&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=13101c65f3508388d574ded1023c6b96&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywsfiveDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=6baa829e9ff89faea8db0671c679c96b&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=831a2b716a58388c7b61ab1eeb63f80a&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">考试提醒</span>



                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=06401ad24486c379d461a4c2d227751f&pos=yyws_zyyaos_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_zyyaos_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



        	<div class="qhpic">



            	<span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=ec98fba41d01e267ad693bf50fc7a8af&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273371%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3371') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>







            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t96_1.html" class="selected" id="yywssex1" onmouseover="yywssex(1)">准考证打印</a><a href="<?php echo $CATEGORYS['228']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank" id="yywssex2" onmouseover="yywssex(2)">证书领取</a></span>



                <div id="yywssexDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b367d7a21502040269a46eae89b00cb3&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=8d4511481598a729b1ce7c4231112e00&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywssexDIV2" style="display:none;">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b06c2827f3e409fb7c7629e4d105f11f&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d66b94ab3b482357f1ea46703c39c121&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D228+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=228 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">在线做题</span>



               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b2745ab369fdbbea2a5a40c01a73905a&action=position&posid=278&order=listorder+DESC&start=2&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'2,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>



    



    <!-- 执业护士<start>-->



    <div class="toruitydiv toruitymg">



    	<div class="toruitydivtitle"><span class="title">执业护士</span><span class="kja"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



        	<div class="qhpic">



            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=0f9b04737e6b1b4a3ce1ed0bf6324c25&pos=zyzg_yyws_zysous\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_zysous',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t71_1.html" class="selected" id="yywsseven1" onmouseover="yywsseven(1)">考试报名</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t97_1.html" id="yywsseven2" onmouseover="yywsseven(2)">成绩查询</a></span>



                <div id="yywssevenDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=4c673ad9bc730914c8eff029efe39904&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=58b80723c0228874a3c38fbb973f962d&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywssevenDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=9d965025529ac55dac0d89d30d2911a3&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=d16deb7877c3bea0f217eb3746a06818&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">考试提醒</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=4b84faf69148806dfa4aae53af63c2e5&pos=yyws_zysous_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_zysous_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



        	<div class="qhpic">



            	<span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=34232eacdae35206c7ddbecbc48e1533&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273373%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3373') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>







            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t96_1.html" class="selected" id="yywseight1" onmouseover="yywseight(1)">准考证打印</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t98_1.html" id="yywseight2" onmouseover="yywseight(2)">证书领取</a></span>



                <div id="yywseightDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=40c9a233e66e6c0b0566309385a3e8e0&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3457cdddb4d96504be4c62c9603bebab&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywseightDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=517611e361bba4aa20e94b9735c3fba3&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=fce5b2067e4c90711ab3e09e05e397fe&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D225+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=225 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">在线做题</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bab178c8db1a35c625fd7062d434a4c9&action=position&posid=278&order=listorder+DESC&start=3&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'3,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>



    



    <!-- 卫生资格<start>-->



    <div class="toruitydiv toruitymg">



    	<div class="toruitydivtitle"><span class="title">卫生资格</span><span class="kja"><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



        	<div class="qhpic">



            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=e52f46a2f9dbc83aa812ad23d61b8b38&pos=zyzg_yyws_yys\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_yys',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank" class="selected" id="yywsnine1" onmouseover="yywsnine(1)">考试报名</a><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t97_1.html" id="yywsnine2" onmouseover="yywsnine(2)">成绩查询</a></span>



                <div id="yywsnineDIV1">



                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=0cad4c6545bfcaeb86a176acf725f5ad&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D925++AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=925  AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2f585ee468cc42502bd41bc251f35916&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D925++AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=925  AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywsnineDIV2" style="display:none;">



                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=9cf0a46212da56b12d4487ff9f171589&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D925+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=925 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2661461dbe2e57a327fa3ed188f6b8f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D925+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=925 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">考试提醒</span>



                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=a3cc3bd859cf949c7668b406ad4587dd&pos=yyws_yys_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_yys_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



        	<div class="qhpic">



            	<span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=1838a96edcde75ccd6c21dab6b717111&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273374%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3374') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>







            </div>



            <div class="yywsct">



            	<span class="cuttwo"><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t96_1.html" class="selected" id="yywsten1" onmouseover="yywsten(1)">准考证打印</a><a href="<?php echo $CATEGORYS['454']['url'];?>m<?php echo $mid;?>_t98_1.html" id="yywsten2" onmouseover="yywsten(2)">证书领取</a></span>



                <div id="yywstenDIV1">



                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=71f202f04833664bf7ffb4710310ce8a&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D869+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=869 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12e28ea34b90a34d8d492fa9a89c15dc&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D869+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=869 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="yywstenDIV2" style="display:none;">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=89c5ae4c958b335aee78152652454144&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D869+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=869 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=74854863d5344917e38eba8f03e02f59&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D869+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=869 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



            	<span class="cutone">在线做题</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=04d82717d4dccf9b12da269f44656d60&action=position&posid=278&order=listorder+DESC&start=4&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'4,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>









    <!-- 主治医师<start>-->



    <div class="toruitydiv toruitymg">



        <div class="toruitydivtitle"><span class="title">主治医师</span><span class="kja"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t71_1.html" target="_blank">考试报名</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t96_1.html"  target="_blank">准考证</a> <a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t97_1.html">成绩查询</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t98_1.html" target="_blank">证书领取</a><a href="#">考试大纲</a></span></div>



        <div class="toruihotnews toruitydvhg toruitymg">



            <div class="qhpic">



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=0f9b04737e6b1b4a3ce1ed0bf6324c25&pos=zyzg_yyws_zysous\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'zyzg_yyws_zysous',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="yywsct">



                <span class="cuttwo"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t71_1.html" class="selected" id="zzysten1" onmouseover="zzysten(1)">考试报名</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t97_1.html" id="zzysten2" onmouseover="zzysten(2)">成绩查询</a></span>



                <div id="zzystenDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=aae5a07f633153b989d9be823bdf8e6b&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=71 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=ea100cac998bbce251adda23901f7773&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D71+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=71 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="zzystenDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=f11615ec4863797fdcc5bd368da16f0b&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=97 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=301d8b18a8f3bf5f1fb804f8d45a44e0&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D97+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=97 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



                <span class="cutone">考试提醒</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=4b84faf69148806dfa4aae53af63c2e5&pos=yyws_zysous_kstx\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'yyws_zysous_kstx',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



            </div>



            <div class="toruiclear"></div>



        </div>



        



        <div class="toruihotnews toruitydvhg">



            <div class="qhpic">



                <span class="cutone">历年真题</span>



                <ul class="toruinewslist">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=34232eacdae35206c7ddbecbc48e1533&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D867+and+typeid%3D99+and+mid+in+%28SELECT+id+FROM+%60v9_zirui_mokuai%60+WHERE+%60typeid%60+%3D+%273373%27%29+order+by+id+desc&cache=0&return=data&start=0&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=867 and typeid=99 and mid in (SELECT id FROM `v9_zirui_mokuai` WHERE `typeid` = '3373') order by id desc LIMIT 7");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 



                    <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>



    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>







            </div>



            <div class="yywsct">



                <span class="cuttwo"><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t96_1.html" class="selected" id="zzystenone1" onmouseover="zzystenone(1)">准考证打印</a><a href="<?php echo $CATEGORYS['462']['url'];?>m<?php echo $mid;?>_t98_1.html" id="zzystenone2" onmouseover="zzystenone(2)">证书领取</a></span>



                <div id="zzystenoneDIV1">



                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=6443151c358fbd17c5d50b32641f0bd6&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=96 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=7f0a32af5944e547a24c858b3ec9c81b&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D96+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=96 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



                <div id="zzystenoneDIV2" style="display:none;">



                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e7c8a89ae4355a2e3eccccfd3899e10b&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=98 order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                    <p class="firstnw lghg"><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></p>



                     <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 



                    <ul class="toruinewslist">



                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=aee7b56be3dfa585c031981480d4c03e&sql=SELECT+id%2Cstyle%2Curl%2Ctitle+FROM+phpcms_news+where+catid%3D229+AND+status%3D99+and+typeid%3D98+order+by+id+desc&cache=0&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title FROM phpcms_news where catid=229 AND status=99 and typeid=98 order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>



            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



                         <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'66','');?></a> </li>



<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                    </ul>



                </div>



            </div>



            <div class="toruitydv">



                <span class="cutone">在线做题</span>



                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bab178c8db1a35c625fd7062d434a4c9&action=position&posid=278&order=listorder+DESC&start=3&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'278','order'=>'listorder DESC','limit'=>'3,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>



            <p class="pct"><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>"><img src="<?php echo $r['thumb'];?>"  width="270" height="84" /></a><span><?php echo str_cut(trim($r[title]),'36','');?></span></p>



            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                <ul class="yywszxzt">



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                    <li><a href="#">中级会计</a></li><li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li>



                    <li><a href="#">会计从业</a></li><li><a href="#">初级会计</a></li><li><a href="#">会计从业</a></li>



                </ul>



            </div>



            <div class="toruiclear"></div>



        </div>



        



    </div>



    



</div>



<!-- center<end>-->







<!-- footer<start>-->



	<?php include template("content","rsks_bottom"); ?>



<!-- footer<end>-->



<!--异步加载开始-->



 <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>



 <script type="text/javascript">



 <!-- 广告位：(新版)致睿首页-顶部banner -->



        BAIDU_CLB_fillSlotAsync('690550','PAGE_AD_5690550');



		<!-- 广告位：（新版）致睿顶部-左侧banner01 -->



	BAIDU_CLB_fillSlotAsync('690553','PAGE_AD_690553');



	<!-- 广告位：（新版）致睿顶部右部-banner02 -->



	BAIDU_CLB_fillSlotAsync('690555','PAGE_AD_690555');



	<!-- 广告位：（新版）致睿首页顶部左下-banner03 -->



	BAIDU_CLB_fillSlotAsync('690558','PAGE_AD_690558'); <!-- 广告位：（新版）致睿首页顶部中间-banner04 -->



        BAIDU_CLB_fillSlotAsync('690562','PAGE_AD_690562');  



		<!-- 广告位：（新版）致睿首页顶部右侧-banner05 -->



		 BAIDU_CLB_fillSlotAsync('690565','PAGE_AD_690565');  



		 



		 



		<!-- 广告位：（新）致睿首页-中栏banner -->



		 BAIDU_CLB_fillSlotAsync('695678','PAGE_AD_695678');



		<!-- 广告位：（新）致睿首页-顶部banner -->



		 BAIDU_CLB_fillSlotAsync('695679','PAGE_AD_695679');



</script>



<!--异步加载结束 --> 



<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>



<script type="text/javascript" src="/statics/js/53kefu.js"></script>







</body>



</html>



