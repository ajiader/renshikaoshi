<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<meta name="baidu-site-verification" content="uhu52zagQh" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css?xg=010" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css?xg=0112" />
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery.slideBox.js"></script>
<script language="javascript" src="/statics/jsj/js/jq_scroll.js"></script>
<script language="javascript">
$(document).ready(function(){
	$('#dtA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#dtDIV > ul").eq($('#dtA a').index(this)).show().siblings().hide();
	});
	$('#dtAone a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#dtDIVone > div").eq($('#dtAone a').index(this)).show().siblings().hide();
	});
	 $("#teacheryiwen").Scroll({line:1,speed:500,timer:3000});
});
</script>
<script type="text/javascript" src="http://www.51kaozc.com/themes/kaozc/js/timedjs.js"></script>
<script src="http://siteapp.baidu.com/static/webappservice/uaredirect.js" type="text/javascript"></script>
<script type="text/javascript">uaredirect("http://siteapp.baidu.com/webapp/www.renshikaoshi.net","http://www.renshikaoshi.net");</script>
<script type="text/javascript">
jQuery(function($){
	$('#slidepic').slideBox({
		duration : 0.3,//滚动持续时间，单位：秒
		easing : 'linear',//swing,linear//滚动特效
		delay : 5,//滚动延迟时间，单位：秒
		hideClickBar : false,//不自动隐藏点选按键
		clickBarRadius : 10
	});
});
</script>
<base target="_blank" />
</head>

<body onload="DigitalTime1()">

<?php include template("content","rsks_top_index"); ?>




<div class="cy-tyct">
	
    <div class="schoolsk">
    <span class="lfsk">各地人事考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $v['pinyin'];?>.html" title="<?php echo replace_arr($v['name'],array('省','市'));?>人事考试网" target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
		<a href="sitemaps.html#rsbmrk" target="_blank">更多>></a>
    </span>
    <span class="map"></span>
</div>
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="lf-1">
        	<div class="jhyd">距离2015年全国职称英语考试还有：<b id="LiveClock1"></b> 天</div>

        	<?php $posid=302; //首页-热点推送1?>
        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=15b2985bbd5922119c7235b8e36cba71&action=position&posid=%24posid&order=listorder+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        	<h1> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h1>
        	  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=4cd2ce2b2221271a125e0e12bf2c1de9&action=position&posid=%24posid&order=listorder+DESC&num=2&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'1,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

           
        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=4d5150ae4a71d4e4dfa8b29433e998cb&action=position&posid=%24posid&order=listorder+DESC&num=1&start=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'5,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        	<h2> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h2>
        	  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5a2a602b1e133b01d3dd32f5c135970c&action=position&posid=%24posid&order=listorder+DESC&num=2&start=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'6,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

            
        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7de7a9ea6b5fcdb141a5f939a2f7914f&action=position&posid=%24posid&order=listorder+DESC&num=1&start=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'10,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        	<h2> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h2>
        	  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c91e4faf0b35964dfd3e3839ec703dae&action=position&posid=%24posid&order=listorder+DESC&num=2&start=11\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'11,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

        </div>
        
        <?php $posid=303; //首页-焦点图?>
        <div class="rg-1">
        	<div class="slideBox" id="slidepic">
                <ul class="items">
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b499c242ff2e92c8dafbb4bcc3f60b00&action=position&posid=%24posid&order=listorder+DESC&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'5',));}?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><img src="<?php echo thumb($val['thumb'],300,560);?>" alt="<?php echo $val['title'];?>" title="<?php echo $val['title'];?>" height="300" width="540" /></a></li>
                    <?php $n++;}unset($n); ?> <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>

        	
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="lf-1">
        	<?php $posid=316; //首页-热点推送2?>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=1cdba64db9d5b1e67b4c01b932acbb79&action=position&posid=%24posid&order=listorder++DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder  DESC','limit'=>'1',));}?>

            <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <h2> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h2>
              <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=4cd2ce2b2221271a125e0e12bf2c1de9&action=position&posid=%24posid&order=listorder+DESC&num=2&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'1,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

           
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=4d5150ae4a71d4e4dfa8b29433e998cb&action=position&posid=%24posid&order=listorder+DESC&num=1&start=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'5,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <h2> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h2>
              <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5a2a602b1e133b01d3dd32f5c135970c&action=position&posid=%24posid&order=listorder+DESC&num=2&start=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'6,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

           
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7de7a9ea6b5fcdb141a5f939a2f7914f&action=position&posid=%24posid&order=listorder+DESC&num=1&start=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'10,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <h2> <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'62','');?></a></h2>
              <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            <p> <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c91e4faf0b35964dfd3e3839ec703dae&action=position&posid=%24posid&order=listorder+DESC&num=2&start=11\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>$posid,'order'=>'listorder DESC','limit'=>'11,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a><br /><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p> 
        </div>
        
        <div class="rg-1">
        	<div class="kzc-ksdt kzc-mg1">
            	<div class="dtcut" id="dtA"><a href="#" class="selected">报考公告</a><a href="#">准考证打印</a></div>
                <div id="dtDIV">
                	<ul class="newslist">
                        <?php $_where = "catid in (420,187,225,226,227,228,229,230,231, 232)"; //英语（420）  计算机（187） 致睿（225  226  227  228  229  230  231  232）?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12baf69d2824cb0ed606b75cf72274f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                    	<li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_ksgg.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'60','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b4134e5af240061108c541932b4b2423&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="newslist" style="display:none;">
                    	<?php $_where = "catid in ('421','196')"; //准考证打印：英语（421）   计算机（196）?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12baf69d2824cb0ed606b75cf72274f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_zkzdy.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'60','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b4134e5af240061108c541932b4b2423&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
            </div>
            <div class="kzc-ksdt">
            	<div class="dtcut" id="dtAone"><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank" class="selected">成绩查询</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">证书领取</a><a href="http://www.renshikaoshi.net/question/" target="_blank">问答中心</a></div>
                <div id="dtDIVone">
                	<div><ul class="newslist">
                    	<?php $_where = "catid in ('422','188')"; //成绩查询： 英语（422）        计算机（188）?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12baf69d2824cb0ed606b75cf72274f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_fscx.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></h2><p><?php echo str_cut(trim($r['description']),'66');?></p></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b4134e5af240061108c541932b4b2423&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul></div>
                	<div style="display:none"><ul class="newslist">
                    	<?php $_where = "catid in ('423','197')"; //证书领取：英语（423）        计算机（197）?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12baf69d2824cb0ed606b75cf72274f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_zslq.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></h2><p><?php echo str_cut(trim($r['description']),'66');?></p></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b4134e5af240061108c541932b4b2423&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'200','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul></div>
                    <div id="teacheryiwen" class="quesdv" style="display:none;">
                        <ul>
                            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=bd0a630bedd3cee62d8d66352a70b822&sql=SELECT+aq.qid%2Caq.question%2Caq.url%2Caq.ip%2Caq.catid%2Caa.%2A+from+v9_ask_question+aq+JOIN+v9_ask_answer+aa+ON+aq.qid%3Daa.qid+WHERE+aq.status+%21%3D+1+AND+aq.aid%3E0+and+aq.siteid%3D%24siteid+ORDER+BY+aa.qid+desc&cache=1800&return=data&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT aq.qid,aq.question,aq.url,aq.ip,aq.catid,aa.* from v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid WHERE aq.status != 1 AND aq.aid>0 and aq.siteid=$siteid ORDER BY aa.qid desc',)).'bd0a630bedd3cee62d8d66352a70b822');if(!$data = tpl_cache($tag_cache_name,1800)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT aq.qid,aq.question,aq.url,aq.ip,aq.catid,aa.* from v9_ask_question aq JOIN v9_ask_answer aa ON aq.qid=aa.qid WHERE aq.status != 1 AND aq.aid>0 and aq.siteid=$siteid ORDER BY aa.qid desc LIMIT 4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
                            <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                            <li><p><a href="<?php echo $val['url'];?>" title="<?php echo $val['question'];?>" target="_blank"><?php echo str_cut($val['question'],'75');?></a></p><p><?php echo str_cut(strip_tags($val['content']),'180');?></p></li>
                            <?php $n++;}unset($n); ?>
                            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="kzc-newsone kzc-btlind" id="banner01">加载中...</div>
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="kzc-dtl"><span>医药卫生职称考试</span><div class="moredv"><a href="<?php echo $CATEGORYS['225']['url'];?>" target="_blank">护士考试</a> / <a href="<?php echo $CATEGORYS['226']['url'];?>" target="_blank">执业医师</a> / <a href="<?php echo $CATEGORYS['227']['url'];?>" target="_blank">医学高级</a> / <a href="<?php echo $CATEGORYS['228']['url'];?>" target="_blank">执业药师</a> / <a href="<?php echo $CATEGORYS['229']['url'];?>" target="_blank">主治医师</a> / <a href="<?php echo $CATEGORYS['230']['url'];?>" target="_blank">主管技师</a> / <a href="<?php echo $CATEGORYS['231']['url'];?>" target="_blank">药师资格</a></div></div>
        
        <div class="xg_ct2">
        	<div class="ct2_cut"><span>考试指南</span></div>
            <ul class="kszn_l">
            	<li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/yxgjks/" class="a1">医学高级</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/yxgjks/m0_t71_1.html" class="a1">2014医学高级职称考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxgjks/m0_t111_1.html">医学高级职称考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxgjks/m0_t97_1.html">医学高级职称考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxgjks/m0_t100_1.html" class="a1">医学高级职称考试真题</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/" class="a1">执业药师</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/m0_t71_1.html" class="a1">2014执业药师考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/m0_t111_1.html">执业药师考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/m0_t97_1.html">执业药师考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/m0_t100_1.html" class="a1">执业药师考试题库</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/zzys/">主治医师</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/zzys/m0_t71_1.html" class="a1">2014主治医师考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/zzys/m0_t111_1.html">主治医师考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/zzys/m0_t97_1.html">主治医师考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/zzys/m0_t100_1.html" class="a1">主治医师考试真题</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/">执业医师</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/m0_t71_1.html" class="a1">2014执业医师考试报名 </a><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/m0_t111_1.html">执业医师考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/m0_t97_1.html">执业医师考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/m0_t100_1.html">执业医师分数线</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyys/m0_t100_1.html" class="a1">执业医师考试真题</a></li>
                <li><strong><a href="/zyzg/yy/yjks/">医技考试</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/zgjs/m0_t71_1.html" class="a1">2014技师考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/zgjs/m0_t111_1.html">技师考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/zgjs/m0_t97_1.html">技师考试成绩查询</a><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yijikaoshi/" class="a1">技师考试题库</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/hszyzgks/">护士考试</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/hszyzgks/m0_t71_1.html" class="a1">2014护士资格证考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/hszyzgks/m0_t111_1.html">护士资格证考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/hszyzgks/m0_t97_1.html">护士资格证考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/hszyzgks/m0_t100_1.html" class="a1">护士资格证考试真题</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/yszg/">药师资格</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/yszg/m0_t71_1.html" class="a1">2014药师资格证考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/yszg/m0_t111_1.html">药师资格证报名时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/yszg/m0_t97_1.html">药师资格证查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/yszg/m0_t100_1.html">药师资格证考试科目</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyyaos/">住院医师</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/zyuanys/m0_t71_1.html" class="a1">2014住院医师规范化考试考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyuanys/m0_t97_1.html">住院医师规范化考试查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/zyuanys/m0_t100_1.html">住院医师规范化考试题库</a></li>
                <li><strong><a href="http://www.renshikaoshi.net/zyzg/yy/yxsj/">医学三基</a></strong><a href="http://www.renshikaoshi.net/zyzg/yy/yxsj/m0_t71_1.html" class="a1">2014医学三基考试报名</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxsj/m0_t111_1.html">医学三基考试时间</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxsj/m0_t97_1.html">医学三基考试成绩查询</a><a href="http://www.renshikaoshi.net/zyzg/yy/yxsj/m0_t100_1.html">医学三基题库</a></li>
            </ul>
        </div>
        
        <div class="xg_ct3">
        	<div class="ct2_cut"><span>考试题库下载</span></div>
            <ul class="xxdowload">
            	<li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/gaojizhichen/" class="a1">医学卫生高级职称考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/gaojizhichen/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhiyeyaoshi/" class="a1">执业药师考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhiyeyaoshi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhuzhiyishi/">主治医师考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhuzhiyishi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhiyeyishi/">执业医师考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhiyeyishi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yijikaoshi/">医技考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yijikaoshi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/hulikaoshi/">护理考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/hulikaoshi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yaoxuezhicheng/">药学职称考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yaoxuezhicheng/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhuyuanyishi/">住院医师考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/zhuyuanyishi/">[下载]</a></span></li>
                <li><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yixuesanji/">医学三基考试宝典</a><span><a href="http://www.renshikaoshi.net/download/yiyaokaoshi/yixuesanji/">[下载]</a></span></li>
            </ul>
        </div>
        
        <div class="clear"></div>
    </div>
    
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="kzc-dtl"><span>职称考试攻略</span><div class="moredv"><a href="http://www.renshikaoshi.net/jsj/jqxd/">职称计算机</a>/<a href="http://www.renshikaoshi.net/english/">职称英语</a>/<a href="http://www.renshikaoshi.net/zyzg/yy/">医药卫生</a></div></div>
        <div class="kzc-xszdty kzc-mg2">
        	<div class="flcut kzc-newsone"><span>医药卫生</span></div>
            <ul class="newslist ftsmall">
            	<?php $catid=217; // 医药卫生?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=aec1dc1839c4e44db60148f10f8d7c85&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_yyws.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=13b697f8862498c51ec3a2f58d299df8&action=lists&catid=%24catid&order=id+DESC&num=6&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="kzc-xszdty kzc-mg2">
        	<div class="flcut kzc-newsone"><span>职称计算机</span></div>
            <ul class="newslist ftsmall">
            	<?php $catid=16 // 考试动态?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=aec1dc1839c4e44db60148f10f8d7c85&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_zcjsj.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=13b697f8862498c51ec3a2f58d299df8&action=lists&catid=%24catid&order=id+DESC&num=6&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>" title_style($r[style])} title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'100','');?></a> </li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="kzc-xszdty">
        	<div class="flcut kzc-newsone"><span>职称英语</span></div>
            <ul class="newslist ftsmall">
                <?php $_where = "catid in (154,155,280)"; //考试指南：英语（154 155 280） 计算机（184）  致睿（871）?>
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=12baf69d2824cb0ed606b75cf72274f4&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_zcyy.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=b4134e5af240061108c541932b4b2423&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cupdatetime+FROM+v9_news+where++status%3D99+and+%24_where+order+by+id+desc&return=data&start=1&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT id,style,url,title,description,updatetime FROM v9_news where  status=99 and $_where order by id desc LIMIT 1,6");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="kzc-newsone kzc-btlind" id="banner02">加载中...</div>
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="kzc-dtl"><span>职称考试辅导</span><div class="moredv"><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/">职称计算机报名</a> / <a href="http://www.renshikaoshi.net/En/ksdt/bktz/">职称英语报名</a> / <a href="http://www.renshikaoshi.net/zyzg/">医药卫生报名</a></div></div>
        <div class="kzc-xszdty kzc-mg2">
        	<div class="flcut kzc-newsone"><span>建筑工程</span><div></div></div>
            <ul class="newslist ftsmall">
            <?php $_where = "catid=218";  //建筑工程?>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=82596745057d65f78e5b3a042857fede&action=lists&catid=218&order=id+DESC&num=1&start=%270%27+cache%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'218','order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_jzgc.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9705de1c571ad9f702769fce851bb034&action=lists&catid=218&order=id+DESC&num=6&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'218','order'=>'id DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="kzc-xszdty kzc-mg2">
        	<div class="flcut kzc-newsone"><span>财会经济</span><div></div></div>
            <ul class="newslist ftsmall">
               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a8a59911bde15c1b7408ef74cb436cfd&action=lists&catid=18&order=id+DESC&num=1&start=%270%27+cache%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'18','order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_ckjj.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f52a62db09df406bbde8887bb6bd3906&action=lists&catid=18&order=id+DESC&num=6&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'18','order'=>'id DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="kzc-xszdty">
        	<div class="flcut kzc-newsone"><span>职业资格</span><div></div></div>
            <ul class="newslist ftsmall">
               <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=48c2e088ee3d1d75723f6d3c2c45249d&action=lists&catid=11&order=id+DESC&num=1&start=%270%27+cache%3D\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'11','order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li class="lione"><a href="<?php echo $r['url'];?>"><img src="/statics/renshikaoshi/images/zy_zyzg.jpg" /></a><div class="pccontent"><h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'80','');?></a></h2></div></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5542a26f0b43d5a189a882e8eaffd511&action=lists&catid=11&order=id+DESC&num=6&start=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'11','order'=>'id DESC','limit'=>'1,6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                        <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'100','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="clear"></div>
    </div>

	<div class="kzc-newsone kzc-btlind" id="banner03">加载中...</div>
    
    <div class="kzc-newsone kzc-btlind">
    	<div class="kzc-dtl"><span>友情链接</span></div>
        <div class="rsbmrk"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"link\" data=\"op=link&tag_md5=2058336d254ea2811f0a8e48148440cd&action=type_list&typeid=0&siteid=%24siteid&order=listorder+DESC&num=48&linktype=0&return=dat\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$link_tag = pc_base::load_app_class("link_tag", "link");if (method_exists($link_tag, 'type_list')) {$dat = $link_tag->type_list(array('typeid'=>'0','siteid'=>$siteid,'order'=>'listorder DESC','linktype'=>'0','limit'=>'48',));}?>
		<?php $n=1;if(is_array($dat)) foreach($dat AS $v) { ?>
              <a href="<?php echo $v['url'];?>" target="_blank"><?php echo $v['name'];?></a>
		<?php $n++;}unset($n); ?>
	<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></div>
    </div>
</div>
<div class="ftadd_link">
    <p align="center"><a href="http://www.renshikaoshi.net/jsjbm/" title="职称计算机考试报名时间" target="_blank">职称计算机考试报名时间</a> - <a href="http://www.renshikaoshi.net/jsjbm/shandong.html" title="山东职称计算机考试报名时间" target="_blank">山东职称计算机考试报名时间</a> - <a href="http://www.renshikaoshi.net/jsjbm/sichuan.html" title="四川职称计算机考试报名时间" target="_blank">四川职称计算机考试报名时间</a> - <a href="http://www.renshikaoshi.net/jsjbm/guangdong.html" title="广东职称计算机考试报名时间" target="_blank">广东职称计算机考试报名时间</a> - <a href="http://www.renshikaoshi.net/jsjbm/hebei.html" title="河北职称计算机考试报名时间" target="_blank">河北职称计算机考试报名时间</a> - <a href="http://www.renshikaoshi.net/jsjbm/yunnan.html" title="云南职称计算机考试报名时间" target="_blank">云南职称计算机考试报名时间</a></p>
    </div>

<?php include template("content","rsks_bottom"); ?>
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
    <!-- 广告位：首页-banner01 -->
    BAIDU_CLB_fillSlotAsync('869421','banner01');
    <!-- 广告位：首页-banner02 -->
    BAIDU_CLB_fillSlotAsync('869426','banner02');
    <!-- 广告位：首页-banner03 -->
    BAIDU_CLB_fillSlotAsync('869431','banner03');
</script>
</body>
</html>
