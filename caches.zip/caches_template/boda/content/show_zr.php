<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?>人事考试资讯网</title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/zyzg/css/toruistyle.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script language="javascript" src="/statics/zyzg/js/qh.js"></script>
<script language="javascript" src="/statics/zyzg/js/scrolltop.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript">
$(function(){
	$("#monikaochang").find("li div:first").show();
	$("#monikaochang li").hover(function(){
	$("#monikaochang").find("li div").hide();
    $(this).find("div").show();
	});
});
</script>
</head>

<body>

<div id="bdshare_l"></div>

<div class="medicalrgpiao"><a href="http://www.renshikaoshi.net/ksbd/" target="_blank" class="a2" title="去商城购买"></a><a href="javascript:;" id="goTopBtn" class="a1" title="返回顶部"></a></div>



<SCRIPT type=text/javascript>goTopEx();</SCRIPT>



<!-- heaer<start>-->



<?php include template("content","rsks_top"); ?>
<?php $ad_ids = explode('|',$CATEGORYS[$catid][ad_ids])?>


<!-- heaer<end>-->











<!-- center<start>-->



<div class="toruitycenter toruipd">
	
    <div class="schoolsk">
    <span class="lfsk">各地人事考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $v['pinyin'];?>.html" title="<?php echo replace_arr($v['name'],array('省','市'));?>人事考试网" target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
		<a href="sitemaps.html#rsbmrk" target="_blank">更多>></a>
    </span>
    <span class="map"></span>
</div>

    <div id="<?php echo $ad_ids['0'];?>"> </div>



    <div class="toruilistymps">您现在的位置：<a href="<?php echo siteurl($siteid);?>">首页</a><span> &gt; </span> <?php if(!in_array($catid, GetCaijiCatid()) ) { ?><a href="<?php echo $CATEGORYS[$catid]['url'];?>"><?php echo $CATEGORYS[$catid]['catname'];?></a> <span> &gt; </span> <?php } else { ?> <a href="<?php echo siteurl($siteid);?>/news/">资讯中心</a> <span> &gt; </span><?php } ?><?php echo $title;?></div>



    



    <div class="toruilistlie">



    



    	<div class="lieleftwai">



    



            



            <div class="lieleft">



                <h1 class="contentnrh1"><?php echo $title;?></h1>



                <div class="contentnrly">来源：<?php if($topCityList) { ?> <a target="_blank" href="/renshibaoming/<?php echo $topCityList['pinyin'];?>.html"><?php echo str_replace(array('省',市),'',$topCityList['name']);?>人事考试网</a><?php } else { ?>  <a href="<?php echo siteurl($siteid);?>">人事考试资讯网</a>  <?php } ?> 发布时间：<?php echo date('Y年m月d日',$rs[inputtime]);?></div>



                <?php if($description) { ?> <div class="contentnrdd ymmg1"><strong>导读：</strong><?php echo $description;?></div><?php } ?>



              <div class="contentwznr" id="contentwznr">



                  <?php echo replace_arr($content);?><?php echo $randcontent;?>
<br />

 本文链接：<?php echo $url;?>

              </div>



                 <?php if($keywords) { ?><div class="contentwordhot"><font>相关热词搜索</font><?php $n=1;if(is_array($keywords)) foreach($keywords AS $keyword) { ?><a href="<?php echo siteurl($siteid);?>/tags-<?php echo urlencode($keyword);?>_<?php echo $catid;?>_1.html" class="blue"><?php echo $keyword;?></a><?php $n++;}unset($n); ?></div> <?php } ?>



               <div class="text-c" id="pages"><?php echo str_replace("_0.html","_1.html",$pages);?></div>



               



            <div class="contentwordhot"><strong>上一篇：</strong><a href="<?php echo $previous_page['url'];?>"><?php echo str_cut($previous_page[title],60);?></a></div>



                <div class="contentwordhot"><strong>下一篇：</strong><a href="<?php echo $next_page['url'];?>"><?php echo str_cut($next_page[title],60);?></a>



                



                </div>



                



                



                



     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"block\" data=\"op=block&tag_md5=863c4298a81ea412717ccf5c32c174a5&pos=content_zyzg_kefu\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">添加碎片</a>";}$block_tag = pc_base::load_app_class('block_tag', 'block');echo $block_tag->pc_tag(array('pos'=>'content_zyzg_kefu',));?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>     


 <div class="zrggmrmg" id="<?php echo $ad_ids['3'];?>"></div>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7d26f71bf2a4e48ff4965a896f5d08dc&action=relation&relation=%24relation&id=%24id&catid=%24catid&num=5&keywords=%24rs%5Bkeywords%5D&order=id+desc\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'relation')) {$data = $content_tag->relation(array('relation'=>$relation,'id'=>$id,'catid'=>$catid,'keywords'=>$rs[keywords],'order'=>'id desc','limit'=>'5',));}?>



                  <?php if($data) { ?>



                   



                    <div class="related" style="display:none">



                        <h5 class="blue">延伸阅读：</h5>



                        <ul class="toruinewslist">



                            <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>



                                <li><a href="<?php echo $r['url'];?>" target="_blank"><?php echo $r['title'];?></a><span>(<?php echo date('Y-m-d',$r[inputtime]);?>)</span></li>



                            <?php $n++;}unset($n); ?>



                        </ul>



                    </div>



                  <?php } ?>



              <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>  
 <ul class="newslist ftsmall listmore <?php echo $city_id;?>">
              <?php $where = "catid=$catid and level=1 ";?>
              <?php $where = ($city_id>0)?$where." and cityid=$city_id":$where;?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=93a41709ef79f0c53b3f51377d9abcff&sql=SELECT+%2A+from+phpcms_diypage+WHERE+%24where&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE $where LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
<li><a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a></li>
<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>


              



              







          </div>



      </div>



        



        <div class="lieright">



        	<!--右侧广告位一-->



            <div class="toruibanner" id="<?php echo $ad_ids['1'];?>"></div>



            





            <!--右侧广告位二-->



            <div class="toruibanner" id="979203"></div>



        



        	<div class="lietydv">



            	<span class="rgtrcut">热门推荐</span>



                <ul class="toruinewslist toruinewslistxg">



              <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=1a9f7d9fe4836c4b4521bc6be5a792f8&action=position&posid=292&order=listorder+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'292','order'=>'listorder DESC','limit'=>'10',));}?>



                <?php $i=1?>



				<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>



                    <li><i <?php if($i>3) { ?>class="num"<?php } ?>><?php echo $i;?></i><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 48, '');?></a></li>



                    <?php $i++?>



				<?php $n++;}unset($n); ?>



			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>



            </div>



            <!-- 广告位：致睿-内容页-左侧中栏 右侧广告位三 -->



            <div class="toruibanner" id="<?php echo $ad_ids['2'];?>"></div>



            <div class="lietydv">



            	<span class="rgtrcut">试题排行</span>



                <ul class="toruinewslist toruinewslistxg">



                   	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d09a3bdd996817c252fccd081b70bebc&action=hits&catid=%24catid&num=10&order=monthviews+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>$catid,'order'=>'monthviews DESC',)).'d09a3bdd996817c252fccd081b70bebc');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>$catid,'order'=>'monthviews DESC','limit'=>'10',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>



                    <?php $i=1?>



				<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>



                    <li><i <?php if($i>3) { ?>class="num"<?php } ?>><?php echo $i;?></i><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 48, '');?></a></li>



                    <?php $i++?>



				<?php $n++;}unset($n); ?>



			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>



                </ul>



            </div>



            



            <!--右侧广告位四-->



            <div class="toruibanner" id="979206"></div>



            



            </div>



            





            



        </div>



        <div class="toruiclear"></div>



    </div>



    



</div>



<!-- center<end>-->







<!-- footer<start>-->



<script language="JavaScript" src="/kscount_<?php echo $id;?>_<?php echo $modelid;?>.html"></script>



	<?php include template("content","rsks_bottom"); ?>

<!-- footer<end>-->



<!--异步加载开始-->



 <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>







<script language="javascript" src="/statics/zyzg/js/jq_scroll.js"></script>











<script type="text/javascript">







$(document).ready(function(){







$("#contentwdhg").Scroll({line:3,speed:500,timer:3000});







});







</script>


<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
<?php $n=1; if(is_array($ad_ids)) foreach($ad_ids AS $k => $v) { ?>
<?php if($v>0) { ?>
    BAIDU_CLB_fillSlotAsync('<?php echo $v;?>', '<?php echo $v;?>');
	<?php } ?>
	<?php $n++;}unset($n); ?>
</script>
<!--异步加载结束 -->




<!--异步加载结束 --> 

<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>

<script type="text/javascript" src="/statics/js/53kefu.js"></script>

<!-- Baidu Button BEGIN-->

<!---->

<script type="text/javascript" id="bdshare_js" data="type=slide&amp;img=8&amp;pos=left&amp;uid=585549" ></script>

<script type="text/javascript" id="bdshell_js"></script>

<script type="text/javascript">

document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);

</script> 

<!-- Baidu Button end-->



</body>



</html>



