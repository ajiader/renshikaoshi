<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><header>

<div class="kzctop-fixed">

	<div class="cy-tyct">
    	<div class="sitemapflt"><a href="javascript:void(0)">加入收藏</a>|<a href="/download/" target="_blank">题库下载</a>|<a href="/sitemaps.html" target="_blank">网站地图</a></div>
        <div class="bdsharetp">
            <!-- Baidu Button BEGIN -->
            <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
                <a class="bds_qzone">QQ空间</a>
                <a class="bds_tsina">新浪微博</a>
                <a class="bds_tqq">腾讯微博</a>
                <a class="bds_renren">人人网</a>
                <span class="bds_more">更多</span>
                <a class="shareCount"></a>
            </div>
            <!-- Baidu Button END -->
        </div>
        
    </div>

</div>

<div class="kzcheader">

	<div class="cy-tyct">

        <!-- logo-->

        <div class="schoollogodv">

            <div class="dvlogo"><a href="/"><img src="/statics/renshikaoshi/images/logo.png" /></a></div>

            <div class="dvss">

              <form target="_blank" action="http://zhannei.baidu.com/cse/search">
				<input type="hidden" value="12015755717762391354" name="s">
                <span><input type="text" name="q" class="txt" /><input type="submit" name="ssbtn" class="btn" value="搜索" /></span>
  			  </form>

                <span class="hotnew">热门搜索：<a href="http://zhannei.baidu.com/cse/search?q=<?php echo urlencode('职称计算机');?>&s=2481340568731389422" target="_blank">职称计算机</a><a href="http://zhannei.baidu.com/cse/search?q=<?php echo urlencode('职称英语');?>&s=2481340568731389422" target="_blank">职称英语</a><a target="_blank" href="http://zhannei.baidu.com/cse/search?q=<?php echo urlencode('医药卫生');?>&s=2481340568731389422">医药卫生</a><a href="http://zhannei.baidu.com/cse/search?q=<?php echo urlencode('考试报名');?>&s=2481340568731389422" target="_blank">考试报名</a></span>

            </div>

            <div class="clear"></div>

        </div>

        <!-- 导航-->

        <div class="xgmenu">
        	<div class="xg_lf">
            	<p><strong><a href="<?php echo $CATEGORYS['217']['url'];?>" target="_blank">医药卫生</a></strong><a target="_blank" href="<?php echo $CATEGORYS['227']['url'];?>" class="a1">医学高级</a>/<a target="_blank" href="<?php echo $CATEGORYS['228']['url'];?>" class="a1">执业药师</a>/<a target="_blank" href="<?php echo $CATEGORYS['226']['url'];?>" class="a1">执业医师</a>/<a target="_blank" href="<?php echo $CATEGORYS['229']['url'];?>" class="a1">主治医师</a>/<a target="_blank" href="<?php echo $CATEGORYS['230']['url'];?>">医技考试</a>/<a target="_blank" href="<?php echo $CATEGORYS['225']['url'];?>">护士考试</a>/<a target="_blank" href="<?php echo $CATEGORYS['231']['url'];?>">药师资格</a>/<a target="_blank" href="<?php echo $CATEGORYS['924']['url'];?>">住院医师</a>/<a target="_blank" href="<?php echo $CATEGORYS['291']['url'];?>">医学三基</a></p>
                
                <p><strong><a target="_blank" href="<?php echo $CATEGORYS['218']['url'];?>">建筑工程</a></strong><a target="_blank" href="<?php echo $CATEGORYS['244']['url'];?>" class="a1">一级建造师</a>/<a target="_blank" href="<?php echo $CATEGORYS['252']['url'];?>">土地代理人</a>/<a target="_blank" href="<?php echo $CATEGORYS['253']['url'];?>">环境评价师</a>/<a target="_blank" href="<?php echo $CATEGORYS['233']['url'];?>">一级建筑师</a>/<a target="_blank" href="<?php echo $CATEGORYS['248']['url'];?>">监理工程师</a>/<a target="_blank" href="<?php echo $CATEGORYS['234']['url'];?>">二级建筑师</a>/<a target="_blank" href="<?php echo $CATEGORYS['245']['url'];?>" class="a1">二级建造师</a></p>
                
                <p><strong><a target="_blank" href="<?php echo $CATEGORYS['18']['url'];?>">财会经济</a></strong><a target="_blank" href="<?php echo $CATEGORYS['294']['url'];?>">保险代理</a>/<a target="_blank" href="<?php echo $CATEGORYS['255']['url'];?>">会计从业</a>/<a target="_blank" href="<?php echo $CATEGORYS['271']['url'];?>">中级经济师</a>/<a target="_blank" href="<?php echo $CATEGORYS['256']['url'];?>" class="a1">初级会计师</a>/<a target="_blank" href="<?php echo $CATEGORYS['257']['url'];?>">中级会计师</a>/<a target="_blank" href="<?php echo $CATEGORYS['258']['url'];?>">注册会计师</a>/<a target="_blank" href="<?php echo $CATEGORYS['273']['url'];?>">证券经纪人</a></p>
            </div>
            <div class="xg_rg">
            	<a href="<?php echo $CATEGORYS['10']['url'];?>" class="a1" target="_blank">职称计算机</a><a href="<?php echo $CATEGORYS['9']['url'];?>" target="_blank">职称英语</a><a  href="<?php echo $CATEGORYS['457']['url'];?>" target="_blank">人力资源师</a><a  href="<?php echo $CATEGORYS['491']['url'];?>" target="_blank" class="a1">司法考试</a><a  href="<?php echo $CATEGORYS['908']['url'];?>" target="_blank">深圳职员</a><a  href="<?php echo $CATEGORYS['806']['url'];?>" target="_blank">心理咨询师</a><a href="/" target="_blank">返回首页</a>
            </div>
        </div>

    </div>

</div>

</header>