<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>

<meta name="keywords" content="<?php echo $SEO['keyword'];?>">

<meta name="description" content="<?php echo $SEO['description'];?>">

<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />

<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />

<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>

<script language="javascript" src="/statics/renshikaoshi/js/dvqh.js"></script>

</head>



<body>

<?php include template("content","rsks_top"); ?>



<div class="cy-tyct">
<div class="schoolsk">
    <span class="lfsk">计算机各地考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/jsj/<?php echo $v['pinyin'];?>/" title="<?php echo replace_arr($v['name'],array('省','市'));?>职称计算机考试"  target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
    </span>
    <span class="map"></span>
</div>
	<div class="kzc-jsj-top">

    	<div class="kzc-jsj-lfpic">

            <div class="slider-wrapper theme-default">

                <div class="ribbon"></div>

                <div id="sliderjsj" class="nivoSlider">

                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=31e38495549f4a8b6ea86d260594a830&action=position&posid=227&order=listorder+DESC&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'227','order'=>'listorder DESC','limit'=>'5',));}?> <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>

                        <a href="<?php echo $val['url'];?>"><img src="<?php echo thumb($val['thumb'],308,272);?>" title="<?php echo $val['title'];?>" /></a>

                         <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>                </div>

            </div>

        	<script type="text/javascript" src="/statics/renshikaoshi/js/jquery.nivo.slider.pack.js"></script>

			<script type="text/javascript">

            $(window).load(function() {

                $('#sliderjsj').nivoSlider();

            });

            </script>

        </div>

        

        <div class="kzc-jsj-ctnew">

        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=50e7dc06e23fa674f1ee2d55bf3ff798&action=lists&catid=187&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

        	<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'45','');?></a></h2>

            <p class="hotcontent"><?php echo str_cut($r['description'],152);?> <a href="<?php echo $r['url'];?>" target="_blank">详细>></a></p>

            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dbbcfa7d697324bd5d2a6f0fc11be03e&action=lists&catid=187&order=id+DESC&num=2&start=3\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'3,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dac0f1167da98149b26f32bbe23ccc6f&action=lists&catid=187&order=id+DESC&num=2&start=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'5,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

            

            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9994571999bfbe07a0189714476d8dbf&action=lists&catid=187&order=id+DESC&num=1&start=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'7,1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

        	<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'45','');?></a></h2>

            <p class="hotcontent"><?php echo str_cut($r['description'],152);?> <a href="<?php echo $r['url'];?>" target="_blank">详细>></a></p>

            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7a9dd39864265ba9bfd90d8ee175df18&action=lists&catid=187&order=id+DESC&num=2&start=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'8,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

            <p class="hotlist"><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=251e1e2fde0030f933bef8f3c368b30d&action=lists&catid=187&order=id+DESC&num=2&start=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'10,2',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'36','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>

        </div>

        

        <div class="kzc-jsj-rgtj">

        	<div class="rgcut">精彩推荐<span>Recommend</span></div>

            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=535c18803bf10338abb81181a2ff4ad6&action=hits&catid=202&num=1&start=0&order=views+DESC&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'202','order'=>'views DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

            <div class="rgtjpic"><a href="<?php echo $r['url'];?>"  title="<?php echo $r['title'];?>"><img src="<?php echo thumb($r['thumb'],260,110);?>" width="260"  height="110"/></a><p><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo str_cut($r['title'],46);?></a></p></div>

            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

            <ul class="newslist ftsmall">

            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9cb035e8005f364d057da45dec6dc55c&action=hits&catid=202&num=5&start=1&order=views+DESC&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>'202','order'=>'views DESC','limit'=>'1,5',));}?>

                    <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>

                        <li><a href="<?php echo $r['url'];?>" target="_blank" title=<?php echo $r['title'];?>><?php echo str_cut($r[title], 46, '');?></a></li>

                    <?php $n++;}unset($n); ?>

                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

            </ul>

        </div>

        <div class="clear"></div>

    </div>

    

    <div class="kzc-jsjtwo">

    	<div class="eightk">

        	<a href="http://www.renshikaoshi.net/kaoshi-185-106623-1.html" target="_blank">报考条件</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106684-1.html" target="_blank">合格标准</a>

            <a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank" class="mrling">报名时间</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106622-1.html" target="_blank">考试实施</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106640-1.html" target="_blank">考试科目</a>

            <a href="<?php echo $CATEGORYS['189']['url'];?>" target="_blank" class="mrling">历年真题</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106642-1.html" target="_blank">成绩查询</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106686-1.html" target="_blank">证书管理</a>

            <a href="http://www.renshikaoshi.net/jsj/jqxd/" target="_blank" class="mrling">考试心得</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-88138-1.html" target="_blank">考试教材</a>

            <a href="http://www.renshikaoshi.net/kaoshi-185-106620-1.html" target="_blank">考试介绍</a>

            <a href="<?php echo $CATEGORYS['182']['url'];?>" target="_blank" class="mrling">考试解密</a>

        </div>

        

        <div class="jsjzixun">

        	<div class="zxcut">最新资讯</div>

            <ul class="daitime">

            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=e96c9e5e2c8a7987cf739f8b4dcfcdf4&action=lists&catid=16&order=id+DESC&num=9&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'16','order'=>'id DESC',)).'e96c9e5e2c8a7987cf739f8b4dcfcdf4');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'16','order'=>'id DESC','limit'=>'9',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

            </ul>

        </div>

        

        <div class="kzc-onerg">

        	<div class="onecut">考试报名<a href="<?php echo $CATEGORYS['187']['url'];?>" class="more">more</a></div>

            <ul class="daitime">

            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0e2543b6afe058d30ae3c41d5a2049a3&action=lists&catid=187&order=id+DESC&num=4&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'187','order'=>'id DESC',)).'0e2543b6afe058d30ae3c41d5a2049a3');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'4',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'50','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

            </ul>

            <div class="onecut">报考指南<a href="<?php echo $CATEGORYS['184']['url'];?>" class="more">more</a></div>

            <ul class="daitime">

            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ec34d24741a76651be2f490d32beeff1&action=lists&catid=184&order=id+DESC&num=4&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'184','order'=>'id DESC',)).'ec34d24741a76651be2f490d32beeff1');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'184','order'=>'id DESC','limit'=>'4',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'50','');?></a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

            </ul>

        </div>

        <div class="clear"></div>

    </div>

    

    <div class="kzc-newsone" id="PAGE_AD_center">加载中...</div>

    

     <!--考试资讯 -->

    <div class="examinationtycut"><span class="sp1"><a href="<?php echo $CATEGORYS['187']['url'];?>">考试报名</a><a href="<?php echo $CATEGORYS['188']['url'];?>">成绩查询</a><a href="<?php echo $CATEGORYS['196']['url'];?>">准考证打印</a><a href="<?php echo $CATEGORYS['197']['url'];?>">证书领取</a></span><h2>考试资讯</h2></div>

    <div class="examinationnrqh">

    	<div class="qhtitlelft"><a href="javascript:;" id="qhnrright1" onmouseover="qhnrright(1)" class="selected">考试报名</a><a  href="javascript:;" id="qhnrright2" onmouseover="qhnrright(2)">成绩查询</a><a  href="javascript:;" id="qhnrright3" onmouseover="qhnrright(3)">准考证打印</a><a  href="javascript:;" id="qhnrright4" onmouseover="qhnrright(4)">证书领取</a></div>

        <div class="qhnrright" id="qhnrrightDIV1">

        	<div class="nrty exammgtwo">

            	<h2 class="titlecut remindcut"><i></i>报名入口<a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank" class="more">更多>></a></h2>

                <span class="spalist"><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">全国</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">安徽</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">北京</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">福建</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">甘肃</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">广东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">广西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">贵州</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">海南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">河北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">河南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">湖北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">湖南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">吉林</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">江苏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">江西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">辽宁</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">宁夏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">青海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">山东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">山西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">陕西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">上海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">四川</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">天津</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">西藏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">新疆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">云南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">浙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">重庆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/bktz/" target="_blank">黑龙江</a><a href="#">内蒙古</a></span>

            </div>

            <div class="nrty">

            	<h2 class="titlecut remindcut"><i></i>报名资讯<a href="<?php echo $CATEGORYS['187']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=78c08181b220c2b0778442d8352a69ca&action=lists&catid=187&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'187','order'=>'id DESC',)).'78c08181b220c2b0778442d8352a69ca');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'187','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

        </div>

        <div class="qhnrright" id="qhnrrightDIV2" style="display:none;">

        	<div class="nrty exammgtwo">

            	<h2 class="titlecut remindcut"><i></i>查分入口<a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank" class="more">更多>></a></h2>

                <span class="spalist"><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">全国</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">安徽</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">北京</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">福建</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">甘肃</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">广东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">广西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">贵州</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">海南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">河北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">河南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">湖北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">湖南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">吉林</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">江苏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">江西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">辽宁</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">宁夏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">青海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">山东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">山西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">陕西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">上海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">四川</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">天津</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">西藏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">新疆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">云南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">浙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">重庆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">黑龙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" target="_blank">内蒙古</a></span>

            </div>

            <div class="nrty">

            	<h2 class="titlecut remindcut"><i></i>查分资讯<a href="<?php echo $CATEGORYS['188']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=98d0e489e76a3dff5114f248e0a71bc4&action=lists&catid=188&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'188','order'=>'id DESC',)).'98d0e489e76a3dff5114f248e0a71bc4');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'188','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

        </div>

        <div class="qhnrright" id="qhnrrightDIV3" style="display:none;">

        	<div class="nrty exammgtwo">

            	<h2 class="titlecut remindcut"><i></i>打印入口<a href="http://www.renshikaoshi.net/jsj/ksdt/cjcx/" class="more">更多>></a></h2>

                <span class="spalist"><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">全国</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">安徽</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">北京</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">福建</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">甘肃</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">广东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">广西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">贵州</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">海南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">河北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">河南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">湖北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">湖南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">吉林</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">江苏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">江西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">辽宁</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">宁夏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">青海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">山东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">山西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">陕西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">上海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">四川</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">天津</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">西藏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">新疆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">云南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">浙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">重庆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">黑龙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zkz/" target="_blank">内蒙古</a></span>

            </div>

            <div class="nrty">

            	<h2 class="titlecut remindcut"><i></i>准考证资讯<a href="<?php echo $CATEGORYS['196']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6049e2cbb2403e1cf840bf88e1f84538&action=lists&catid=196&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'196','order'=>'id DESC',)).'6049e2cbb2403e1cf840bf88e1f84538');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'196','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

        </div>

        <div class="qhnrright" id="qhnrrightDIV4" style="display:none;">

        	<div class="nrty exammgtwo">

            	<h2 class="titlecut remindcut"><i></i>领取入口<a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank" class="more">更多>></a></h2>

                <span class="spalist"><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">全国</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">安徽</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">北京</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">福建</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">甘肃</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">广东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">广西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">贵州</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">海南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">河北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">河南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">湖北</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">湖南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">吉林</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">江苏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">江西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">辽宁</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">宁夏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">青海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">山东</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">山西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">陕西</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">上海</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">四川</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">天津</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">西藏</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">新疆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">云南</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">浙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">重庆</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">黑龙江</a><a href="http://www.renshikaoshi.net/jsj/ksdt/zslq/" target="_blank">内蒙古</a></span>

            </div>

            <div class="nrty">

            	<h2 class="titlecut remindcut"><i></i>合格证资讯<a href="<?php echo $CATEGORYS['197']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9fa100e7105a49094bb1975b360f2282&action=lists&catid=197&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'197','order'=>'id DESC',)).'9fa100e7105a49094bb1975b360f2282');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'197','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

        </div>

        <div class="examtyclear"></div>

    </div>

    

    <!--科目辅导 -->

    <div class="examinationtycut"><span class="sp1"><a href="<?php echo $CATEGORYS['200']['url'];?>" target="_blank" class="selected">windowsXP</a><a href="<?php echo $CATEGORYS['199']['url'];?>" target="_blank">word</a><a href="<?php echo $CATEGORYS['201']['url'];?>" target="_blank">Excel</a><a href="<?php echo $CATEGORYS['202']['url'];?>" target="_blank">Powerpoint</a><a   href="<?php echo $CATEGORYS['203']['url'];?>" target="_blank">Internet</a></span><h2>科目辅导</h2></div>

    <div class="examinationnrqh examhg1">

    	<div class="qhtitlelft examhg1"><a href="<?php echo $CATEGORYS['200']['url'];?>" target="_blank" class="selected">windowsXP</a><a href="<?php echo $CATEGORYS['199']['url'];?>" target="_blank">word</a><a href="<?php echo $CATEGORYS['201']['url'];?>" target="_blank">Excel</a><a href="<?php echo $CATEGORYS['202']['url'];?>" target="_blank">Powerpoint</a><a   href="<?php echo $CATEGORYS['203']['url'];?>" target="_blank">Internet</a></div>

        <div class="qhnrright">

        	<div class="nrty exammgtwo">

            	<h2 class="titlecut remindcut"><i></i>专项辅导<a href="<?php echo $CATEGORYS['198']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=532ef2f0859e7095cf4ec58233d45406&action=lists&catid=198&order=id+DESC&num=7&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'198','order'=>'id DESC',)).'532ef2f0859e7095cf4ec58233d45406');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'198','order'=>'id DESC','limit'=>'7',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

            <div class="nrty">

            	<h2 class="titlecut remindcut"><i></i>技巧心得<a href="<?php echo $CATEGORYS['192']['url'];?>" target="_blank" class="more">更多>></a></h2>

                <ul class="daitime">

                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=853e9a57ae659dc54d77416922b73349&action=lists&catid=192&order=id+DESC&num=7&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'192','order'=>'id DESC',)).'853e9a57ae659dc54d77416922b73349');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'192','order'=>'id DESC','limit'=>'7',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                   <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                  <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                </ul>

            </div>

        </div>

        <div class="examtyclear"></div>

    </div>

    

    <!--培训辅导 -->

    <div class="examinationtycut"><span class="sp1"><a href="<?php echo $CATEGORYS['200']['url'];?>" target="_blank" class="selected">windowsXP</a><a href="<?php echo $CATEGORYS['199']['url'];?>" target="_blank">word</a><a href="<?php echo $CATEGORYS['201']['url'];?>" target="_blank">Excel</a><a href="<?php echo $CATEGORYS['202']['url'];?>" target="_blank">Powerpoint</a><a   href="<?php echo $CATEGORYS['203']['url'];?>" target="_blank">Internet</a></span><h2>培训辅导</h2></div>

    <div class="examinationnrqh examhg2">

    	<div class="qhtitlelft examhg1" id="bmzxA">

            <a href="<?php echo $CATEGORYS['192']['url'];?>" class="selected" target="_blank">技巧心得</a>

            <a>考试动态 </a>

            <a>考试辅导</a>

        </div>

        <div id="bmzxDIV">

            <div class="qhnrright">

            	<div class="nrty exammgtwo">

                	<h2 class="titlecut remindcut"><i></i>备考技巧<a href="<?php echo $CATEGORYS['192']['url'];?>" target="_blank" class="more">更多&gt;&gt;</a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f4eb269832719f805458056ae259702f&action=lists&catid=192&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'192','order'=>'id DESC',)).'f4eb269832719f805458056ae259702f');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'192','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                    </ul>

                </div>

                <div class="nrty">

                	<h2 class="titlecut remindcut"><i></i>专家解题<a href="<?php echo $CATEGORYS['917']['url'];?>" target="_blank" class="more">更多>></a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cf3663c24d9ffe2e15d9c8826e8266e8&action=lists&catid=917&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'917','order'=>'id DESC',)).'cf3663c24d9ffe2e15d9c8826e8266e8');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'917','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 

                    </ul>

                </div>

            </div>



            <div class="qhnrright" style="display:none;">

                <div class="nrty exammgtwo">

                    <h2 class="titlecut remindcut"><i></i>考试政策<a href="<?php echo $CATEGORYS['185']['url'];?>" target="_blank" class="more">更多&gt;&gt;</a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=f9589b58235a4d0f7ec7c0a111e016c4&action=lists&catid=185&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'185','order'=>'id DESC',)).'f9589b58235a4d0f7ec7c0a111e016c4');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'185','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                    </ul>

                </div>

                <div class="nrty">

                    <h2 class="titlecut remindcut"><i></i>考试大纲<a href="<?php echo $CATEGORYS['186']['url'];?>" target="_blank" class="more">更多&gt;&gt;</a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=63c77e18663a1921c1b1b3d75c0d9eb2&action=lists&catid=186&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'186','order'=>'id DESC',)).'63c77e18663a1921c1b1b3d75c0d9eb2');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'186','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                    </ul>

                </div>

            </div>



            <div class="qhnrright" style="display:none;">

                <div class="nrty exammgtwo">

                    <h2 class="titlecut remindcut"><i></i>历年真题<a href="<?php echo $CATEGORYS['189']['url'];?>" target="_blank" class="more">更多&gt;&gt;</a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=81b87f0236cb7ac7be7900ae5112357a&action=lists&catid=189&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'189','order'=>'id DESC',)).'81b87f0236cb7ac7be7900ae5112357a');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'189','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                    </ul>

                </div>

                <div class="nrty">

                    <h2 class="titlecut remindcut"><i></i>模拟试题<a href="<?php echo $CATEGORYS['190']['url'];?>" target="_blank" class="more">更多>></a></h2>

                    <ul class="daitime">

                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=32d02b3046a5546ef873d78e72736c18&action=lists&catid=190&order=id+DESC&num=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'190','order'=>'id DESC',)).'32d02b3046a5546ef873d78e72736c18');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'190','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>

                       <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>

                      <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

                    </ul>

                </div>

            </div>



        </div>

        <div class="examtyclear"></div>

    </div>

    

</div>



<?php include template("content","rsks_bottom"); ?>



<!-- 请置于所有广告位代码之前 -->

<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>

<script type="text/javascript">

    BAIDU_CLB_fillSlotAsync('874620', 'PAGE_AD_center');

</script>

<script language="javascript">

$(document).ready(function(){

    $('#bmzxA a').mouseover(function(){

        $(this).addClass("selected").siblings().removeClass();

        $("#bmzxDIV > div").eq($('#bmzxA a').index(this)).show().siblings().hide();

    });

});

</script>

</body>



</html>















