<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link href="<?php echo CSS_PATH;?>vms/reset.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH;?>vms/sty.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH;?>vms/vms.css" rel="stylesheet" type="text/css" />
<link href="/statics/css/boda/kaozc/style/kuaijishi.css" rel="stylesheet" type="text/css" />
<link href="/statics/css/boda/kaozc/style/index.css" rel="stylesheet" type="text/css" />
<link href="/statics/css/boda/kaozc/huandeng/css/css.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.sgallery.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>search_common.js"></script>
</head>
<body>

<?php include template("content","top_mini"); ?>
<div id="PAGE_AD_537808" align="center"></div>


<div id="PartTwo" class="newsBox">
  <h2 class="dominantColor"><span class="columnName simhei18"><a href="<?php echo $url;?>" target="_blank"><?php echo $catname;?></a></span><span class="subMenu">
  <?php $j=1;?>
  <?php $n=1;if(is_array(subcat($catid))) foreach(subcat($catid) AS $v) { ?>
  <?php if($j == 8) break;?>
  <a href="<?php echo $v['url'];?>" target="_blank"><?php echo $v['catname'];?></a> |
    <?php $j++; ?>
  <?php $n++;}unset($n); ?></span></h2>
  <!-- 辅导资料编辑推荐-->
  <div class="tuijian marT8"><span></span>
  <ul>
 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cdcf232eff1560a34855189c57ef469c&action=lists&catid=%24catid&where=posids+%3D+1+and+%60status%60%3D99&order=id+DESC&num=6\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'where'=>'posids = 1 and `status`=99','order'=>'id DESC','limit'=>'6',));}?>
  <?php $n=1; if(is_array($data)) foreach($data AS $k => $v) { ?>
  <li><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>" target="_blank"<?php echo title_style($v[style]);?>><?php echo str_cut($v[title], 54, '');?></a></li>
<?php $n++;}unset($n); ?> <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
</ul>
		  <div class="clearfloat"></div>
  </div>
  <div class="main newsLi14">
  
<div class="left">
    


	<?php $j=1;?>
	<?php $n=1;if(is_array(subcat($catid))) foreach(subcat($catid) AS $v) { ?>
	<?php if($v['type']!=0) continue;?>
<div class="box<?php if($j%2==0) { ?>2 <?php } ?>">
      <h3><a href="<?php echo $v['url'];?>" target="_blank"><?php echo $v['catname'];?></a><span><a href="<?php echo $v['url'];?>" target="_blank">更多</a></span></h3>
<ul>
 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ad241747ba32229aa0b286102720071e&action=lists&catid=%24v%5Bcatid%5D&num=6&order=id+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$v[catid],'order'=>'id DESC','limit'=>'6',));}?>
 	<?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>
<li><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>" target="_blank"<?php echo title_style($v[style]);?>><?php echo str_cut($v[title], 54, '');?></a></li>
<?php $n++;}unset($n); ?>
				<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>

</ul>
      <div class="clearfloat marV5"></div>
</div>
<?php $j++; ?>
	<?php $n++;}unset($n); ?>
 
</div>
    
    
    
    <div class="right hot">
      <div class="tit"></div>
      <h3 class="marT8">热门排行</h3>
      <ul>
       <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0ad40a45ad075d8f47798a231e25aec2&action=hits&catid=%24catid&num=10&order=views+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>$catid,'order'=>'views DESC',)).'0ad40a45ad075d8f47798a231e25aec2');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>$catid,'order'=>'views DESC','limit'=>'10',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
     <?php $n=1;if(is_array($data)) foreach($data AS $v) { ?>
					<li><a href="<?php echo $v['url'];?>" title="<?php echo $v['title'];?>" target="_blank"<?php echo title_style($v[style]);?>><?php echo str_cut($v[title], 54, '');?></a></li>
				<?php $n++;}unset($n); ?>
			<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
</ul></div>
  </div><div class="clearfloat"></div>
</div>
<!--异步加载开始-->
 <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
 <script type="text/javascript">
    BAIDU_CLB_fillSlotAsync('','');

</script>
<!--异步加载结束 --> 
<div align="center">
<?php include template("content","rsks_bottom"); ?>
</div>
</body>
</html>