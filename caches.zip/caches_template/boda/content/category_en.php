<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<script language="javascript">
$(document).ready(function(){
	$('#hotnewsqha a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#hotnewsqhdv > ul").eq($('#hotnewsqha a').index(this)).show().siblings().hide();
	});
	$('#lglA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#lglDIV > ul").eq($('#lglA a').index(this)).show().siblings().hide();
	});
	$('#wslA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#wslDIV > ul").eq($('#wslA a').index(this)).show().siblings().hide();
	});
	$('#jtjqA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#jtjqDIV > ul").eq($('#jtjqA a').index(this)).show().siblings().hide();
	});
});
</script>
</head>

<body>

<?php include template("content","rsks_top"); ?>

<div class="cy-tyct">
<div class="schoolsk">
    <span class="lfsk">职称英语各地考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/En/<?php echo $v['pinyin'];?>/" title="<?php echo replace_arr($v['name'],array('省','市'));?>职称英语考试"  target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
    </span>
    <span class="map"></span>
</div>
	<div class="kzc-en-indexlf">
    	<div class="en-pc-qh">
        	<div id="wrapper">
                <div class="slider-wrapper theme-default">
                    <div class="ribbon"></div>
                    <div id="slider" class="nivoSlider">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a1cef0c55944eeb2cc88805edc14a693&action=position&posid=131&order=listorder+DESC&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'131','order'=>'listorder DESC','limit'=>'5',));}?> <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                        <a href="<?php echo $val['url'];?>"><img src="<?php echo thumb($val['thumb'],420,240);?>" title="<?php echo $val['title'];?>" /></a>
                         <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </div>
                </div>
            </div>
        	<script type="text/javascript" src="/statics/renshikaoshi/js/jquery.nivo.slider.pack.js"></script>
			<script type="text/javascript">
            $(window).load(function() {
                $('#slider').nivoSlider();
            });
            </script>
        </div>
        
        <div class="hotnew">
        	
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=45bd61d795374bff4d3745ce34313303&action=lists&catid=419&order=id+DESC&num=1&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'45bd61d795374bff4d3745ce34313303');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'1',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
			<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'68','');?></a></h2>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        	<p><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=434b8c5d5d20557ecdd3bcad1c3272e4&action=lists&catid=419&order=id+DESC&num=2&start=1&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'434b8c5d5d20557ecdd3bcad1c3272e4');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'1,2',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'50','');?></a>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d3cb9b89f63cecf7ff19f89c556f8114&action=lists&catid=419&order=id+DESC&num=1&start=3&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'d3cb9b89f63cecf7ff19f89c556f8114');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'3,1',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
			<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'68','');?></a></h2>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        	<p><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=6b1bb7d2affbe51d16817237d1ad34aa&action=lists&catid=419&order=id+DESC&num=2&start=4&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'6b1bb7d2affbe51d16817237d1ad34aa');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'4,2',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'50','');?></a>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ddace06519ce3016a1c63428782f2535&action=lists&catid=419&order=id+DESC&num=1&start=6&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'ddace06519ce3016a1c63428782f2535');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'6,1',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
			<h2><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'68','');?></a></h2>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        	<p><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=e67b3ffb2c305d03cc70ac1eeb8d18c1&action=lists&catid=419&order=id+DESC&num=2&start=7&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'e67b3ffb2c305d03cc70ac1eeb8d18c1');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'7,2',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            <a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'50','');?></a>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
        </div>
        <!--循环div<start>-->
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5bcf10e68db2efae2d8014f7c8849e12&action=lists&catid=419&order=id+DESC&num=9&start=9&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'419','order'=>'id DESC',)).'5bcf10e68db2efae2d8014f7c8849e12');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'419','order'=>'id DESC','limit'=>'9,9',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
        <div class="hotdv">
        	<h3><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank>[<?php echo str_cut(trim($r[title]),'50','');?>]</a></h3>
            <p class="ply"><?php echo date('Y-m-d',$r[inputtime]);?></p>
            <p class="pcont"><?php echo str_cut(trim($r[description]),'84','');?>...<a href="<?php echo $r['url'];?>" target="_blank">[详细]</a></p>
        </div>
        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <!--循环div<end>-->
        <div class="ckmore"><a href="/En/ksdt/bktz/" target="_blank">查看更多</a></div>
    </div>
    
    <div class="kzc-en-indexrg">
    	<div class="rgdvty rgmg">
        	<div class="enrgcut"><span class="entitle">考试报名</span><a href="<?php echo $CATEGORYS['420']['url'];?>" target="_blank" class="more">more</a></div>
            <ul class="ennewsul">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ca1da34a9041c4bc4253294e9e2a3fd7&action=lists&catid=420&order=id+DESC&num=6&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'420','order'=>'id DESC','limit'=>'6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>"

  target=_blank><?php echo str_cut(trim($r[title]),'50','');?></a></li>
                 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="rgdvty">
        	<div class="enrgcut"><span class="entitle">准考证打印</span><a href="<?php echo $CATEGORYS['421']['url'];?>" class="more">more</a></div>
            <ul class="ennewsul">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=879c601a72fb4cd022c56fcd1df913e9&action=lists&catid=421&order=id+DESC&num=6&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'421','order'=>'id DESC','limit'=>'6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>"

  target=_blank><?php echo str_cut(trim($r[title]),'50','');?></a></li>
                 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="btline"></div>
        <div class="rgdvty rgmg">
        	<div class="enrgcut"><span class="entitle">成绩查询</span><a href="<?php echo $CATEGORYS['422']['url'];?>" target="_blank" class="more">more</a></div>
            <ul class="ennewsul">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b425bdb569f74e7ea5e4a55c5cb0a336&action=lists&catid=422&order=id+DESC&num=6&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'422','order'=>'id DESC','limit'=>'6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>"

  target=_blank><?php echo str_cut(trim($r[title]),'48','');?></a></li>
                 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="rgdvty">
        	<div class="enrgcut"><span class="entitle">证书领取</span><a href="<?php echo $CATEGORYS['423']['url'];?>" target="_blank" class="more">more</a></div>
            <ul class="ennewsul">
            	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fd7e9196453a1153215be6372e847189&action=lists&catid=423&order=id+DESC&num=6&start=0&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'423','order'=>'id DESC','limit'=>'6',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>"

  target=_blank><?php echo str_cut(trim($r[title]),'48','');?></a></li>
                 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="btline"></div>
        
        <!-- 综合类-->
        <div class="enclass">
        	<div class="enrgcut enpre"><span class="entitle">综合类</span><span class="flqh" id="hotnewsqha"><a href="<?php echo $CATEGORYS['167']['url'];?>" class="selected">资料辅导</a><a href="<?php echo $CATEGORYS['168']['url'];?>">历年真题</a><a href="<?php echo $CATEGORYS['169']['url'];?>">模拟题</a><a href="<?php echo $CATEGORYS['428']['url'];?>">备考技巧</a></span></div>
            <div class="classty">
            	<div class="listlf" id="hotnewsqhdv">
                	<ul class="ennewsul">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ad7b50fb5c4e3e6bd1a3848ef0b13814&action=lists&catid=167&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'167','order'=>'id DESC',)).'ad7b50fb5c4e3e6bd1a3848ef0b13814');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'167','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=62d2d1881f679105594d5f41e17e872b&action=lists&catid=168&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'168','order'=>'id DESC',)).'62d2d1881f679105594d5f41e17e872b');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'168','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d43fed850df273b974a3c8d32aaf3346&action=lists&catid=169&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'169','order'=>'id DESC',)).'d43fed850df273b974a3c8d32aaf3346');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'169','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=968da567aaec7db67671bc9ad09d2d3a&action=lists&catid=428&order=id+DESC&num=6&start=1&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'428','order'=>'id DESC',)).'968da567aaec7db67671bc9ad09d2d3a');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'428','order'=>'id DESC','limit'=>'1,6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
                <?php $catid=167; //历年真题?>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dc1eda3f4ab89407ac0868573843b7c7&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <div class="picrg">
                	<a href="<?php echo $r['url'];?>"><img src="<?php echo thumb($r['thumb'],199,149);?>" width="199" /></a><p><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></p>
                </div>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <div class="clear"></div>
            </div>
        </div>
        <div class="btline"></div>
        
        <!--理工类-->
        <div class="enclass">
        	<div class="enrgcut enpre"><span class="entitle">理工类</span><span class="flqh" id="lglA"><a href="<?php echo $CATEGORYS['159']['url'];?>" class="selected">资料辅导</a><a href="<?php echo $CATEGORYS['160']['url'];?>">历年真题</a><a href="<?php echo $CATEGORYS['161']['url'];?>">模拟题</a><a href="<?php echo $CATEGORYS['154']['url'];?>">备考技巧</a></span></div>
            <div class="classty">
            	<div class="listlf" id="lglDIV">
                	<ul class="ennewsul">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=79abf0df40d59e4526392a222a48602f&action=lists&catid=159&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'159','order'=>'id DESC',)).'79abf0df40d59e4526392a222a48602f');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'159','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=ea0e5b9b317302c3e7b3a4d8bed12110&action=lists&catid=160&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'160','order'=>'id DESC',)).'ea0e5b9b317302c3e7b3a4d8bed12110');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'160','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=015531fb8bc8c46a78812294056141ea&action=lists&catid=161&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'161','order'=>'id DESC',)).'015531fb8bc8c46a78812294056141ea');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'161','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=664de24d98bbbba641b3300ba39031d3&action=lists&catid=154&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'154','order'=>'id DESC',)).'664de24d98bbbba641b3300ba39031d3');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'154','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
                <?php $catid=159; //历年真题?>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dc1eda3f4ab89407ac0868573843b7c7&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <div class="picrg">
                	<a href="<?php echo $r['url'];?>"><img src="<?php echo thumb($r['thumb'],199,149);?>" width="199" /></a><p><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></p>
                </div>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <div class="clear"></div>
            </div>
        </div>
        <div class="btline"></div>
        
        <!--卫生类-->
        <div class="enclass">
        	<div class="enrgcut enpre"><span class="entitle">卫生类</span><span class="flqh" id="wslA"><a href="<?php echo $CATEGORYS['163']['url'];?>" class="selected">资料辅导</a><a href="<?php echo $CATEGORYS['164']['url'];?>">历年真题</a><a href="<?php echo $CATEGORYS['165']['url'];?>">模拟题</a><a href="<?php echo $CATEGORYS['427']['url'];?>">考试心得</a></span></div>
            <div class="classty">
            	<div class="listlf" id="wslDIV">
                	<ul class="ennewsul">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bb52676ae1e627793df20ffa0bf3f417&action=lists&catid=163&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'163','order'=>'id DESC',)).'bb52676ae1e627793df20ffa0bf3f417');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'163','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dbbcd8f07a172a29e0e9551aa69c2041&action=lists&catid=164&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'164','order'=>'id DESC',)).'dbbcd8f07a172a29e0e9551aa69c2041');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'164','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7a2dee5df6daf26ccb98c90505e76d5e&action=lists&catid=165&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'165','order'=>'id DESC',)).'7a2dee5df6daf26ccb98c90505e76d5e');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'165','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=bf0f4cac81b405038c7d1a8c79d55774&action=lists&catid=427&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'427','order'=>'id DESC',)).'bf0f4cac81b405038c7d1a8c79d55774');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'427','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
                <?php $catid=163; //历年真题?>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dc1eda3f4ab89407ac0868573843b7c7&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <div class="picrg">
                	<a href="<?php echo $r['url'];?>"><img src="<?php echo thumb($r['thumb'],199,149);?>" width="199" /></a><p><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></p>
                </div>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <div class="clear"></div>
            </div>
        </div>
        <div class="btline"></div>
        
        <!--解题技巧-->
        <div class="enclass">
        	<div class="enrgcut enpre"><span class="entitle">解题技巧</span><span class="flqh" id="jtjqA"><a href="<?php echo $CATEGORYS['147']['url'];?>" class="selected">词汇选项</a><a href="<?php echo $CATEGORYS['150']['url'];?>">阅读理解</a><a href="<?php echo $CATEGORYS['149']['url'];?>">概括大意与完成句子</a><a href="<?php echo $CATEGORYS['148']['url'];?>">阅读判断</a></span></div>
            <div class="classty">
            	<div class="listlf" id="jtjqDIV">
                	<ul class="ennewsul">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=5c78ba9b6c9e858bd45cf57ad04a1c26&action=lists&catid=147&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'147','order'=>'id DESC',)).'5c78ba9b6c9e858bd45cf57ad04a1c26');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'147','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=36b53ca9f96cb24993591145f3eba19c&action=lists&catid=150&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'150','order'=>'id DESC',)).'36b53ca9f96cb24993591145f3eba19c');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'150','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b5814d35efd5d7326de43beaf3b6da39&action=lists&catid=149&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'149','order'=>'id DESC',)).'b5814d35efd5d7326de43beaf3b6da39');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'149','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                    <ul class="ennewsul" style="display:none;">
                        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=29f5a11986e45cb95b763b2b65d4a263&action=lists&catid=148&order=id+DESC&num=6&start=0&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>'148','order'=>'id DESC',)).'29f5a11986e45cb95b763b2b65d4a263');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'148','order'=>'id DESC','limit'=>'6',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
						<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target=_blank><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                 		<?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    </ul>
                </div>
                <?php $catid=147; //历年真题?>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=dc1eda3f4ab89407ac0868573843b7c7&action=lists&catid=%24catid&order=id+DESC&num=1&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'id DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <div class="picrg">
                	<a href="<?php echo $r['url'];?>"><img src="<?php echo thumb($r['thumb'],199,149);?>" width="199" /></a><p><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank" ><?php echo str_cut(trim($r[title]),'44','');?></a></p>
                </div>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <div class="clear"></div>
            </div>
        </div>
        
    </div>
    
    <div class="clear"></div>
</div>

<?php include template("content","rsks_bottom"); ?>
</body>
</html>
