<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/jsj/css/computer.css?xg=0123" />
<style type="text/css">
.cptp{ border:1px #d9d9d9 solid;}
.cptp .cpist{ height:30px; border-bottom:1px #d9d9d9 solid; line-height:30px; color:#999999;}
.cptp .cpist a{ display:inline-block; margin:0 15px; color:#1e82ac;}
.cptp .cpist div.amore{ background-image:url(/statics/jsj/images/computertyicon.png); background-repeat:no-repeat; background-position:-450px -408px; padding-left:15px; margin:0 0 0 10px; position:relative; display:inline;line-height:30px;}
.cptp .cpist a.gdzx{ background-image:url(/statics/jsj/images/computertyicon.png); background-repeat:no-repeat; background-position:-436px -448px; width:64px; height:19px; float:left; margin-top:6px;}
.cptp .cpist div.amore div{ position:absolute; right:0px; top:15px; width:280px; background:#ffffff; border:1px #d9d9d9 solid; padding:6px 0 0 0; display:none; z-index:9;}
.cptp .cpist div.amore div a{ width:80px; text-align:center; background:#f9f9f9; height:24px; line-height:24px; margin:0 5px 8px 7px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
.cptp .cpist div.amore div.dvtwo{ width:160px;}
.cptp .cpist div.amore div.dvtwo a{ width:65px;}
.dtl{ text-align:center;}
.personelcontent{ overflow:hidden;}
.personelcontent .contentleft{ width:695px; float:left;}
.personelcontent .contentleft .zkaoxx{ border:1px #cccccc solid; height:402px;}
.personelcontent .contentleft .zkaoxx .xxcut{ display:block; height:45px; border-bottom:1px #cccccc solid; background:url(images/xxcutbg.jpg) repeat-x; line-height:25px;}
.personelcontent .contentleft .zkaoxx .xxcut b{ display:inline-block; height:35px; font-size:16px; font-weight:bold; color:#ffffff; padding-left:16px; line-height:35px; font-family:微软雅黑; margin:10px 15px 0 14px;}
.personelcontent .contentleft .zkaoxx .xxcut b.b1{  width:203px;  background:url(images/fudao_bg.jpg) no-repeat;}
.personelcontent .contentleft .zkaoxx .xxcut b.b2{ width:187px; background:url(images/fudao_bg.jpg) no-repeat bottom; margin:10px 190px 0 14px;}
.personelcontent .contentleft .zkaoxx .xxcut a{ margin:0 5px; font-size:12px;}
.personelcontent .contentleft .zkaoxx .qhc{ width:330px; float:left; margin:8px 5px 8px 8px; display:inline;}
.personelcontent .contentleft .zkaoxx .qhc .spspan{ display:block; height:28px; background:#f2f2f2; padding:6px 0 0 15px; position:relative;}
.personelcontent .contentleft .zkaoxx .qhc .spspan a{ display:inline-block;height:26px; line-height:26px; text-align:center; background:#dddddd; font-family:微软雅黑; margin-right:10px;}
.personelcontent .contentleft .zkaoxx .qhc .spspan a.morea{ width:auto; height:auto; line-height:34px; background:none; font-family:宋体; margin:0px; position:absolute; right:10px; top:0px; font-size:12px;}
.personelcontent .contentleft .zkaoxx .qhc .spspan a:hover{ text-decoration:none;}
.personelcontent .contentleft .zkaoxx .qhc .spspan a.selected{ background:#ffffff; border-left:1px #dddddd solid; border-right:1px #dddddd solid; border-top:2px #dddddd solid; color:#cd171c; padding:0 15px;}
.personelul{ display:block; margin-left:8px; margin-top:10px;}
.personelul li{ background:url(/images/icon.jpg) no-repeat left center; padding-left:10px; line-height:24px; position:relative;}
.personelul li span{ position:absolute; right:0px; top:0px; line-height:24px; color:#999999;}
.functionfoot{ padding:15px 0; text-align:center; border-top:1px #bdbdbd solid; margin-top:10px; color:#454545; font-size:12px;}
.functionfoot p{ line-height:20px;}
</style>
<script type="text/javascript">
function hftb(){
  window.open("http://item.taobao.com/item.htm?spm=a1z10.1.w6842337-6518291215.31.Q60c6b&id=37117006912","_blank");
}
</script>
</head>

<body>
<div class="computerheaderbg">
	<div class="computertycenter">
    	<div class="headertop"><span class="sprg"><a href="/">□网站首页</a><a href="#">□设为首页</a><a href="#">□收藏本站</a></span></div>
        <div class="headerlogo"><span class="logo"><img src="/statics/jsj/images/rslogo.gif" /></span></div>
        <div class="headermenu">
        	<ul id="navmenu">
            	<li><a href="/">首页</a></li>
                <li><a href="/jsj/">职称计算机</a></li>
                <li><a href="/jsj/ksdt/bktz/">报考通知</a></li>
                <li><a href="/jsj/ksdt/zkz/">准考证打印</a></li>
                <li><a href="/jsj/mnst/mnt/">模拟考试</a></li>
                <li><a href="/jsj/lnzt/">历年真题</a></li>
                <li><a href="/jsj/jqxd/">技巧心得</a></li>
                <li><a href="/En/">职称英语</a></li>
            </ul>
        </div>
    </div>
</div>

<!-- center -->
<div class="computertycenter">

	<?php include template("content","jsjseo_top"); ?>

    <div class="computerctone computertymg twohg">
    	<div class="computeroneleft">
        	<div class="hdppic"><img src="/statics/jsj/images/hdppic1.jpg" /></div>
            <div class="ksjm computertymg dfzdvbk ">
            	<span class="dfzcut">报考指南</span>
                <div class="ymrgbkzn computertymg dfzbkzn">

                   <a href="/jsj/xszd/#kaoshijianjie" target="_blank">考试简介</a><a href="/jsj/xszd/#baokaotiaojian" target="_blank">报考条件</a><a href="/jsj/xszd/#baomingshijian" target="_blank">报名时间</a>

                    <a href="/jsj/xszd/" target="_blank">报考地点</a><a href="/jsj/xszd/" target="_blank">考试科目</a><a href="/jsj/xszd/#kaoshishijian" target="_blank">考试时间</a>

                    <a href="/jsj/xszd/#kaoshidagang" target="_blank">考试大纲</a><a href="/jsj/xszd/" target="_blank">考试教材</a><a href="/jsj/xszd/" target="_blank">考试形式</a>

                    <a href="/jsj/xszd/#chengjichaxun" target="_blank">成绩查询</a><a href="/jsj/xszd/#hegebiaozhun" target="_blank">合格标准</a><a href="http://www.egbroad.com/dialog_2.htm?arg=cdbroadcom&amp;style=2&amp;kflist=on&amp;kf=sl864,ycy875,zhoucl,fanxuemei,yushunlai,zhangjing,lijanq,lilinglin,litingting,zhouq835,hr869,lijiao867,zhangyu,tanggl,yangjiao,linj&amp;zdkf_type=1&amp;language=cn&amp;charset=gbk&amp;lytype=0&amp;referer=http%3A%2F%2Fwww.kaozc.com%2Fjsj%2Fxszd%2F&amp;keyword=http%3A//www.kaozc.com/&amp;tfrom=1&amp;tpl=crystal_blue&amp;timeStamp=1369359259140" target="_blank">报考答疑</a>

                </div>
            </div>
        </div>
        
        <div class="computeronecenter">
        	<div class="classnews dfzbkyc">
                <span class="newstitle "><font>考试动态：</font><?php $catids = '185,186,187,188,196,197'; //考试动态?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=716594810b10e30d7606ca4a379c8801&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+catid+in%28%24catids%29+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and catid in($catids) and  ( $condition    )  order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></span>
                <ul class="newsul">
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=ebd9466203259affde05caef78a6b737&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+catid+in%28%24catids%29+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=1&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and catid in($catids) and  ( $condition    )  order by id desc LIMIT 1,4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?> </a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
               <span class="newstitle "><font>报考指南：</font><?php $catids = '184'; //报考指南?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=716594810b10e30d7606ca4a379c8801&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+catid+in%28%24catids%29+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and catid in($catids) and  ( $condition    )  order by id desc LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></span>
                <ul class="newsul">
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=ebd9466203259affde05caef78a6b737&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+catid+in%28%24catids%29+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=1&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and catid in($catids) and  ( $condition    )  order by id desc LIMIT 1,4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?> </a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <span class="newstitle "><font>考试技巧 ：</font><?php $catids = $CATEGORYS[192]['arrchildid'];?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=499a9de0d23fbbbf26bf9f30b6e5b738&sql=+SELECT+t1.id%2Ct1.style%2Ct1.url%2Ct1.title%2Ct1.description%2Ct1.updatetime%2Ct1.%60status%60%0AFROM+%60v9_news%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28id%29+FROM+%60v9_news%60+%29-%28SELECT+MIN%28id%29+FROM+%60v9_news%60+%29%29%2B%28SELECT+MIN%28id%29+FROM+%60v9_news%60%29%29+AS+id%29+AS+t2+%0AWHERE+t1.id+%3E%3D+t2.id++and+t1.%60status%60%3D99++and+t1.%60inputtime%60+%3E+UNIX_TIMESTAMP%28%272013-01-01%27%29++and++catid+in+%28%24catids%29%0AORDER+BY++t1.id+&cache=0&return=data&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query(" SELECT t1.id,t1.style,t1.url,t1.title,t1.description,t1.updatetime,t1.`status`
FROM `v9_news` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `v9_news` )-(SELECT MIN(id) FROM `v9_news` ))+(SELECT MIN(id) FROM `v9_news`)) AS id) AS t2 
WHERE t1.id >= t2.id  and t1.`status`=99  and t1.`inputtime` > UNIX_TIMESTAMP('2013-01-01')  and  catid in ($catids)
ORDER BY  t1.id  LIMIT 1");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                <?php $n=1; if(is_array($data)) foreach($data AS $k => $val) { ?>
 <a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></span>
                <ul class="newsul">
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=7b98ff83d8abaa4d051ca04f879f8bbc&sql=+SELECT+t1.id%2Ct1.style%2Ct1.url%2Ct1.title%2Ct1.description%2Ct1.updatetime%2Ct1.%60status%60%0AFROM+%60v9_news%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28id%29+FROM+%60v9_news%60+%29-%28SELECT+MIN%28id%29+FROM+%60v9_news%60+%29%29%2B%28SELECT+MIN%28id%29+FROM+%60v9_news%60%29%29+AS+id%29+AS+t2+%0AWHERE+t1.id+%3E%3D+t2.id++and+t1.%60status%60%3D99++and+t1.%60inputtime%60+%3E+UNIX_TIMESTAMP%28%272013-01-01%27%29++and++catid+in+%28%24catids%29%0AORDER+BY++t1.id+&cache=0&return=data&start=1&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query(" SELECT t1.id,t1.style,t1.url,t1.title,t1.description,t1.updatetime,t1.`status`
FROM `v9_news` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `v9_news` )-(SELECT MIN(id) FROM `v9_news` ))+(SELECT MIN(id) FROM `v9_news`)) AS id) AS t2 
WHERE t1.id >= t2.id  and t1.`status`=99  and t1.`inputtime` > UNIX_TIMESTAMP('2013-01-01')  and  catid in ($catids)
ORDER BY  t1.id  LIMIT 1,4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                <?php $n=1; if(is_array($data)) foreach($data AS $k => $val) { ?>
                    <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?> </a></li><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
            <div class="dfzbnewsct">
            	<span class="dfzbnewscut" id="zxnewsA"><a class="selected">报考通知</a><a>报名时间</a><a>报名入口</a><a>考试时间</a></span>
            </div>
            <div id="zxnewsDIV">
                <ul class="newsultylist">
                <?php $C_title = "title like '%报考通知%'"; //报考通知?>
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e39acfebd239b4f68f0fba1da2029a10&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+%24C_title+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and $C_title and  ( $condition    )  order by id desc LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'60','');?></a><span>[<?php echo date('m-d', $val['updatetime']);?>]</span></li>
                    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul class="newsultylist" style="display:none;">
                	 <?php $C_title = "title like '%报名时间%'"; //报名时间?>
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e39acfebd239b4f68f0fba1da2029a10&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+%24C_title+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and $C_title and  ( $condition    )  order by id desc LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'60','');?></a><span>[<?php echo date('m-d', $val['updatetime']);?>]</span></li>
                    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul class="newsultylist" style="display:none;">
                	 <?php $C_title = "title like '%报名入口%'"; //报名入口?>
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e39acfebd239b4f68f0fba1da2029a10&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+%24C_title+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and $C_title and  ( $condition    )  order by id desc LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'60','');?></a><span>[<?php echo date('m-d', $val['updatetime']);?>]</span></li>
                    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul class="newsultylist" style="display:none;">
                	 <?php $C_title = "title like '%考试时间%'"; //考试时间?>
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=e39acfebd239b4f68f0fba1da2029a10&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+%24C_title+and++%28+%24condition++++%29++order+by+id+desc&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and $C_title and  ( $condition    )  order by id desc LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'60','');?></a><span>[<?php echo date('m-d', $val['updatetime']);?>]</span></li>
                    <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
        </div>
        
        <div class="computeroneright">
        	<div class="classnews dfzdvbk">

            	<span class="dfzcut">考试提醒</span>

                <span class="kstxcut"><a href="/jsj/ksdt/bktz/">报名入口</a><a href="/jsj/ksdt/bktz/list.html?typeid=96">准考证</a><a href="/jsj/ksdt/zslq/">证书领取</a><a href="/jsj/ksdt/bktz/list.html?typeid=97">成绩查询</a></span>

                <p class="kstxp">报名时间：<?php echo $kslist['bmtime'];?></p>

               	<p class="kstxp">准考证打印时间：<?php echo $kslist['lztime'];?></p>

                <p class="kstxp">考试时间：<?php echo $kslist['kstime'];?></p>

                <p class="kstxp">考试详情：<a href="/jsj/ksdt/bktz/" target="_blank">点击进入>></a></p>

            </div>
            <div class="ksjm computertymg dfzdvbk">
            	<span class="dfzcut">热点专题</span>
                <ul class="tynewsullist hotzt">
                <?php $catids = '342'; $rand_id = rand(0,530);  //热点专题?>
                  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=c5d3bc27fd9fb84b4b5e2ebb2ab371f3&sql=SELECT+url%2Ctitle%2Cupdatetime%2Ccatid%2Ccity_id+FROM+v9_news+WHERE+status%3D99+and+catid+in%28%24catids%29+++order+by+id+desc+limit+%24rand_id%2C9--&cache=0&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT url,title,updatetime,catid,city_id FROM v9_news WHERE status=99 and catid in($catids)   order by id desc limit $rand_id,9-- LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?><?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li class="tynewsullist"><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank" ><?php echo str_cut($val['title'],'40','');?></a></li>
                   <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
       	</div>
        <div class="newsclear"></div>
    </div>
    
    <div class="computerstudycut">
    	<span class="lftitle">学习软件</span>
        <div class="rgnr"><span>产品优势</span><a href="#">3小时学习即可考试通关</a><a href="#">98%考试通过率</a><a href="#">12元助您一次取证</a></div>
    </div>
    
    <div class="computerstudynr rstymgbt">
		<div class="rstymgbt"><?php echo $diycode;?></div>
        <h2 class="h2js">2015年考试宝典职称计算机考试模拟题-全真题库，模拟真实考试操作，全国同类题库过关率最高，过万考生好评<a href="javascript:hftb()">[查看评价]</a></h2>
        <ul>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/pointer2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">PowerPoint2007</a><br>科目代码：213 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/excel2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">Excel2007</a><br>科目代码：212 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/word2007.jpg"></a><a href="javascript:hftb()" rel="nofollow">Word2007</a><br>科目代码：211 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/Internet.jpg"></a><a href="javascript:hftb()" rel="nofollow">Internet应用</a><br>科目代码：303 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/PowerPoint2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">PowerPoint2003</a><br>科目代码：207 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/Excel2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">Excel2003</a><br>科目代码：206 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/wrod2003.jpg"></a><a href="javascript:hftb()" rel="nofollow">Word2003</a><br>科目代码：205 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/xp.jpg"></a><a href="javascript:hftb()" rel="nofollow">WindowsXP</a><br>科目代码：102 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">FrontPage2003</a><br>科目代码：305 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/jswz.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山文字2005</a><br>科目代码：208 常考模块</li>

            <li><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/jsbg.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山表格2005</a><br>科目代码：209 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/jsys.jpg"></a><a href="javascript:hftb()" rel="nofollow">金山演示2005</a><br>科目代码：210 常考模块</li>

            <li class="duoa"><b></b><a href="javascript:hftb()"><img src="/statics/kaozc/images/wpsoffice.jpg"></a><a href="javascript:hftb()" rel="nofollow">WPSOffice办公组合中文字处理</a><br>科目代码：204 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">FrontPage2000</a><br>科目代码：302 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/cad.jpg"></a><a href="javascript:hftb()" rel="nofollow">AutoCAD2004</a><br>科目代码：503 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/u8.jpg"></a><a href="javascript:hftb()" rel="nofollow">用友U8</a><br>科目代码：403 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/VisualFoxPro.jpg"></a><a href="javascript:hftb()" rel="nofollow">VisualFoxPro5.0</a><br>科目代码：401 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Flash.jpg"></a><a href="javascript:hftb()" rel="nofollow">FlashMX2004动画制作</a><br>科目代码：504 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Authorware.jpg"></a><a href="javascript:hftb()" rel="nofollow">Authorware7.0</a><br>科目代码：505 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Frontpage2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">Project2000项目管理</a><br>科目代码：901 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/Access2000.jpg"></a><a href="javascript:hftb()" rel="nofollow">Access2000</a><br>科目代码：402 常考模块</li>

            <li class="duoa"><a href="javascript:hftb()"><img src="/statics/kaozc/images/ps.jpg"></a><a href="javascript:hftb()" rel="nofollow">PhotoshopCS4图像处理</a><br>科目代码：506 常考模块</li>

            <li><a href="javascript:hftb()"><img src="/statics/kaozc/images/u8.jpg"></a><a href="javascript:hftb()" rel="nofollow">用友T3会计信息化软件</a><br>科目代码：404 常考模块</li>

        

        </ul>

        <div class="newsclear"></div>

   	</div>
    
    <!-- 广告位 -->
    <div class="computerggw"><a href="#"><img src="/statics/jsj/images/g_g_2.jpg"  /></a></div>
    
    <div class="personelcontent">
    	<!-- left部分-->
    	<div class="contentleft">
        	<div class="zkaoxx">
            	<span class="xxcut"><b class="b1">北京市招考信息</b></span>
                <div class="qhc">
                	<span class="spspan"><a href="javascript:;" class="selected">职业资格</a><a href="<?php echo $CATEGORYS['11']['url'];?>" class="morea">更多>></a></span>
                    <ul class="personelul">
                       <?php $catids = $CATEGORYS[11]['arrchildid'];?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=c7afd172041111c8f55476cff862fe6e&sql=+SELECT+t1.id%2Ct1.style%2Ct1.url%2Ct1.title%2Ct1.description%2Ct1.updatetime%2Ct1.%60status%60%0AFROM+%60v9_news%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28id%29+FROM+%60v9_news%60+%29-%28SELECT+MIN%28id%29+FROM+%60v9_news%60+%29%29%2B%28SELECT+MIN%28id%29+FROM+%60v9_news%60%29%29+AS+id%29+AS+t2+%0AWHERE+t1.id+%3E%3D+t2.id++and+t1.%60status%60%3D99++and+t1.%60inputtime%60+%3E+UNIX_TIMESTAMP%28%272013-01-01%27%29++and++catid+in+%28%24catids%29%0AORDER+BY++t1.id+&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query(" SELECT t1.id,t1.style,t1.url,t1.title,t1.description,t1.updatetime,t1.`status`
FROM `v9_news` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `v9_news` )-(SELECT MIN(id) FROM `v9_news` ))+(SELECT MIN(id) FROM `v9_news`)) AS id) AS t2 
WHERE t1.id >= t2.id  and t1.`status`=99  and t1.`inputtime` > UNIX_TIMESTAMP('2013-01-01')  and  catid in ($catids)
ORDER BY  t1.id  LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                      
                <?php $n=1; if(is_array($data)) foreach($data AS $k => $r) { ?>
                <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                  </ul>
                </div>
                <div class="qhc">
                	<span class="spspan"><a href="javascript:;" class="selected">职称计算机考试</a><a href="<?php echo $CATEGORYS['10']['url'];?>" class="morea">更多>></a></span>
                    <ul class="personelul">
                       <?php $catids = $CATEGORYS[187]['arrchildid'];?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=c7afd172041111c8f55476cff862fe6e&sql=+SELECT+t1.id%2Ct1.style%2Ct1.url%2Ct1.title%2Ct1.description%2Ct1.updatetime%2Ct1.%60status%60%0AFROM+%60v9_news%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28id%29+FROM+%60v9_news%60+%29-%28SELECT+MIN%28id%29+FROM+%60v9_news%60+%29%29%2B%28SELECT+MIN%28id%29+FROM+%60v9_news%60%29%29+AS+id%29+AS+t2+%0AWHERE+t1.id+%3E%3D+t2.id++and+t1.%60status%60%3D99++and+t1.%60inputtime%60+%3E+UNIX_TIMESTAMP%28%272013-01-01%27%29++and++catid+in+%28%24catids%29%0AORDER+BY++t1.id+&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query(" SELECT t1.id,t1.style,t1.url,t1.title,t1.description,t1.updatetime,t1.`status`
FROM `v9_news` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `v9_news` )-(SELECT MIN(id) FROM `v9_news` ))+(SELECT MIN(id) FROM `v9_news`)) AS id) AS t2 
WHERE t1.id >= t2.id  and t1.`status`=99  and t1.`inputtime` > UNIX_TIMESTAMP('2013-01-01')  and  catid in ($catids)
ORDER BY  t1.id  LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                <?php $n=1; if(is_array($data)) foreach($data AS $k => $r) { ?>
                <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                  </ul>
                </div>
                <div class="personelsd"></div>
                <div class="qhc">
                	<span class="spspan"><a href="javascript:;" class="selected">职称英语</a><a href="<?php echo $CATEGORYS['9']['url'];?>" class="morea">更多>></a></span>
                    <ul class="personelul">
                        <?php $catids = $CATEGORYS[9]['arrchildid'];?>
                         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=c7afd172041111c8f55476cff862fe6e&sql=+SELECT+t1.id%2Ct1.style%2Ct1.url%2Ct1.title%2Ct1.description%2Ct1.updatetime%2Ct1.%60status%60%0AFROM+%60v9_news%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28id%29+FROM+%60v9_news%60+%29-%28SELECT+MIN%28id%29+FROM+%60v9_news%60+%29%29%2B%28SELECT+MIN%28id%29+FROM+%60v9_news%60%29%29+AS+id%29+AS+t2+%0AWHERE+t1.id+%3E%3D+t2.id++and+t1.%60status%60%3D99++and+t1.%60inputtime%60+%3E+UNIX_TIMESTAMP%28%272013-01-01%27%29++and++catid+in+%28%24catids%29%0AORDER+BY++t1.id+&cache=0&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query(" SELECT t1.id,t1.style,t1.url,t1.title,t1.description,t1.updatetime,t1.`status`
FROM `v9_news` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(id) FROM `v9_news` )-(SELECT MIN(id) FROM `v9_news` ))+(SELECT MIN(id) FROM `v9_news`)) AS id) AS t2 
WHERE t1.id >= t2.id  and t1.`status`=99  and t1.`inputtime` > UNIX_TIMESTAMP('2013-01-01')  and  catid in ($catids)
ORDER BY  t1.id  LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                <?php $n=1; if(is_array($data)) foreach($data AS $k => $r) { ?>
                <li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'60','');?></a></li>
                        <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                  </ul>
                </div>
                <div class="qhc">
                	<span class="spspan"><a href="javascript:;" class="selected">其他地区考试</a></span>
                    <ul class="personelul">
                        <?php
           $i=1;
           shuffle($childCitylist);
           ?>
          <?php $n=1;if(is_array($childCitylist)) foreach($childCitylist AS $r) { ?>
                      <li><a href="<?php echo $cat_url;?><?php echo $murl;?><?php echo getCityUrl($r['pinyin']);?>.html" title="<?php echo str_replace(array('省','市','县'),'',$r['name']);?><?php echo $catname;?>考试报名时间" target="_blank"><?php echo str_replace(array('省','市','县'),'',$r['name']);?><?php echo $catname;?>考试报名时间</a></li>
           <?php
           if($i==5) break;
           $i++;
           ?>
        <?php $n++;}unset($n); ?>
                  </ul>
                </div>
            </div>
            
        </div>
        
        <div class="ksjm" style="float:right; height:402px; overflow:hidden; width:250px;">
            <span class="spancut">你问我答</span>
            
            <div id="teacheryiwen" style="height:350px; overflow:hidden;">
                <ul class="computernwwdul">
                 <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=bfee999041778482d87a2be61343a201&sql=SELECT+t1.qid%2Ct1.question%2Ct1.url%2Ct1.ip%2Ct1.catid+%0AFROM+%60v9_ask_question%60+AS+t1+JOIN+%28SELECT+ROUND%28RAND%28%29+%2A+%28%28SELECT+MAX%28qid%29+FROM+%60v9_ask_question%60%29-%28SELECT+MIN%28qid%29+FROM+%60v9_ask_question%60%29%29%2B%28SELECT+MIN%28qid%29+FROM+%60v9_ask_question%60%29%29+AS+qid%29+AS+t2+%0AWHERE+t1.qid+%3E%3D+t2.qid+and+t1.catid%3D1+%0AORDER+BY+t1.qid+&cache=0&return=data&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT t1.qid,t1.question,t1.url,t1.ip,t1.catid 
FROM `v9_ask_question` AS t1 JOIN (SELECT ROUND(RAND() * ((SELECT MAX(qid) FROM `v9_ask_question`)-(SELECT MIN(qid) FROM `v9_ask_question`))+(SELECT MIN(qid) FROM `v9_ask_question`)) AS qid) AS t2 
WHERE t1.qid >= t2.qid and t1.catid=1 
ORDER BY t1.qid  LIMIT 8");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $i=1?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><p><a href="<?php echo $val['url'];?>"><?php echo $val['question'];?></a></p><p><?php echo str_cut($val['question'],'44');?></p></li>
                   <?php $i++?>
          <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>  
                </ul>
            </div>
        </div>
        
        <div class="newsclear"></div>
    </div>
    
</div>
<?php include template("content","rsks_bottom"); ?>
<script language="javascript" src="/statics/js/jquery.min.js"></script>
<script src="/statics/jsj/js/jq_scroll.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$("#amoreone").mousemove(function(){$(this).find("div").show();});
$("#amoreone").mouseleave(function(){$(this).find("div").hide();});

$("#amoretwo").mousemove(function(){$(this).find("div").show();});
$("#amoretwo").mouseleave(function(){$(this).find("div").hide();});
});
$("#teacheryiwen").Scroll({line:1,speed:500,timer:3000});
$('#zxnewsA a').mouseover(function(){
	$(this).addClass("selected").siblings().removeClass();
	$("#zxnewsDIV > ul").eq($('#zxnewsA a').index(this)).show().siblings().hide();
});
</script>


</body>
</html>
