<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><?php
param::set_cookie('siteid',$siteid);
?>
<?php $CATEGORYS1=getcache('category_content_1','commons')?>
<?php $CATEGORYS2=getcache('category_content_2','commons')?>
<div class="body-top"  >

  <div class="expo_nav" style="width:940px;margin:0 auto;line-height:26px;height:36px;">
   <span><a href="<?php echo siteurl(1);?>" target="_blank"><b>网站首页</b></a></span>-<font color="red">职称英语</font></a>-<a href="<?php echo $CATEGORYS1['158']['url'];?>">理工类</a>-<a href="<?php echo $CATEGORYS1['162']['url'];?>">卫生类</a>-<a href="<?php echo $CATEGORYS1['10']['url'];?>">职称计算机</a>-
  <a href="<?php echo $CATEGORYS1['11']['url'];?>">职业资格</a>-<a href="<?php echo $CATEGORYS1['18']['url'];?>">金融财会</a>-<a href="<?php echo $CATEGORYS1['218']['url'];?>">建筑工程</a>-<a href="<?php echo $CATEGORYS1['217']['url'];?>">医药卫生</a>-<a href="#">帮助中心</a></div>
  
  
</div>
