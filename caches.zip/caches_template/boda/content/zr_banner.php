<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>

<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
<script type="text/javascript">
    <!-- 广告位： -->
    BAIDU_CLB_fillSlotAsync('976621','AD_976621');
    BAIDU_CLB_fillSlotAsync('976622','AD_976622');
    BAIDU_CLB_fillSlotAsync('976623','AD_976623');
	BAIDU_CLB_fillSlotAsync('976624','AD_976624');
	BAIDU_CLB_fillSlotAsync('976625','AD_976625');
	BAIDU_CLB_fillSlotAsync('976626','AD_976626');
</script>


<div class="banber1"><div class="toruibanner" id="AD_976621"></div>
    
    <div class="toruitopnewshot toruitymg">
    	<div class="newspic" id="AD_976622"></div>
        <div class="newsct">
        	<p>  <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=945439cf3b136ed6363abc0aa1f45fb1&action=position&posid=245&order=listorder+DESC&start=0&num=1\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'245','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'80','');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></p>
            <ul>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b028723bbcb35b72d1052d6ca42b0b38&action=position&posid=245&order=listorder+DESC&start=1&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'245','order'=>'listorder DESC','limit'=>'1,8',));}?><?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
            	<li><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> title="<?php echo trim($r[title]);?>" target="_blank"><?php echo str_cut(trim($r[title]),'54','');?></a></li>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </ul>
        </div>
        <div class="newsrgpc">
        	<p id="AD_976623"></p>
            <p class="wb"><a href="#" class="xlwb">新浪微博</a><a href="#" class="txwb">腾讯微博</a></p>
        </div>
        <div class="toruiclear"></div>
    </div>
    
    <div class="toruithreegg toruimgbt"><span id="AD_976624"></span><span id="AD_976625"></span><span class="mg0" id="AD_976626"></span><div class="toruiclear"></div></div>
    </div>