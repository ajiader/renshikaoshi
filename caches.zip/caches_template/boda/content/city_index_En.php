<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/en/css/zcyy_cy.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
</head>
<body onload="DigitalTime1()">
<?php include template("content","rsks_top"); ?>

<!-- center-->
<div class="zcyycenter">
		<div class="schoolsk">
    <span class="lfsk">职称英语各地考试入口</span>
    <span class="rgsk">
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
      
        <a href="<?php echo siteurl($siteid);?>/En/<?php echo $v['pinyin'];?>/" title="<?php echo replace_arr($v['name'],array('省','市'));?>职称英语考试"  target="_blank"><?php echo replace_arr($v['name'],array('省','市'));?></a>
<?php $n++;}unset($n); ?>
    </span>
    <span class="map"></span>
</div>
    	<div class="dfzquyu zcenglishtymg">
    	<table cellspacing="0" cellpadding="0" border="0">
        	<tbody>
                <tr>
                    <td width="13%" class="dfname"><?php echo citys2city($cityList['name']);?>站</td>
                    <td width="87%" class="dfnr">
                	  <?php $n=1;if(is_array($childCitylist)) foreach($childCitylist AS $v) { ?>
                        <?php if($v['pinyin']) { ?> <a href="<?php echo $CATEGORYS[$catid]['url'];?><?php echo $v['pinyin'];?>/" title="<?php echo $v['name'];?>职称英语考试网"><?php echo citys2city($v['name']);?></a><?php } ?>
                      <?php $n++;}unset($n); ?>				   
                    </td>
                </tr>
        	</tbody>
        </table>
    </div>
    
    <div class="zcyy_dfct">
    
    	<div class="zcyy_ctlf">
        
        	<div class="hdppic zcenglishtymg">
                <span class="picswitchnum">
                	<ul>
              <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7cf924a8eaebc2d65708fb41c7b9d5d3&action=position&posid=131&thumb=1&order=listorder+DESC&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('posid'=>'131','thumb'=>'1','order'=>'listorder DESC','limit'=>'5',));}?>
			    <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 
                 <li></li>
				 <?php $n++;}unset($n); ?>
				 </ul>
				 </span>
              <div class="picswitchpic">
                 <ul>
                 	<?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?> 
                    <li><a href="<?php echo $r['url'];?>" target="_blank"  title="<?php echo str_cut(trim($r[title]),'100','');?>"><img src="<?php echo thumb($r['thumb'],290, 185);?>" /></a></li>
                    <?php $n++;}unset($n); ?>		 
                 </ul>
               </div>
			  <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
            </div>
            
            <div class="zcyy_bor_ty zcenglishtymg">
            	<div class="borcut"><span class="sp1">考试心得</span><span class="sp2"><a href="<?php echo $CATEGORYS['427']['url'];?>">更多>></a></span></div>
                <ul class="zcenglishnews zcyy_ulmg">
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=48f96b4ead2bc453320a76ae82fb17a6&action=lists&catid=427&order=id+DESC&num=10\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'427','order'=>'id DESC','limit'=>'10',));}?>
					<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><a target="_blank" href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut(trim($val['title']),'44','');?></a></li>
                    <?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
            
            
            
        </div>
        
        <div class="zcyy_ctmd">
        
        	<div class="hotnews">
        		<div class="first"><span>热点</span><h2><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d993ad3281ddfe2cb5a9dd8ff5a68c31&action=position&cityid=%24topparentid&posid=289&order=listorder+DESC&num=1&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('cityid'=>$topparentid,'posid'=>'289','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $key => $r) { ?><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],40,'');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></h2></div>
                <ul>
                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=94aee141762bcbff378aa6de5a85fe84&action=position&cityid=%24topparentid&posid=289&order=listorder+DESC&num=6&start=1&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('cityid'=>$topparentid,'posid'=>'289','order'=>'listorder DESC','limit'=>'1,6',));}?> 
				     <?php $n=1; if(is_array($data)) foreach($data AS $key => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],40,'');?></a></li>
                     <?php $n++;}unset($n); ?>
				   <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <div class="line_h"></div>
          		<div class="first"><span>辅导</span><h2><?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c78a7a15a3b329b52d7ff0b06d00eb6d&action=position&cityid=%24topparentid&posid=428&order=listorder+DESC&num=1&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('cityid'=>$topparentid,'posid'=>'428','order'=>'listorder DESC','limit'=>'1',));}?><?php $n=1; if(is_array($data)) foreach($data AS $key => $r) { ?><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],40,'');?></a><?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?></h2></div>
                <ul>
                   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=7148411f33ede0d82439e52e720c5e60&action=position&cityid=%24topparentid&posid=428&order=listorder+DESC&num=8&start=1&cache=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'position')) {$data = $content_tag->position(array('cityid'=>$topparentid,'posid'=>'428','order'=>'listorder DESC','limit'=>'1,8',));}?> 
                      <?php $n=1; if(is_array($data)) foreach($data AS $key => $r) { ?>
                    <li><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo str_cut($r['title'],40,'');?></a></li>
                      <?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
                </ul>
        	</div>
            
            <div id="bkjqA" class="hotcut2">
                <a target="_blank" href="javascript:;" class="selected">最近更新</a><a target="_blank" href="<?php echo $CATEGORYS['420']['url'];?>">报考通知</a><a target="_blank" href="<?php echo $CATEGORYS['421']['url'];?>">准考证</a><a  target="_blank" href="<?php echo $CATEGORYS['422']['url'];?>">成绩查询</a>
            </div>
            <div id="hotDIV">
            	<ul class="zcenglishnews font14 pd1">
               <?php
                $catids = $CATEGORYS['419']['arrchildid'];
                $data = city_news_list($siteid,$cityList,$catids,10);
               ?>
               <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    <li><a  href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'60','');?><span><?php echo date('m-d',$val['updatetime']);?></span></a></li>
               <?php $n++;}unset($n); ?>
                </ul>
                <ul class="zcenglishnews font14 pd1" style="display:none;">
                   	<?php $data = city_news_list($siteid,$cityList,"420",10);?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],'60','');?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul class="zcenglishnews font14 pd1" style="display:none;">
                   	<?php $data = city_news_list($siteid,$cityList,"421",10);?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],'60','');?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul class="zcenglishnews font14 pd1" style="display:none;">
                   	<?php $data = city_news_list($siteid,$cityList,"422",10);?>
						<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	<li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],'60','');?></a><span><?php echo date('m/d',$val['updatetime']);?></span></li>
						<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
            
            
        
        </div>
        
        <div class="zcyy_ctrg">
        
        	<div class="zcyy_bor_ty zcenglishtymg">
            	<div class="borcut"><span class="sp1">新手指导</span></div>
                <div class="msf_xszd">
            	   <a href="http://www.kaozc.com/kaoshi-154-110018-1.html">考试简介</a><a href="http://www.kaozc.com/kaoshi-154-110027-1.html">报名时间</a><a href="http://www.kaozc.com/kaoshi-154-110026-1.html">考试时间</a>
                   <a href="http://www.kaozc.com/kaoshi-154-113623-1.html">考试题型</a><a href="http://www.kaozc.com/kaoshi-154-110029-1.html">考试内容</a><a href="http://www.kaozc.com/tg/zcyy/zz/#yongshu">考试用书</a>
                   <a href="http://www.kaozc.com/kaoshi-154-89297-1.html">免考规定</a><a href="http://www.kaozc.com/En/ksdt/cjcx/">成绩查询</a><a href="http://www.kaozc.com/kaoshi-154-110296-1.html">成绩有效期</a>
                   <a href="http://www.kaozc.com/kaoshi-154-113624-1.html">考试级别</a><a href="http://www.kaozc.com/kaoshi-154-110277-1.html">合格标准</a><a href="http://www.kaozc.com/En/ksdt/zslq/">证书领取</a>

                </div>
            </div>
            
            <div class="ksjl">
            	<span class="tl">距离2015年全国职称英语考试</span>
                <span class="djs">还有<font id="LiveClock1"></font>天</span>
                <p>考试时间：<?php echo $kslist['kstime'];?></p>
            </div>
            
            <div class="zcyy_bor_ty zcenglishtymg">
            	<div class="borcut"><span class="sp1">职称考评</span><span class="sp2"><a href="<?php echo $CATEGORYS['280']['url'];?>">更多>></a></span></div>
                <ul class="zcenglishnews zcyy_ulmg">
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fcbef05b6eb5b2b0e045d96e01633820&action=lists&catid=280&order=id+DESC&num=6&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'280','order'=>'id DESC','limit'=>'6',));}?>						          
					<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>                    
					<li><a target="_blank" href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'60','');?></a></li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
            
            
            
        </div>
        
        <div class="clear"></div>
    </div>
    
    <div class="zcenglishtymg" id="538660"></div>
    
    <div class="dfztitlety">考试辅导<span><a href="<?php echo $CATEGORYS['179']['url'];?>">资料辅导</a>/<a href="<?php echo $CATEGORYS['933']['url'];?>">历年真题</a>/<a href="<?php echo $CATEGORYS['934']['url'];?>">模拟题</a></span></div>
    
    <div class="dfzfudao">
    	<div class="fudaodv">
        	<div class="dvcut">资料辅导<span id="fudaoaone"><a target="_blank" href="<?php echo $CATEGORYS['159']['url'];?>">理工类</a><a target="_blank" href="<?php echo $CATEGORYS['167']['url'];?>" class="selected">综合类</a><a target="_blank" href="<?php echo $CATEGORYS['163']['url'];?>">卫生类</a></span></div>
            <div id="fudaonrone" class="fudaonr">
            	<ul class="zcenglishnews">
               	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=123ed7fac996907fbe89078f73f6db99&action=lists&catid=159&order=id+DESC&num=7&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'159','order'=>'id DESC','limit'=>'7',));}?>						          
					<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>                    
					<li><a target="_blank" href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'60','');?></a></li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul style="display:none;" class="zcenglishnews">
               	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c2a475d8cb1c746882413bf4c1b17fd7&action=lists&catid=167&order=id+DESC&num=7&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'167','order'=>'id DESC','limit'=>'7',));}?>						          
					<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>                    
					<li><a target="_blank" href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'60','');?></a></li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
                <ul style="display:none" class="zcenglishnews">
               	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a0ce152d48fef771dfdef8189e488b64&action=lists&catid=163&order=id+DESC&num=7&start=0\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'163','order'=>'id DESC','limit'=>'7',));}?>						          
					<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>                    
					<li><a target="_blank" href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>"><?php echo str_cut($val['title'],'60','');?></a></li>
					<?php $n++;}unset($n); ?>
					<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
        </div>
        
        <div class="fudaodv mgfd">
        	<div class="dvcut">历年真题<span id="fudaoatwo"><a class="selected" target="_blank" href="<?php echo $CATEGORYS['933']['url'];?>">理工类</a><a target="_blank" href="<?php echo $CATEGORYS['933']['url'];?>">综合类</a><a target="_blank" href="<?php echo $CATEGORYS['933']['url'];?>">卫生类</a></span></div>
            <div id="fudaonrtwo" class="fudaonr">
            	<ul class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a8e4ff44e349c9fc48d0248d91340f16&action=lists&catid=160&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'160','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>                </ul>
                					<ul style="display:none;" class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=3fc47b279b8e9b13e6e5a5474f7239b3&action=lists&catid=168&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'168','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>     
                </ul>
                <ul style="display:none" class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=430103c686d2ce6e3280db3d14df1731&action=lists&catid=164&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'164','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>   
                </ul>
            </div>
        </div>
        
        <div class="fudaodv">
        	<div class="dvcut">模拟题<span id="fudaoathree"><a class="selected" target="_blank" href="<?php echo $CATEGORYS['934']['url'];?>">理工类</a><a target="_blank" href="<?php echo $CATEGORYS['934']['url'];?>">综合类</a><a target="_blank" href="<?php echo $CATEGORYS['934']['url'];?>">卫生类</a></span></div>
            <div id="fudaonrthree" class="fudaonr">
            	<ul class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=113f32d54fbb6771f225e8f4cb6c34bb&action=lists&catid=934&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'934','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>                </ul>
                <ul style="display:none;" class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c58761dc101d25eb5e00a07c2754ec69&action=lists&catid=169&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'169','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>     
                </ul>
                <ul style="display:none" class="zcenglishnews">
                		          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=10b9daf60c5906fc27b42e91c88f803f&action=lists&where=%24where&catid=165&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('where'=>$where,'catid'=>'165','order'=>'id DESC','limit'=>'7',));}?>
						          <?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
                    	           <li><a href="<?php echo $val['url'];?>" title="<?php echo $val['title'];?>" target="_blank"><?php echo str_cut($val['title'],60);?></a></li>
						          <?php $n++;}unset($n); ?>
						          <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>   
                </ul>
            </div>
        </div>
        
    </div>

</div>

<!-- footer-->
<?php include template("content","rsks_bottom"); ?>
<script language="javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<script language="javascript" src="/statics/renshikaoshi/js/pictab.js"></script>
<script language="javascript" src="/statics/renshikaoshi/js/timedjs.js"></script>

<script language="javascript">
$(document).ready(function(){
	$('#ksfdA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#ksfdDIV > ul").eq($('#ksfdA a').index(this)).show().siblings().hide();
	});
	
	$('#bkjqA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#hotDIV > ul").eq($('#bkjqA a').index(this)).show().siblings().hide();
	});
	
	$('#ksstA a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#ksstDIV > ul").eq($('#ksstA a').index(this)).show().siblings().hide();
	});
	
	$('#fudaoaone a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#fudaonrone > ul").eq($('#fudaoaone a').index(this)).show().siblings().hide();
	});
	$('#fudaoatwo a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#fudaonrtwo > ul").eq($('#fudaoatwo a').index(this)).show().siblings().hide();
	});
	$('#fudaoathree a').mouseover(function(){
		$(this).addClass("selected").siblings().removeClass();
		$("#fudaonrthree > ul").eq($('#fudaoathree a').index(this)).show().siblings().hide();
	});
	$("#zcenglishmenu li").mousemove(function(){$(this).find("div").show();});
	$("#zcenglishmenu li").mouseleave(function(){$(this).find("div").hide();});
});
</script>
</body>
</html>
