<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link href="<?php echo CSS_PATH;?>z_reset.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH;?>z_default_blue.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH;?>z_share.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />

<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css" />
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.sgallery.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>search_common.js"></script>
</head>
<body>
</script>
<?php include template("content","rsks_top"); ?>
<!--main-->
<div class="main">
	<div class="col-left">
    <div class="expo_nav_ad">
      <script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>
        <?php 
if ($siteid == 2):
?>
<!-- 广告位：公务员内页-顶部 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("538687");</script>
<?php
else:
?>
<!-- 广告位：职称类-内页顶部banner1 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("538603");</script>
<?php
endif;
?>
    </div>
    	<div class="crumbs"><a href="<?php echo siteurl($siteid);?>">首页</a><span> > </span><?php echo catpos($catid);?> 标签：<font color="red"><?php echo $tag;?></font> 总共有 <?php echo $total;?> 条记录</div>
        <ul class="list lh24 f14">
<?php $n=1;if(is_array($datas)) foreach($datas AS $r) { ?>
	<li><span class="rt"><?php echo date('Y-m-d',$r[inputtime]);?></span>·<a href="<?php echo $r['url'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo $r['title'];?></a></li>
	<?php if($n%5==0) { ?><li class="bk20 hr"></li><?php } ?>
<?php $n++;}unset($n); ?>
        </ul>
        <div id="pages" class="text-c"><?php echo $pages;?></div>
  </div>
    <div class="col-auto" style="float:right">
        <div class="box">
            <h5 class="title-2">频道总排行</h5>
           <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0ad40a45ad075d8f47798a231e25aec2&action=hits&catid=%24catid&num=10&order=views+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>$catid,'order'=>'views DESC',)).'0ad40a45ad075d8f47798a231e25aec2');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>$catid,'order'=>'views DESC','limit'=>'10',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
            <ul class="content digg">
				<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
					<li><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo str_cut($r[title],50,'');?></a></li>
				<?php $n++;}unset($n); ?>
            </ul>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </div>
        <div class="bk10"></div>
     <?php 
if ($siteid == 2):
?>   <div class="ad_pic">
<!-- 广告位：公务员内页-右侧 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("538694");</script>
</div>

 <div class="ad_pic">
<!-- 广告位：内页-右侧位02 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("568247");</script>
</div>
<?php
else:
?>
<div class="ad_pic">
<!-- 广告位：职称类-内页右侧位 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("538605");</script>
</div>

<div class="ad_pic">
<!-- 广告位：内页右侧位02 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("568252");</script>
</div>
<?php
endif;
?>
      <div class="box">
          <h5 class="title-2">频道本月排行</h5>
     
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2caa10e576ba663010144233732308cd&action=hits&catid=%24catid&num=8&order=monthviews+DESC&cache=3600\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('catid'=>$catid,'order'=>'monthviews DESC',)).'2caa10e576ba663010144233732308cd');if(!$data = tpl_cache($tag_cache_name,3600)){$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'hits')) {$data = $content_tag->hits(array('catid'=>$catid,'order'=>'monthviews DESC','limit'=>'8',));}if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
            <ul class="content rank">
				<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
				<li><span><?php echo number_format($r[monthviews]);?></span><a href="<?php echo $r['url'];?>"<?php echo title_style($r[style]);?> class="title" title="<?php echo $r['title'];?>"><?php echo str_cut($r[title],56,'...');?></a></li>
				<?php $n++;}unset($n); ?>
            </ul>
            <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </div>
        
    </div>
</div>
<?php include template("content","rsks_bottom"); ?>
 </body>
    </html>