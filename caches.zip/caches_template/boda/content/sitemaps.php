<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>人事考试资讯网-网站地图</title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css?xg=1208" />
</head>

<body>
<div class="cy-tyct">
 <div class="kzc-posi">当前位置：<a href="http://www.renshikaoshi.net">首页</a><span> &gt; </span>  <a href="/sitemaps.html">站点地图</a></a>
</div>
<span style="display:none;"><strong>网站栏目</strong></span>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b43f1459ac702900c8d44c91a5e796dd&action=category&catid=0&num=25&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>'0','siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'25',));}?>
      <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
     
         <?php if($r[catid]<='11') { ?>
                     <div class="sitemaptycut"><a href="<?php echo $r['url'];?>" target="_blank"><?php echo $r['catname'];?></a></div><?php } ?> 
                     
                     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=2c5796102fc450f9052b61ce2eb23536&action=category&catid=%24r%5Bcatid%5D&num=25&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$r[catid],'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'25',));}?>
      <?php $n=1;if(is_array($data)) foreach($data AS $r2) { ?>
            
          <p class="sitemapclass">   <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9b32af063afe4a26d3226de12d53c1b0&action=category&catid=%24r2%5Bcatid%5D&num=25&siteid=%24siteid&order=listorder+ASC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('catid'=>$r2[catid],'siteid'=>$siteid,'order'=>'listorder ASC','limit'=>'25',));}?>
      <?php $n=1;if(is_array($data)) foreach($data AS $r3) { ?>
      <a href="<?php echo $r3['url'];?>" target="_blank"><?php echo $r3['catname'];?></a>
            <?php $n++;}unset($n); ?>
            </p>
            
            
       <?php $n++;}unset($n); ?>

     <?php $n++;}unset($n); ?>
      <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>    
      <div style="height:40px;" id="rsbmrk"></div>
      <div class="kzc-newsone kzc-btlind">
    	<div class="kzc-dtl"><span>人事报名入口</span></div>
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=97286c6f7e8cb20705eb61ae1d7e6975&sql=SELECT+linkageid%2Cname%2Cpinyin+from+v9_linkage+WHERE+parentid%3D0+AND+child%3D1+AND+linkageid+NOT+IN+%2833%2C34%2C35%2C3358%2C3364%29&cache=3600&return=data&num=31\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$tag_cache_name = md5(implode('&',array('sql'=>'SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364)',)).'97286c6f7e8cb20705eb61ae1d7e6975');if(!$data = tpl_cache($tag_cache_name,3600)){pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT linkageid,name,pinyin from v9_linkage WHERE parentid=0 AND child=1 AND linkageid NOT IN (33,34,35,3358,3364) LIMIT 31");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);if(!empty($data)){setcache($tag_cache_name, $data, 'tpl_data');}}?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $v) { ?>
        <table width="100%" cellpadding="0" cellspacing="0" class="bmrk_tb"  style="display:;">
        	<tr class="bg1">
            	<td colspan="6" class="sf_name"><?php echo $v['name'];?>人事考试网上报名快速通道</td>
            </tr>
            <tr>
             <?php $num = 0?>
         <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2063a765ab2cea71ee772c66644871fa&sql=SELECT+%2A+FROM+v9_renshibaoming+WHERE+cityid+%3D+%27%24v%5Blinkageid%5D%27+AND+status+%3D+%271%27+and+typeid%3D%27104%27+and+siteid%3D1+order+by+id+asc&cache=0&return=data2&num=1000\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM v9_renshibaoming WHERE cityid = '$v[linkageid]' AND status = '1' and typeid='104' and siteid=1 order by id asc LIMIT 1000");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data2 = $a;unset($a);?>
<?php $n=1; if(is_array($data2)) foreach($data2 AS $k => $val) { ?> <td>
            	 <?php if($val['filename']) { ?>
         <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $val['filename'];?>.html" target="_blank"><?php echo $val['seotitle'];?>报名入口</a>
         <?php } else { ?>
          <!-- <a href="<?php echo siteurl($siteid);?>/renshibaoming/<?php echo $val['id'];?>.html" target="_blank"><?php echo $val['title'];?></a> -->
         <?php } ?>
         </td>
         <?php if(($k+1)%6==0) { ?></tr><tr><?php } ?>
                <?php $n++;}unset($n); ?>
            </tr>
        </table>

        <?php $n++;}unset($n); ?>
    </div>

  <table width="100%" cellpadding="0" cellspacing="0" class="bmrk_tb"  style="display:;">
        	<tr class="bg1">
            	<td colspan="6" class="sf_name"> <span> <strong>考试专栏</strong></span></td>
            </tr>
            <tr>
             <?php $num = 0?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=3ff8490b0d1c65fb29206e256d07e13b&sql=SELECT+%2A+from+phpcms_diypage++order+by+id+desc&cache=0&num=1000&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage  order by id desc LIMIT 1000");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
 <td>	
         <a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a>
         </td>
         <?php if(($key+1)%6==0) { ?></tr><tr><?php } ?>
                <?php $n++;}unset($n); ?>
            </tr>
        </table>

 <p> <a href="/download/" target="_blank" title="下载列表">下载列表</a></p>   
      
</div>
<?php include template("content","rsks_bottom"); ?>

</body>
</html>