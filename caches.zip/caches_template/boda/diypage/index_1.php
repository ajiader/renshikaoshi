<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo str_replace(' - ','',$SEO['title']);?><?php } ?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/kzcty-css.css" />
<link type="text/css" rel="stylesheet" href="/statics/renshikaoshi/css/cykzc.css?xg=1212" />
<script type="text/javascript" src="/statics/renshikaoshi/js/53kf.js"></script>
<script type="text/javascript" src="/statics/renshikaoshi/js/jquery-1.7.2.min.js"></script>

</head>

<body>
<?php include template("content","rsks_top"); ?>
 <?php $catid = $catid>0?$catid:'0';?>
<!--center部分-->
<div class="cy-tyct">
    
    <!--当前位置-->
    <div class="functiondqwz"><img src="/statics/gwy/images/posiitonwz.png" />当前位置：<a href="/">首页</a>><?php echo $breadcrumb;?></div>
    
    <div class="seo_onedv">
    	<div class="wzdylf">
        	<h1><?php echo $h1;?></h1>
            <div class="dydaodu">
            	<div class="dlf"></div>
                <div class="drg" id="limittext">
                	<div class="content">
                	<?php echo $daodu;?>
                    </div>
                    
                </div>
            	<div class="examtyclear"></div>
            </div>
            
        </div>
        <div class="kstkright">
        	<div class="kstkcut"><a href="#" class="a1">考试题库</a><a href="javascript:void(0)" onclick="kefulink(6)" class="a2">向职考专家提问</a></div>
            <div class="kstkcontent">
            	<p class="p1">编辑推荐:</p>
                <p class="p1 p2"><a href="<?php echo $down_url;?>" title="<?php echo $down_title;?>" target="_blank"><?php echo $down_title;?></a></p>
                <p class="p3">下载次数：<strong><?php echo $down_num;?></strong></p>
                <p class="p4"><a href="<?php echo $down_url;?>" target="_blank">立即下载</a></p>
            </div>
        </div>
    	<div class="clear"></div>
    </div>
    <div class="seo_content">

    	<div class="seoleft">
         <?php if($h2arr) { ?>

            <?php $n=1;if(is_array($h2arr)) foreach($h2arr AS $v) { ?>
            <?php if($v['name']) { ?>
            <h2><?php echo $v['name'];?></h2>
            <ul class="newslist ftsmall listmore">
                 <?php if($v['like']) { ?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=368c7050a8229bc047f4e367b92c835d&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cinputtime+FROM+v9_news+where++status%3D99+%24v%5Blike%5D+order+by+id+desc&cache=3600&page=%24page&return=data&start=0&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 5;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_news where  status=99 $v[like] order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,inputtime FROM v9_news where  status=99 $v[like] order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
             <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
            	<li><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo $r['title'];?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <?php } else { ?>
                <li>没有找到相关信息</li>
                <?php } ?>
            </ul>
            
             <ul class="newslist ftsmall listmore">
                 <?php if($v['like']) { ?>
             <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=086e5059d847159837248230a724db3f&sql=SELECT+id%2Cstyle%2Curl%2Ctitle%2Cdescription%2Cinputtime+FROM+v9_news+where++status%3D99+%24v%5Blike%5D+order+by+id+desc&cache=3600&page=%24page&return=data&start=5&num=5\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$pagesize = 5;$page = intval($page) ? intval($page) : 1;if($page<=0){$page=1;}$offset = ($page - 1) * $pagesize;$r = $get_db->sql_query("SELECT COUNT(*) as count FROM  v9_news where  status=99 $v[like] order by id desc");$s = $get_db->fetch_next();$pages=pages($s['count'], $page, $pagesize, $urlrule);$r = $get_db->sql_query("SELECT id,style,url,title,description,inputtime FROM v9_news where  status=99 $v[like] order by id desc LIMIT $offset,$pagesize");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
             <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>  
            	<li><a href="<?php echo $r['url'];?>" target="_blank" title="<?php echo $r['title'];?>"><?php echo $r['title'];?></a><span><?php echo date('m-d',$r['inputtime']);?></span></li>
                <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                <?php } else { ?>
                <li>没有找到相关信息</li>
                <?php } ?>
            </ul>
            <?php } ?>
            <?php $n++;}unset($n); ?>
           <?php } ?>
            
        </div>
        <div class="seoright">
        	<div class="dvone">
            	<div class="dvcut">职称计算机考试模块推荐<a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">更多>></a></div>
                <div class="tjlist">
                	<span class="sp1 icon1"></span>
                    <span class="sp2">Word XP模块<br /><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">详情</a></span>
                   	<span class="sp3"><p class="p1">10元</p><p class="p2">原价50元</p></span>
                </div>
                <div class="tjlist">
                	<span class="sp1 icon2"></span>
                    <span class="sp2">Word 2003模块<br /><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">详情</a></span>
                   	<span class="sp3"><p class="p1">10元</p><p class="p2">原价50元</p></span>
                </div>
                <div class="tjlist">
                	<span class="sp1 icon3"></span>
                    <span class="sp2">Internet模块<br /><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">详情</a></span>
                   	<span class="sp3"><p class="p1">10元</p><p class="p2">原价50元</p></span>
                </div>
                <div class="tjlist">
                	<span class="sp1 icon4"></span>
                    <span class="sp2">PPT2003模块<br /><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">详情</a></span>
                   	<span class="sp3"><p class="p1">10元</p><p class="p2">原价50元</p></span>
                </div>
                <div class="tjlist">
                	<span class="sp1 icon5"></span>
                    <span class="sp2">Excel 2003模块<br /><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
">详情</a></span>
                   	<span class="sp3"><p class="p1">10元</p><p class="p2">原价50元</p></span>
                </div>
            </div>
            <div class="kzc-newsone"><a href="http://item.taobao.com/item.htm?spm=2013.1.w5002-6518291210.8.NaZzoG&id=37117006912
"><img src="/statics/renshikaoshi/images/jsjggpic1.gif" /></a></div>
            <div class="dvone">
            	<div class="dvcut"><?php echo $CATEGORYS[$catid]['catname'];?>最新动态</div>
                <ul class="newslist ftsmall listmore seorg">
                <?php $where="status=99";?>
                <?php $where = ($catid>0)?$where." and catid=$catid":$where;?>
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=0b81a2ed2dc89866748da20573a151ee&sql=SELECT+%2A+from+phpcms_news+WHERE+%24where+&cache=0&num=10&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_news WHERE $where  LIMIT 10");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                     <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
              <li><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo str_cut($r[title],55,'');?></a></li>
                 <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                </ul>
            </div>
            <div class="kzc-newsone"><a href="#"><img src="/statics/renshikaoshi/images/jsjggpic1.gif" /></a></div>
            <div class="dvone">
            	<div class="dvcut"><?php echo replace_arr($cityList['name'],array('省','市'));?>考试最新动态</div>
                <ul class="newslist ftsmall listmore seorg">
                <?php $cityname = replace_arr($cityList['name'],array('省','市'));?>
                     <?php $where="status=99";?>
                <?php $where = ($cityid>0)?$where." and (city_id in ($cityList[arrchildid])  or title like '%$cityname%')":$where;?>
     <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=0b81a2ed2dc89866748da20573a151ee&sql=SELECT+%2A+from+phpcms_news+WHERE+%24where+&cache=0&num=10&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_news WHERE $where  LIMIT 10");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
                       <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                    <li><a href="<?php echo $r['url'];?>" target="_blank"<?php echo title_style($r[style]);?>><?php echo str_cut($r[title],55,'...');?></a></li>
                   <?php $n++;}unset($n); ?>
                </ul>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    
</div>
<div class="seokszl">
	<div class="cy-tyct">
    	<span>考试专栏：</span>
        <div class="kszldv">
       <?php $where = "id>0";?>
         <?php $where = ($catid>0)?$where." and catid=$catid":$where;?>
              <?php $where = ($cityid>0)?$where." and  cityid in ($cityList[arrchildid])":$where;?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=dd37412dd859f74b8d41e56e8dfe6134&sql=SELECT+%2A+from+phpcms_diypage+WHERE+%24where+order+by+level+desc%2Cid+desc&cache=0&num=30&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * from phpcms_diypage WHERE $where order by level desc,id desc LIMIT 30");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$data = $a;unset($a);?>
<?php $n=1; if(is_array($data)) foreach($data AS $key => $val) { ?>
        	<a href="/r/<?php echo $val['dirname'];?>/" target="_blank" title="<?php echo $val['h1'];?>"><?php echo $val['h1'];?></a>
            <?php $n++;}unset($n); ?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        </div>
        <div class="clear"></div>
    </div>
</div>
<?php include template("content","rsks_bottom"); ?>
</body>
</html>
