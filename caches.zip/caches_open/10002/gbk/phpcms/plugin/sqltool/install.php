<?php
defined('IN_PHPCMS') or exit('No permission resources.');	
$op_status = TRUE;
?>